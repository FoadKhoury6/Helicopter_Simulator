//Struct
typedef struct Speed;
typedef struct Color;
typedef struct Location;
typedef struct Rotation;
typedef struct Size;
typedef struct Smoke;
typedef struct Box;
typedef struct Wheel;
typedef struct Sata;
typedef struct Missile;
typedef struct Missile_Launcher;
typedef struct Tank;
typedef struct Bullding_With_Tank;
typedef struct Tree;
typedef struct Cloud;
typedef struct Street;
typedef struct XO;
typedef struct Aim;
typedef struct Bullet;
typedef struct Helicopter;
typedef struct Bridge;
typedef struct Building;
typedef struct Button;
typedef struct GameList;
typedef struct Bonus;
typedef struct Trailer;
typedef struct Train;
typedef struct XO_Table;
typedef struct Star;
//Functions

//Object Status
#define HIDE -1
#define NOT_READY 0
#define READY 1
#define NOT_ACTIVE 0
#define ACTIVATED 1
#define LEFT_BOUND 1
#define RIGHT_BOUND 2
#define BACK_BOUND 3
#define FRONT_BOUND 4
#define DAWN_BOUND 5
#define UP_BOUND 6
#define CLOSE_TANK 7
#define FAR_TANK 8
#define CATCHED 9
#define FALLEN 10

//Game_Controller
#define SCREEN_MANU 0
#define SCREEN_PLAYING 1
#define SCREEN_WINNER 2
#define SCREEN_OBJECTS 3
#define SCREEN_CHOOSE_PLAYERS 4
#define SCREEN_NEWUSER  5
//Hit_Coins
#define HIT_TANK_BONUS 1
#define TANK_DESTROYED_BONUS 25
#define BUILD_DESTROYED_BONUS 15
#define TRAIN_HIT_BONUS 5
//Maps
#define MAP_1 1
#define MAP_2 2
#define MAP_3 3 
#define MAP_4 4
#define MAP_5 5

//Players
#define ONE_PLAYER 1
#define TWO_PLAYERS 2
//XO
#define BLUE_X 1
#define RED_O 2
//Screen_Controller
#define MOVE_MAP_TO_MAIN 0
#define MOVE_MAIN_TO_MAP 1
#define MOVE_MAIN_TO_GAMES 2 
#define MOVE_GAMES_TO_MAIN 3 
#define MOVE_MAIN_TO_DETAILS 4
#define MOVE_DETAILS_TO_MAIN 5
#define MOVE_MAIN_TO_REGISTER 6  
#define MOVE_REGISTER_TO_MAP 7
#define MOVE_MAP_TO_STORE 8
#define MOVE_STORE_TO_MAP 9
#define MOVE_DETAILS_TO_OBJECTS 10
#define MOVE_OBJECTS_TO_DETAILS 11

// Status Define's
#define NOT_ACTIVE 0
#define ACTIVATED 1
#define LEFT_BOUND 1
#define RIGHT_BOUND 2
#define BACK_BOUND 3
#define FRONT_BOUND 4
#define DAWN_BOUND 5
#define UP_BOUND 6
#define CLOSE_TANK 7
#define FAR_TANK 8
#define CATCHED 9
#define FALLEN 10

//Builds Define's
#define Map_2_Build_1 0
#define Map_2_Build_2 1
#define Map_2_Build_3 2
#define Map_2_Build_4 3
#define Map_2_Build_5 4 
#define Map_2_Build_6 5
#define Map_Wall 10
#define Map_1_Build_1 6
#define Map_1_Build_2 7
#define Map_1_Build_3 8
#define Map_1_Build_4 9
#define Map_1_Build_5 23
#define Map_1_Build_6 24
#define Map_3_Build_1 11
#define Map_3_Build_2 12
#define Map_3_Build_3 13
#define Map_3_Build_4 14 
#define Map_3_Build_5 15
#define Map_3_Build_6 16
#define Map_3_Build_7 17
#define Map_3_Build_8 18
#define Map_3_Build_9 19
#define Map_3_Build_10 21
#define Map_3_Build_11 22
#define Map_4_Build_1 20
#define Map_4_Build_2 25

#define LEVEL_1 0
#define LEVEL_2 1
#define LEVEL_3 2
#define BULLET_DAMAGE 10
#define MISSILE_DAMAGE 30
#define BOMB_DAMAGE 40

#define HIT_XO 1
#define PLAYER_1_WINS 1
#define PLAYER_2_WINS 2
#define DRAW 3
#define BIG_MISSILE 0
#define SMALL_MISSILE 1
#define TRILER_TYPE_0 0
#define TRILER_TYPE_1 1
#define TRILER_TYPE_2 2
#define TRILER_TYPE_3 3
#define BOUND_DISTANCE 0.4
#define PI 3.14159265