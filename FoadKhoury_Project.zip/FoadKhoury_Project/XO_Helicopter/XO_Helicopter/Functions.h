#include "Stucture.h"
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <GL/glut.h>
#include <windows.h>

float GlobalSpeed =2.5;
float StoreX=19;
void Draw_String_int(float r,float g,float b,float x,float y,float z,char *s,int health);
void Draw_String_float(float r,float g,float b,float x,float y,float z,char *s,float health);
void Draw_Square(float x,float y,float Side,float r,float g,float b);
void Draw_String(float r,float g,float b,float x,float y,float z,char *s);
int BoundFunc(Box B1 ,Location L1,Box B2,Location L2);
void Draw_XO_Box(XO *xo);
void Throw_Xo(Helicopter *H);
int Check_Winner(XO_Table *table);
User *Get_User(char *str);
void Blow_Gun(Gun *G);
float Distince_xz(Location *L1,Location *L2)
{
	return sqrt(pow(L1->x-L2->x,2)*pow(L1->z-L2->z,2));
}
float Distince_x(Location *L1,Location *L2)
{
	return abs(L1->x-L2->x);
}
float Distince_z(Location *L1,Location *L2)
{
	return abs(L1->z-L2->z);
}
//Speed
void Set_Speed(Speed *S,float x,float y,float z)
{
	S->x=x;
	S->y=y;
	S->z=z;
}
//Size
void Set_Size(Size *S,float x,float y,float z)
{
	S->x=x;
	S->y=y;
	S->z=z;
}
void Set_Box_Size(Box *B,float size_x,float size_y,float size_z)
{
	Set_Size(&B->size,size_x,size_y,size_z);

}
//Color
void Set_Color(Color *R,float r,float g,float b)
{
	R->r=r;
	R->g=g;
	R->b=b;
}
void Set_Box_Color(Box *B,float r,float g,float b)
{
	Set_Color(&B->color,r,g,b);
}
void Color_On(Color C)
{
	glColor3f(C.r*1.2,C.g*1.2,C.b*1.2);
}
//Location
void Set_Location(Location *L,float x,float y,float z)
{
	L->x=x;
	L->y=y;
	L->z=z;
}
void Set_Box_Location(Box *B,float x,float y,float z)
{
	Set_Location(&B->location,x,y,z);
}
void Go_Location(Location L)
{
	glTranslatef(L.x, L.y, L.z);
}
void Back_Location(Location L)
{
	glTranslatef(-L.x, -L.y, -L.z);
}
void Copy_Location(Location *L,Location L1)
{
	L->x=L1.x;
	L->y=L1.y;
	L->z=L1.z;
}
void Add_Location(Location *L,Location L1)
{
	L->x+=L1.x;
	L->y+=L1.y;
	L->z+=L1.z;
}
//Rotation
void Set_Rotation(Rotation *R,int x,int y,int z)
{
	R->x=x;
	R->y=y;
	R->z=z;
}
void Set_Box_Rotation(Box *B,float Rotx,float Roty,float Rotz)
{
	Set_Rotation(&B->rotation,Rotx,Roty,Rotz);
}
void Rotation_Open(Rotation R,int f1,int f2,int f3)
{
	if(f1)
		glRotatef(R.x,1,0,0);
	if(f2)
		glRotatef(R.y,0,1,0);
	if(f3)
		glRotatef(R.z,0,0,1);
}
void Rotation_Close(Rotation R,int f1,int f2,int f3)
{

	if(f3)
		glRotatef(-R.z,0,0,1);
	if(f2)
		glRotatef(-R.y,0,1,0);
	if(f1)
		glRotatef(-R.x,1,0,0);
}

void RotateUntil_X(Rotation *R,Location FROM,Location TO,int add)
{
	if(TO.z > FROM.z)
	{
		if(TO.y>FROM.y)
		{
			R->x=-(int)(atan( abs( (TO.y) - (FROM.y) ) / abs( (TO.z) - (FROM.z) ) )*180.0/PI)+add;
		}
		else
		{
			R->x=(int)(atan( abs( (TO.y) - (FROM.y) ) / abs( (FROM.z) - (TO.z) ) )*180.0/PI)+add;
		}
	}
	else
	{
		if(TO.y>FROM.y)
		{
			R->x=-180+(int)(atan( abs( (FROM.y) - (TO.y) ) / abs( (TO.z) - (FROM.z) ) )*180.0/PI)+add;
		}
		else
		{
			R->x=-180-(int)(atan( abs( (FROM.y) - (TO.y) ) / abs( (FROM.z) - (TO.z) ) )*180.0/PI)+add;

		}
	}
}
void RotateUntil_Y(Rotation *R,Location FROM,Location TO,int add)
{
	if(TO.x > FROM.x)
	{
		if(TO.z>FROM.z)
		{
			R->y=(int)(atan( abs( (TO.x) - (FROM.x) ) / abs( (TO.z) - (FROM.z) ) )*180.0/PI)+add;
		}
		else
		{
			R->y=180-(int)(atan( abs( (TO.x) - (FROM.x) ) / abs( (FROM.z) - (TO.z) ) )*180.0/PI)+add;
		}
	}
	else
	{
		if(TO.z>FROM.z)
		{
			R->y=360-(int)(atan( abs( (FROM.x) - (TO.x) ) / abs( (TO.z) - (FROM.z) ) )*180.0/PI)+add;
		}
		else
		{
			R->y=180+(int)(atan( abs( (FROM.x) - (TO.x) ) / abs( (FROM.z) - (TO.z) ) )*180.0/PI)+add;
		}
	}
}

void RotateUntil_X_Half(Rotation *R,Location FROM,Location TO,int add)
{
	float Under;
	if(abs( (TO.z) - (FROM.z) ) > abs( (TO.x) - (FROM.x) ))
		Under = abs( (TO.z) - (FROM.z) );
	else
		Under = abs( (TO.x) - (FROM.x) );
	if(FROM.z<TO.z)
	{
		if(TO.y>FROM.y)
		{
			R->x=-(int)(atan( abs( (TO.y) - (FROM.y) ) / Under )*180.0/PI)+add;
		}
		else
		{
			R->x=(int)(atan( abs( (TO.y) - (FROM.y) ) / Under )*180.0/PI)+add;
		}
	}
	else
	{
		if(TO.y>FROM.y)
		{
			R->x=-(int)(atan( abs( (TO.y) - (FROM.y) ) / Under )*180.0/PI)+add;
		}
		else
		{
			R->x=(int)(atan( abs( (TO.y) - (FROM.y) ) / Under )*180.0/PI)+add;
		}
	}
}
void RotateUntil_XY(Rotation *R,Location FROM,Location TO,int add)
{
	RotateUntil_Y(R,FROM,TO,add);
	if(FROM.z<TO.z)
	{
		if(TO.y>FROM.y)
		{
			R->x=-(int)(atan( abs( (TO.y) - (FROM.y) ) / abs( (TO.z) - (FROM.z) ) )*180.0/PI)+add;
		}
		else
		{
			R->x=(int)(atan( abs( (TO.y) - (FROM.y) ) / abs( (FROM.z) - (TO.z) ) )*180.0/PI)+add;
		}
	}
	else
	{
		if(TO.y>FROM.y)
		{
			R->x=(int)(atan( abs( (TO.y) - (FROM.y) ) / abs( (TO.z) - (FROM.z) ) )*180.0/PI)+add;
		}
		else
		{
			R->x=-(int)(atan( abs( (TO.y) - (FROM.y) ) / abs( (FROM.z) - (TO.z) ) )*180.0/PI)+add;
		}
	}
}
//Box
void Set_Box(Box *B,float x,float y,float z,float size_x,float size_y,float size_z,float Rotx,float Roty,float Rotz,float r,float g,float b)
{
	Set_Location(&B->location,x,y,z);
	Set_Size(&B->size,size_x,size_y,size_z);
	Set_Rotation(&B->rotation,Rotx,Roty,Rotz);
	Set_Color(&B->color,r,g,b);
}
void Draw_Box(Box B)
{
	float cx,cy,cz;
	cx=B.size.x/2;
	cy=B.size.y/2;
	cz=B.size.z/2;
	Color_On(B.color);

	glBegin(GL_QUADS);
	// Front
	glNormal3f(0, 0, 1);
	glVertex3f(-cx, -cy, cz);
	glVertex3f(-cx, cy, cz);
	glVertex3f(cx, cy, cz);
	glVertex3f(cx, -cy, cz);

	// Back
	glNormal3f(0, 0, -1);
	glVertex3f(-cx, -cy, -cz);
	glVertex3f(cx, -cy, -cz);
	glVertex3f(cx, cy, -cz);
	glVertex3f(-cx, cy, -cz);

	// Left side
	glNormal3f(-1, 0, 0);
	glVertex3f(-cx, -cy, cz);
	glVertex3f(-cx, cy, cz);
	glVertex3f(-cx, cy, -cz);
	glVertex3f(-cx, -cy, -cz);

	// Right side
	glNormal3f(1, 0, 0);
	glVertex3f(cx, -cy, cz);
	glVertex3f(cx, -cy, -cz);
	glVertex3f(cx, cy, -cz);
	glVertex3f(cx, cy, cz);

	// Up side
	glNormal3f(0, 0, 1);
	glVertex3f(cx, cy, cz);
	glVertex3f(cx, cy, -cz);
	glVertex3f(-cx, cy, -cz);
	glVertex3f(-cx, cy, cz);

	// down side
	glNormal3f(0, 0, 1);
	glVertex3f(cx, -cy, cz);
	glVertex3f(cx, -cy, -cz);
	glVertex3f(-cx, -cy, -cz);
	glVertex3f(-cx, -cy, cz);
	glEnd();
}
void Draw_Box_R(Box B)
{
	Rotation_Open(B.rotation,1,1,1);
	Draw_Box(B);
	Rotation_Close(B.rotation,1,1,1);
}
void Draw_Box_T(Box B)
{
	Go_Location(B.location);
	Draw_Box(B);
	Back_Location(B.location);
}
void Draw_Box_TR(Box B)
{
	Go_Location(B.location);
	Rotation_Open(B.rotation,1,1,1);
	Draw_Box(B);
	Rotation_Close(B.rotation,1,1,1);
	Back_Location(B.location);
}
void Draw_Shapped_Box_Up(Box B,float x,float y,float z)
{
	float cx,cy,cz;
	cx=B.size.x/2;
	cy=B.size.y/2;
	cz=B.size.z/2;
	Color_On(B.color);
	Go_Location(B.location);
	Rotation_Open(B.rotation,1,1,1);
	glBegin(GL_QUADS);
	// Front

	glNormal3f(0, 0, 1);
	glVertex3f(-cx, -cy, cz);
	glVertex3f(-(cx+x), cy, (cz+z));
	glVertex3f((cx+x), cy, (cz+z));
	glVertex3f(cx, -cy, cz);

	// Back
	glNormal3f(0, 0, -1);
	glVertex3f(-cx, -cy, -cz);
	glVertex3f(cx, -cy, -cz);
	glVertex3f((cx+x), cy, -(cz+z));
	glVertex3f(-(cx+x), cy, -(cz+z));

	// Left side
	glNormal3f(-1, 0, 0);
	glVertex3f(-cx, -cy, cz);
	glVertex3f(-(cx+x), cy, (cz+z));
	glVertex3f(-(cx+x), cy, -(cz+z));
	glVertex3f(-cx, -cy, -cz);

	// Right side
	glNormal3f(1, 0, 0);
	glVertex3f(cx, -cy, cz);
	glVertex3f(cx, -cy, -cz);
	glVertex3f((cx+x), cy, -(cz+z));
	glVertex3f((cx+x), cy, (cz+z));

	// Up side
	glNormal3f(0, 0, 1);
	glVertex3f((cx+x), cy, (cz+z));
	glVertex3f((cx+x), cy, -(cz+z));
	glVertex3f(-(cx+x), cy, -(cz+z));
	glVertex3f(-(cx+x), cy, (cz+z));

	// down side
	glNormal3f(0, 0, 1);
	glVertex3f(cx, -cy, cz);
	glVertex3f(cx, -cy, -cz);
	glVertex3f(-cx, -cy, -cz);
	glVertex3f(-cx, -cy, cz);
	glEnd();
	Rotation_Close(B.rotation,1,1,1);
	Back_Location(B.location);

}
void Draw_Shapped_Box_Front(Box B,float x,float y,float z)
{
	float cx,cy,cz;
	cx=B.size.x/2;
	cy=B.size.y/2;
	cz=B.size.z/2;
	Color_On(B.color);
	Go_Location(B.location);
	Rotation_Open(B.rotation,1,1,1);
	
	glBegin(GL_QUADS);

	glNormal3f(0, 0, 1);
	glVertex3f(-(cx+x), -(cy+y), cz);
	glVertex3f(-(cx+x), (cy+y), cz);
	glVertex3f((cx+x), (cy+y), cz);
	glVertex3f((cx+x), -(cy+y), cz);

	// Back
	glNormal3f(0, 0, -1);
	glVertex3f(-cx, -cy, -cz);
	glVertex3f(cx, -cy, -cz);
	glVertex3f(cx, cy, -cz);
	glVertex3f(-cx, cy, -cz);

	// Left side
	glNormal3f(-1, 0, 0);
	glVertex3f(-(cx+x), -(cy+y), cz);
	glVertex3f(-(cx+x), (cy+y), cz);
	glVertex3f(-cx, cy, -cz);
	glVertex3f(-cx, -cy, -cz);

	// Right side
	glNormal3f(1, 0, 0);
	glVertex3f((cx+x), -(cy+y), cz);
	glVertex3f(cx, -cy, -cz);
	glVertex3f(cx, cy, -cz);
	glVertex3f((cx+x), (cy+y), cz);

	// Up side
	glNormal3f(0, 0, 1);
	glVertex3f((cx+x), (cy+y), cz);
	glVertex3f(cx, cy, -cz);
	glVertex3f(-cx, cy, -cz);
	glVertex3f(-(cx+x), (cy+y), cz);

	// down side
	glNormal3f(0, 0, 1);
	glVertex3f((cx+x), -(cy+y), cz);
	glVertex3f(cx, -cy, -cz);
	glVertex3f(-cx, -cy, -cz);
	glVertex3f(-(cx+x), -(cy+y), cz);
	glEnd();
	Rotation_Close(B.rotation,1,1,1);
	Back_Location(B.location);

}
//Smoke
void Set_Smoke(Smoke *S,float MaxRadius,float speed,float R,float G,float B)
{
	Set_Color(&S->color,R,G,B);
	S->Max_Radius=MaxRadius;
	S->Speed=speed*GlobalSpeed;
}
void Draw_Smoke(Smoke *S,int DownColor)
{
	if(DownColor==1)
	{
		S->color.r-=0.001;
		S->color.g-=0.001;
		S->color.b-=0.001;
	}
	Go_Location(S->location);
		Color_On(S->color);
		glutSolidSphere(S->Radius,5,5);
	Back_Location(S->location);
	S->Radius+=S->Speed;
	if(S->Radius>S->Max_Radius)
			S->Radius=0;
}
void Draw_Blow_Smoke(Smoke *S)
{
	Go_Location(S->location);
		if(S->Radius<S->Max_Radius/2)
			glColor3f(1,1,0);
		else if(S->Radius<S->Max_Radius)
			glColor3f(1,0,0);
		else
			glColor3f(0,0,0);
		glutSolidSphere(S->Radius,5,5);
	Back_Location(S->location);
	S->Radius+=S->Speed;
	if(S->Radius>S->Max_Radius+0.5)
			S->Radius=0;
	
}
//Missile
void Set_Missile(Missile *missile,float x,float y,float z ,int type)
{
	Set_Location(&missile->location,x,y,z);
	missile->Type=type;
	if(!type)
	{
		for(int i=0;i<4;i++)
		{
			Set_Smoke(&missile->smoke[i],1,0.02,1,1,1);
			missile->smoke[i].Radius=i*-0.2;
		}

		Set_Smoke(&missile->Blow,2,0.01,1,1,1);

		missile->fuel=1500;
		Set_Speed(&missile->Maxspeed,1*GlobalSpeed,1*GlobalSpeed,1*GlobalSpeed);

		Set_Box_Color(&missile->Body,1,1,1);
		Set_Box_Size(&missile->Body,0.3,0.3,1.5);
		Set_Box_Location(&missile->Body,0,0,0);
		Set_Box_Rotation(&missile->Body,0,0,0);

		Set_Box_Color(&missile->Top,1,0,0);
		Set_Box_Size(&missile->Top,0.3,0.3,1);
		Set_Box_Location(&missile->Top,0,0,1.2);
		Set_Box_Rotation(&missile->Top,0,0,0);

		Set_Box_Color(&missile->Wing1,0,0,1);
		Set_Box_Size(&missile->Wing1,0.2,0.8,0.5);
		Set_Box_Location(&missile->Wing1,0,0,-0.5);
		Set_Box_Rotation(&missile->Wing1,0,0,0);

		Set_Box_Color(&missile->Wing2,0,0,1);
		Set_Box_Size(&missile->Wing2,0.8,0.2,0.5);
		Set_Box_Location(&missile->Wing2,0,0,-0.5);
		Set_Box_Rotation(&missile->Wing2,0,0,0);
	}
	else
	{
		for(int i=0;i<4;i++)
		{
			Set_Smoke(&missile->smoke[i],1.0,0.04,1,1,1);
			missile->smoke[i].Radius=i*-0.2;
		}
		Set_Smoke(&missile->Blow,1,0.05,1,1,1);

		missile->fuel=400;
		Set_Speed(&missile->Maxspeed,3,3,3);

		Set_Box_Color(&missile->Body,1,1,1);
		Set_Box_Size(&missile->Body,0.3,0.3,0.5);
		Set_Box_Location(&missile->Body,0,0,0);
		Set_Box_Rotation(&missile->Body,0,0,0);

		Set_Box_Color(&missile->Top,1,0,0);
		Set_Box_Size(&missile->Top,0.3,0.3,0.5);
		Set_Box_Location(&missile->Top,0,0,0.5);
		Set_Box_Rotation(&missile->Top,0,0,0);

		Set_Box_Color(&missile->Wing1,0,0,1);
		Set_Box_Size(&missile->Wing1,0.1,0.5,0.5);
		Set_Box_Location(&missile->Wing1,0,0,0);
		Set_Box_Rotation(&missile->Wing1,0,0,0);

		Set_Box_Color(&missile->Wing2,0,0,1);
		Set_Box_Size(&missile->Wing2,0.5,0.1,0.5);
		Set_Box_Location(&missile->Wing2,0,0,0);
		Set_Box_Rotation(&missile->Wing2,0,0,0);
	}
}
void Draw_Missile(Missile *missile)
{
	Go_Location(missile->location);
	Rotation_Open(missile->rotation,1,1,0);
	Draw_Box(missile->Body);
	Draw_Shapped_Box_Front(missile->Top,-missile->Top.size.x/2,-missile->Top.size.y/2,0);
	Draw_Shapped_Box_Front(missile->Wing1,0,-missile->Top.size.y/2,0);
	Draw_Shapped_Box_Front(missile->Wing2,-missile->Top.size.x/2,0,0);
	Rotation_Close(missile->rotation,1,1,0);
	Back_Location(missile->location);
	
	if(missile->status!=0)
	{
		glColor3f(0,0,0);
		glTranslatef(missile->location.x,0.2,missile->location.z);
		Rotation_Open(missile->rotation,0,1,0);
		glBegin(GL_QUADS);
		glVertex3f(0.5,0,0.5);
		glVertex3f(0.5,0,-0.5);
		glVertex3f(-0.5,0,-0.5);
		glVertex3f(-0.5,0,0.5);
		glEnd();
		Rotation_Close(missile->rotation,0,1,0);
		glTranslatef(-missile->location.x,-0.2,-missile->location.z);
	}
	for(int i=0;i<4;i++)
		if(missile->smoke[i].Radius>0)Draw_Smoke(&missile->smoke[i],1);
}
void Reset_Missile(Missile *missile)
{
	Copy_Location(&missile->Blow.location,missile->location);
	missile->Blow.Radius=0.0001;
	missile->status=0;
	Set_Speed(&missile->speed,0,0,0);
	Set_Rotation(&missile->rotation,0,0,0);
	for(int i=0;i<4;i++)
		Set_Color(&missile->smoke[i].color,1,1,1);
	Set_Missile(missile,0,0.8,-0.2,missile->Type);
}
void Missile_Movment(Missile *missile)
{
	if(missile->target!=nullptr)
	{
		RotateUntil_XY(&missile->rotation,missile->location,*missile->target,0);
		if(missile->status!=0)
		{
			if(missile->location.x < missile->target->x)
				(missile->speed.x<0 && missile->speed.x<missile->Maxspeed.x)? missile->speed.x+=0.01 : missile->speed.x+=0.001;
			else
				(missile->speed.x>0 && missile->speed.x>0-missile->Maxspeed.x)?missile->speed.x-=0.01 : missile->speed.x-=0.001;

			if(missile->location.y < missile->target->y)
				(missile->speed.y<0 && missile->speed.y<missile->Maxspeed.y)? missile->speed.y+=0.01 : missile->speed.y+=0.001*GlobalSpeed;
			else
				(missile->speed.y>0 && missile->speed.y>0-missile->Maxspeed.y)? missile->speed.y-=0.01 : missile->speed.y-=0.001*GlobalSpeed;

			if(missile->location.z < missile->target->z)
				(missile->speed.z<0 && missile->speed.z<missile->Maxspeed.z)? missile->speed.z+=0.01 : missile->speed.z+=0.001*GlobalSpeed;
			else
				(missile->speed.z>0 && missile->speed.z>0-missile->Maxspeed.z)? missile->speed.z-=0.01 : missile->speed.z-=0.001*GlobalSpeed;

			for(int i=0;i<4;i++)
				if(missile->smoke[i].Radius==0)
				{
					Copy_Location(&missile->smoke[i].location,missile->location);
					missile->smoke[i].Radius+=0.001;
				}

			missile->location.x+=missile->speed.x;
			missile->location.y+=missile->speed.y;
			missile->location.z+=missile->speed.z;
			missile->fuel--;
			missile->status++;
			if(missile->fuel==0 || missile->location.y<0)
				Reset_Missile(missile);
			if(BoundFunc(missile->Body,missile->location,missile->Helicopter_target->BoundArea,*missile->target))
			{
				missile->Helicopter_target->Shake=30;
				missile->Helicopter_target->Health-=missile->Damage;
				Throw_Xo(missile->Helicopter_target);
				Reset_Missile(missile);
			}
		}
	}

}
//Missile_Launcher
void Set_MissileLauncher(Missile_Launcher *ML,float x,float y,float z,int Type)
{
	ML->Type=Type;
	Set_Location(&ML->location,x,y,z);
	ML->missile.Launch_Location=&ML->location;
	Set_Missile(&ML->missile,0,0.8,-0.2,Type);
	ML->missile.status=0;
	Set_Rotation(&ML->rotation,0,0,0);
	Set_Rotation(&ML->missile.rotation,0,0,0);
	if(!Type)
	{
		Set_Box_Color(&ML->Base,0.2,0.4,0.2);
		Set_Box_Size(&ML->Base,1,0.2,1.5);
		Set_Box_Location(&ML->Base,0,0,0);
		Set_Box_Rotation(&ML->Base,0,0,0);

		Set_Box_Color(&ML->Hold,0.3,0.5,0.2);
		Set_Box_Size(&ML->Hold,0.6,0.1,1.5);
		Set_Box_Location(&ML->Hold,0,0.5,-0.1);
		Set_Box_Rotation(&ML->Hold,0,0,0);

		Set_Box_Color(&ML->Stick,0.5,0.5,0.5);
		Set_Box_Size(&ML->Stick,0.1,1,0.1);
		Set_Box_Location(&ML->Stick,0.4,0.5,0.65);
		Set_Box_Rotation(&ML->Stick,0,0,0);

		Set_Box_Color(&ML->Under_base,0.5,0.5,0.5);
		Set_Box_Size(&ML->Under_base,0.5,1,0.5);
		Set_Box_Location(&ML->Under_base,0,0,0);
		Set_Box_Rotation(&ML->Under_base,0,0,0);
	}
	else
	{
		Set_Box_Color(&ML->Base,0.2,0.4,0.2);
		Set_Box_Size(&ML->Base,1,0.2,1.5);
		Set_Box_Location(&ML->Base,0,0,0);
		Set_Box_Rotation(&ML->Base,0,0,0);

		Set_Box_Color(&ML->Hold,0.3,0.5,0.2);
		Set_Box_Size(&ML->Hold,0.5,0.5,1.5);
		Set_Box_Location(&ML->Hold,0,0.8,-0.1);
		Set_Box_Rotation(&ML->Hold,0,0,0);

		Set_Box_Color(&ML->Stick,0.5,0.5,0.5);
		Set_Box_Size(&ML->Stick,0.1,1.5,0.1);
		Set_Box_Location(&ML->Stick,0.4,0.75,0.65);
		Set_Box_Rotation(&ML->Stick,0,0,0);

		Set_Box_Color(&ML->Under_base,0.5,0.5,0.5);
		Set_Box_Size(&ML->Under_base,0.5,1.2,0.5);
		Set_Box_Location(&ML->Under_base,0,0,-0.2);
		Set_Box_Rotation(&ML->Under_base,0,0,0);
	}
}
void Draw_Missile_Launcher(Missile_Launcher *ML)
{
	Go_Location(ML->location);
	Rotation_Open(ML->rotation,1,1,1);
	Draw_Box_TR(ML->Base);
	if(ML->missile.status==NOT_ACTIVE)
	{
		Rotation_Open(ML->Hold.rotation,1,1,1);
			Draw_Missile(&ML->missile);
			Draw_Box_T(ML->Hold);
		Rotation_Close(ML->Hold.rotation,1,1,1);
	}
	else
		Draw_Box_TR(ML->Hold);

	Draw_Box_T(ML->Under_base);
	Draw_Box_T(ML->Stick);
	Rotation_Close(ML->rotation,1,1,1);
	Back_Location(ML->location);

	if(ML->trailer==nullptr && ML->TankRotation==nullptr)
	{
		if(ML->missile.Blow.Radius!=0 )
			Draw_Blow_Smoke(&ML->missile.Blow);
		if(ML->missile.status!=NOT_ACTIVE)
			Draw_Missile(&ML->missile);
	}
}
void MissileLauncher_Movment(Missile_Launcher *ML)
{
	if(ML->target==nullptr)return;
	if(ML->missile.status!=NOT_ACTIVE)
	{
		if(ML->missile.status==1)
		{
			Copy_Location(&ML->missile.location,ML->location);
			ML->missile.location.y+=1;
			ML->missile.target=ML->target;
			for(int i=0;i<4;i++)
				ML->missile.smoke[i].Radius=i*0.2;

		}
		Missile_Movment(&ML->missile);
	}
	if(ML->TankRotation!=nullptr)
		RotateUntil_Y(&ML->rotation,*ML->Launch_Location,*ML->target,-(*ML->TankRotation));
	else
		RotateUntil_Y(&ML->rotation,ML->location,*ML->target,0);

	RotateUntil_X_Half(&ML->Hold.rotation,ML->location,*ML->target,0);
}
//Wheel
void Set_Wheel(Wheel *W ,float x,float y,float z,float R)
{
	W->location.x=x;
	W->location.y=y;
	W->location.z=z;
	Set_Box(&W->B1,0,0,0,R/2,R*2+0.2,R/2,0,0,0,0,0,0);
	Set_Box(&W->B2,0,0,0,R/2,R/2,R*2+0.2,0,0,0,0,0,0);
	W->Radius=R;
}
void Draw_Wheel(Wheel *W)
{
	W->rotation.x+=5*GlobalSpeed;
	W->rotation.x%=360;
	glColor3f(2,0,0);
	Go_Location(W->location);
	Rotation_Open(W->rotation,1,1,1);
	double a,z,y;
	int i=0;
	glColor3f(2,0,0);
	glBegin(GL_POLYGON); /// glBegin(GL_LINE_LOOP);
	for(i=0; i < 360; i+=5){
		a = PI * i;
		z = W->Radius*cos(a/180);
		y = W->Radius*sin(a/180);
		glVertex3d(0,y,z);
	}	
	glEnd();
	Draw_Box(W->B1);
	Draw_Box(W->B2);
	Rotation_Close(W->rotation,1,1,1);
	Back_Location(W->location);
}
//Sata
void Set_Sata(Sata *s,float x,float y,float z)
{
	Set_Location(&s->location,x,y,z);

	Set_Box_Color(&s->arr[0],0.2,0.4,0.2);
	Set_Box_Size(&s->arr[0],1,0.5,1);
	Set_Box_Location(&s->arr[0],0,0,0);
	Set_Box_Rotation(&s->arr[0],0,0,0);

	Set_Box_Color(&s->arr[1],0.1,0.5,0.1);
	Set_Box_Size(&s->arr[1],0.4,0.3,0.4);
	Set_Box_Location(&s->arr[1],0,0.3,0);
	Set_Box_Rotation(&s->arr[1],0,0,0);

	Set_Box_Color(&s->arr[2],0.4,0.4,0.4);
	Set_Box_Size(&s->arr[2],0.1,1,1);
	Set_Box_Location(&s->arr[2],-0.4,0.9,0);
	Set_Box_Rotation(&s->arr[2],-20,-55,0);

	Set_Box_Color(&s->arr[3],0.4,0.4,0.4);
	Set_Box_Size(&s->arr[3],0.1,1,1);
	Set_Box_Location(&s->arr[3],0.4,0.9,0);
	Set_Box_Rotation(&s->arr[3],-20,55,0);

	Set_Box_Color(&s->arr[4],0.7,0.7,0.7);
	Set_Box_Size(&s->arr[4],0.1,0.1,1);
	Set_Box_Location(&s->arr[4],0,0.75,0.3);
	Set_Box_Rotation(&s->arr[4],-20,0,0);
}
void Draw_Sata(Sata *s)
{
	s->arr[1].rotation.y++;
	s->arr[1].rotation.y%=360;
	Go_Location(s->location);
	Draw_Shapped_Box_Up(s->arr[0],-0.2,0,-0.2);
	Rotation_Open(s->arr[1].rotation,0,1,0);
	Draw_Box_T(s->arr[1]);
	Draw_Shapped_Box_Front(s->arr[2],0,-0.3,0);
	Draw_Shapped_Box_Front(s->arr[3],0,-0.3,0);
	Draw_Box_TR(s->arr[4]);
	Rotation_Close(s->arr[1].rotation,0,1,0);
	Back_Location(s->location);
}
//Tank
void Tank_Launch_Missile(Tank *T,int Height)
{
	if(T->ML.missile.status!=NOT_ACTIVE)
	{
		if(T->ML.missile.status==2)
		{
			Copy_Location(&T->ML.missile.location,T->location);
			T->ML.missile.location.y+=Height;
			for(int i=0;i<4;i++){
				Copy_Location(&T->ML.missile.smoke[i].location,T->ML.missile.location);
				T->ML.missile.smoke[i].Radius=i*0.2;
			}
		}
	}
}
void Switch_Tank_Target(Tank *T)
{
	if(T->target==&T->location_2)
		T->target=&T->location_1;
	else
		T->target=&T->location_2;
}
void Set_Tank(Tank *T,float x,float y,float z, int Type)
{
	T->Health=100;
	T->Type=Type;
	T->Start_Tank=200;
	T->Maxspeed=0.5*GlobalSpeed;
	Set_Location(&T->location,x,y,z);
	T->ML.TankRotation=&T->rotation.y;
	T->ML.Launch_Location=&T->location;
	T->ML.missile.Damage=MISSILE_DAMAGE;
	Set_Smoke(&T->Blow,2,0.03,1,1,1);
	T->target=nullptr;
	if(Type==1)
	{
		Set_MissileLauncher(&T->ML,0,1.0,-0.5,Type);
		Set_Box_Color(&T->Body,0.2,0.4,0.2);
		Set_Box_Size(&T->Body,2,0.5,2.5);
		Set_Box_Location(&T->Body,0,0.5,0);
		Set_Box_Rotation(&T->Body,0,0,0);

		Set_Box_Color(&T->Room,0.2,0.4,0.2);
		Set_Box_Size(&T->Room,1.5,0.5,1);
		Set_Box_Location(&T->Room,0,1,1.2);
		Set_Box_Rotation(&T->Room,0,0,0);

		Set_Box_Color(&T->Tank_Bound_Area,0.2,0.4,0.2);
		Set_Box_Size(&T->Tank_Bound_Area,3,2,3);
		Set_Box_Location(&T->Tank_Bound_Area,0,1,0);
		Set_Box_Rotation(&T->Tank_Bound_Area,0,0,0);

		if(Type==BIG_MISSILE){
		Set_Box_Size(&T->Missile_Area,20,20,20);
		Set_Box_Location(&T->Missile_Area,0,10,0);
		}
		if(Type==SMALL_MISSILE){
		Set_Box_Size(&T->Missile_Area,15,15,15);
		Set_Box_Location(&T->Missile_Area,0,7.5,0);
		}
		Set_Wheel(&T->wheel[0],0.7,0.2,-0.9,0.4);
		Set_Wheel(&T->wheel[1],0.7,0.2,0,0.4);
		Set_Wheel(&T->wheel[2],0.7,0.2,0.9,0.4);
		Set_Wheel(&T->wheel[3],-0.7,0.2,-0.9,0.4);
		Set_Wheel(&T->wheel[4],-0.7,0.2,0,0.4);
		Set_Wheel(&T->wheel[5],-0.7,0.2,0.9,0.4);
	}
	else if(T->Type==10)
	{
		T->Start_Tank=0;
		Set_MissileLauncher(&T->ML,0,0,-0.5,0);

		Set_Box_Color(&T->Body,0.2,0.4,0.2);
		Set_Box_Size(&T->Body,2,0.4,3);
		Set_Box_Location(&T->Body,0,0,0);
		Set_Box_Rotation(&T->Body,0,0,0);

		Set_Box_Color(&T->Tank_Bound_Area,0.2,0.4,0.2);
		Set_Box_Size(&T->Tank_Bound_Area,3,2,3);
		Set_Box_Location(&T->Tank_Bound_Area,0,0,0);
		Set_Box_Rotation(&T->Tank_Bound_Area,0,0,0);

		Set_Box_Color(&T->Heli[0],0.8,0.8,0.8);
		Set_Box_Size(&T->Heli[0],1.5,0.1,0.2);
		Set_Box_Location(&T->Heli[0],1,-0.3,1.5);
		Set_Box_Rotation(&T->Heli[0],0,0,0);
		
		Set_Box_Color(&T->Heli[1],0.8,0.8,0.8);
		Set_Box_Size(&T->Heli[1],1.5,0.1,0.2);
		Set_Box_Location(&T->Heli[1],-1,-0.3,1.5);
		Set_Box_Rotation(&T->Heli[1],0,0,0);
		
		Set_Box_Color(&T->Heli[2],0.8,0.8,0.8);
		Set_Box_Size(&T->Heli[2],1.5,0.1,0.2);
		Set_Box_Location(&T->Heli[2],1,-0.3,-1.5);
		Set_Box_Rotation(&T->Heli[2],0,0,0);
		
		Set_Box_Color(&T->Heli[3],0.8,0.8,0.8);
		Set_Box_Size(&T->Heli[3],1.5,0.1,0.2);
		Set_Box_Location(&T->Heli[3],-1,-0.3,-1.5);
		Set_Box_Rotation(&T->Heli[3],0,0,0);

		Set_Box_Size(&T->Missile_Area,20,20,20);
		Set_Box_Location(&T->Missile_Area,0,0,0);
	
	}
	else
	{
		Set_MissileLauncher(&T->ML,0,1.0,-0.5,Type);
		Set_Box_Color(&T->Body,0.2,0.4,0.2);
		Set_Box_Size(&T->Body,2,0.5,3.5);
		Set_Box_Location(&T->Body,0,0.5,0);
		Set_Box_Rotation(&T->Body,0,0,0);

		Set_Box_Color(&T->Room,0.2,0.4,0.2);
		Set_Box_Size(&T->Room,1.5,1,1);
		Set_Box_Location(&T->Room,0,1,2);
		Set_Box_Rotation(&T->Room,0,0,0);

		Set_Box_Color(&T->Tank_Bound_Area,0.2,0.4,0.2);
		Set_Box_Size(&T->Tank_Bound_Area,4,2,4);
		Set_Box_Location(&T->Tank_Bound_Area,0,1,0);
		Set_Box_Rotation(&T->Tank_Bound_Area,0,0,0);

		Set_Box_Color(&T->Missile_Area,0,0,0);
		Set_Box_Size(&T->Missile_Area,15,15,15);
		Set_Box_Location(&T->Missile_Area,0,7.5,0);
		Set_Box_Rotation(&T->Missile_Area,0,0,0);

		Set_Wheel(&T->wheel[0],0.7,0.2,-1.2,0.4);
		Set_Wheel(&T->wheel[1],0.7,0.2,0,0.4);
		Set_Wheel(&T->wheel[2],0.7,0.2,1.2,0.4);
		Set_Wheel(&T->wheel[3],-0.7,0.2,-1.2,0.4);
		Set_Wheel(&T->wheel[4],-0.7,0.2,0,0.4);
		Set_Wheel(&T->wheel[5],-0.7,0.2,1.2,0.4);
	}
}
void Set_Tank_1(Tank *T,float x,float y,float z,float x1,float y1,float z1, int Type)
{
	if(Type==10)
	{
		Set_Tank(T,x,y,z,Type);
			return;
	}
	T->Health=100;
	T->Type=Type+2;
	T->Maxspeed=0.1*GlobalSpeed;
	T->target=&T->location_2;
	Set_Location(&T->location,x,y,z);
	Set_Location(&T->location_1,x,y,z);
	Set_Location(&T->location_2,x1,y1,z1);
	Set_MissileLauncher(&T->ML,0,1.0,-0.5,Type);
	T->ML.TankRotation=&T->rotation.y;
	T->ML.Launch_Location=&T->location;
	T->ML.missile.Damage=MISSILE_DAMAGE;
	Set_Smoke(&T->Blow,2,0.03,1,1,1);

	if(Type)
	{
		Set_Box_Color(&T->Body,0.2,0.4,0.2);
		Set_Box_Size(&T->Body,2,1,2.5);
		Set_Box_Location(&T->Body,0,0.5,0);
		Set_Box_Rotation(&T->Body,0,0,0);

		Set_Box_Color(&T->Room,0.2,0.4,0.2);
		Set_Box_Size(&T->Room,1.5,0.5,1);
		Set_Box_Location(&T->Room,0,1,1.2);
		Set_Box_Rotation(&T->Room,0,0,0);

		Set_Box_Color(&T->Tank_Bound_Area,0.2,0.4,0.2);
		Set_Box_Size(&T->Tank_Bound_Area,3,2,3);
		Set_Box_Location(&T->Tank_Bound_Area,0,1,0);
		Set_Box_Rotation(&T->Tank_Bound_Area,0,0,0);

		Set_Box_Color(&T->Missile_Area,0,0,0);
		Set_Box_Size(&T->Missile_Area,15,15,15);
		Set_Box_Location(&T->Missile_Area,0,7.5,0);
		Set_Box_Rotation(&T->Missile_Area,0,0,0);

		Set_Wheel(&T->wheel[0],0.7,0.2,-0.9,0.4);
		Set_Wheel(&T->wheel[1],0.7,0.2,0,0.4);
		Set_Wheel(&T->wheel[2],0.7,0.2,0.9,0.4);
		Set_Wheel(&T->wheel[3],-0.7,0.2,-0.9,0.4);
		Set_Wheel(&T->wheel[4],-0.7,0.2,0,0.4);
		Set_Wheel(&T->wheel[5],-0.7,0.2,0.9,0.4);
	}
	else
	{
		Set_Box_Color(&T->Body,0.2,0.4,0.2);
		Set_Box_Size(&T->Body,2,0.5,3.5);
		Set_Box_Location(&T->Body,0,0.5,0);
		Set_Box_Rotation(&T->Body,0,0,0);

		Set_Box_Color(&T->Room,0.2,0.4,0.2);
		Set_Box_Size(&T->Room,1.5,1,1);
		Set_Box_Location(&T->Room,0,1,2);
		Set_Box_Rotation(&T->Room,0,0,0);

		Set_Box_Color(&T->Tank_Bound_Area,0.2,0.4,0.2);
		Set_Box_Size(&T->Tank_Bound_Area,4,2,4);
		Set_Box_Location(&T->Tank_Bound_Area,0,1,0);
		Set_Box_Rotation(&T->Tank_Bound_Area,0,0,0);

		Set_Box_Color(&T->Missile_Area,0,0,0);
		Set_Box_Size(&T->Missile_Area,15,15,15);
		Set_Box_Location(&T->Missile_Area,0,7.5,0);
		Set_Box_Rotation(&T->Missile_Area,0,0,0);

		Set_Wheel(&T->wheel[0],0.7,0.2,-1.2,0.4);
		Set_Wheel(&T->wheel[1],0.7,0.2,0,0.4);
		Set_Wheel(&T->wheel[2],0.7,0.2,1.2,0.4);
		Set_Wheel(&T->wheel[3],-0.7,0.2,-1.2,0.4);
		Set_Wheel(&T->wheel[4],-0.7,0.2,0,0.4);
		Set_Wheel(&T->wheel[5],-0.7,0.2,1.2,0.4);
	}
}
void Set_Tank_2(Tank *T,float x,float y,float z, int Type)
{
	T->Health=100;
	T->Type=Type+4;
	T->Maxspeed=0.1*GlobalSpeed;
	Set_Location(&T->location,x,y,z);
	Set_MissileLauncher(&T->ML,0,2,0,Type);
	T->ML.TankRotation=&T->rotation.y;
	T->ML.Launch_Location=&T->location;
	Set_Smoke(&T->Blow,2,0.03,1,1,1);
	T->ML.missile.Damage=MISSILE_DAMAGE;

	Set_Box_Color(&T->Body,0.2,0.4,0.2);
	Set_Box_Size(&T->Body,1.2,2,1.2);
	Set_Box_Location(&T->Body,0,1,0);
	Set_Box_Rotation(&T->Body,0,0,0);

	Set_Box_Color(&T->Room,0.2,0.4,0.2);
	Set_Box_Size(&T->Room,2,1,2);
	Set_Box_Location(&T->Room,0,0.5,0);
	Set_Box_Rotation(&T->Room,0,0,0);

	Set_Box_Color(&T->Missile_Area,0,0,0);
	Set_Box_Size(&T->Missile_Area,20,20,20);
	Set_Box_Location(&T->Missile_Area,0,10,0);
	Set_Box_Rotation(&T->Missile_Area,0,0,0);

	Set_Box_Color(&T->Tank_Bound_Area,0.2,0.4,0.2);
	Set_Box_Size(&T->Tank_Bound_Area,2,3,2);
	Set_Box_Location(&T->Tank_Bound_Area,0,1.5,0);
	Set_Box_Rotation(&T->Tank_Bound_Area,0,0,0);
}
void Draw_Tank(Tank *T)
{
	if(T->Blow.Radius!=0)
		Draw_Blow_Smoke(&T->Blow);
	if(T->ML.missile.Blow.Radius!=0)
		Draw_Blow_Smoke(&T->ML.missile.Blow);
	if(T->Health<0)return;
	if(T->Type==10)
	{
		Go_Location(T->location);
		Rotation_Open(T->rotation,0,1,0);
		Draw_Shapped_Box_Up(T->Body,-0.3,0,0.5);
		Draw_Missile_Launcher(&T->ML);
		for(int i=0;i<4;i++)
		{
			Draw_Box_TR(T->Heli[i]);
			T->Heli[i].rotation.y+=30;
			T->Heli[i].rotation.y%=360;
		}
		Rotation_Close(T->rotation,0,1,0);
		Back_Location(T->location);
	}
	else
	{
		Go_Location(T->location);
		Rotation_Open(T->rotation,0,1,0);
		Draw_Shapped_Box_Up(T->Body,-0.3,0,0.5);
		Draw_Shapped_Box_Front(T->Room,-0.3,0,0);
		Draw_Missile_Launcher(&T->ML);
		for(int i=0;i<6;i++)
			Draw_Wheel(&T->wheel[i]);
		Rotation_Close(T->rotation,0,1,0);
		Back_Location(T->location);
	}
	

	if(T->ML.missile.status!=NOT_ACTIVE)
		Draw_Missile(&T->ML.missile);

}

void Tank_Movement_2(Tank *T)
{
	MissileLauncher_Movment(&T->ML);
	Tank_Launch_Missile(T,4);

}
void Tank_Movement_1(Tank *T)
{
	if(T->Health<0)return;
	RotateUntil_Y(&T->rotation,T->location,*T->target,0);
	MissileLauncher_Movment(&T->ML);

	if(T->location.x < T->target->x)
		(T->speed.x<0 && T->speed.x < T->Maxspeed)? T->speed.x+=0.003 : T-> speed.x+=0.0001*GlobalSpeed;
	else
		(T->speed.x>0 && T->speed.x > 0-T->Maxspeed)? T->speed.x-=0.003 : T->speed.x-=0.0001*GlobalSpeed;

	if(T->location.z < T->target->z)
		(T->speed.z<0 && T->speed.z < T->Maxspeed)? T->speed.z+=0.003 : T-> speed.z+=0.0001*GlobalSpeed;
	else
		(T->speed.z>0 && T->speed.z > 0-T->Maxspeed)? T->speed.z-=0.003 : T->speed.z-=0.0001*GlobalSpeed;

	T->location.z += T->speed.z*GlobalSpeed;
	T->location.x += T->speed.x*GlobalSpeed;

	if((T->location_1.z==T->location_2.z))
		if(Distince_x(&T->location,T->target)<1)
			 Switch_Tank_Target(T);

	if((T->location_1.x==T->location_2.x))
		if(Distince_z(&T->location,T->target)<1)
			 Switch_Tank_Target(T);

	Tank_Launch_Missile(T,2);
}
void Tank_Movement(Tank *T)
{
	if(T->Health<0)return;
	if(T->Type==2||T->Type==3)
	{
		Tank_Movement_1(T);
		return;
	}
	if(T->Type==4||T->Type==5)
	{
		Tank_Movement_2(T);
		return;
	}
	if(T->Start_Tank>0)
	{
		T->location.z+=0.05;
		T->Start_Tank--;
		T->rotation.y=0;
		return;
	}
	if(T->target == nullptr)
		return ;

	RotateUntil_Y(&T->rotation,T->location,*T->target,0);
	MissileLauncher_Movment(&T->ML);

	if(T->Status==LEFT_BOUND && T->location.x<T->target->x)
		T->Status=0;
	if(T->Status==RIGHT_BOUND && T->location.x>T->target->x)
		T->Status=0;
	if(T->Status==BACK_BOUND && T->location.z<T->target->z)
		T->Status=0;
	if(T->Status==FRONT_BOUND && T->location.z>T->target->z)
		T->Status=0;

	if(T->Status!=FAR_TANK)
	{
		if(T->location.x < T->target->x)
			(T->speed.x<0 && T->speed.x < T->Maxspeed)? T->speed.x+=0.003 : T-> speed.x+=0.0001*GlobalSpeed;
		else
			(T->speed.x>0 && T->speed.x > 0-T->Maxspeed)? T->speed.x-=0.003 : T->speed.x-=0.0001*GlobalSpeed;

		if(T->location.z < T->target->z)
			(T->speed.z<0 && T->speed.z < T->Maxspeed)? T->speed.z+=0.003 : T-> speed.z+=0.0001*GlobalSpeed;
		else
			(T->speed.z>0 && T->speed.z > 0-T->Maxspeed)? T->speed.z-=0.003 : T->speed.z-=0.0001*GlobalSpeed;

		if(T->Status!=LEFT_BOUND&&Distince_x(&T->location,T->target)>10 && T->Status!=RIGHT_BOUND)
			T->location.x += T->speed.x*GlobalSpeed;
		else
		{
			T->speed.x=0;
			if(T->speed.z>0)
				T->rotation.y=0;
			else
				T->rotation.y=180;
		}
		if(T->Status!=FRONT_BOUND&&Distince_z(&T->location,T->target)>10 && T->Status!=BACK_BOUND)
			T->location.z += T->speed.z*GlobalSpeed;
		else
		{
			T->speed.z=0;
			if(T->speed.x>0)
				T->rotation.y=90;
			else
				T->rotation.y=-90;
		}
	}
	Tank_Launch_Missile(T,2);


}
void Blow_Tank(Tank *T)
{
	Copy_Location(&T->Blow.location,T->location);
	T->Blow.Radius=0.01;
	Reset_Missile(&T->ML.missile);
}
//Bullding_With_Tank
void Set_Bullding_With_Tank(Bullding_With_Tank *b, float x,float y, float z, int Type)
{
	Set_Location(&b->location,x,y,z);
	Set_MissileLauncher(&b->ML,x+2,y+10.2,z-2,Type);
	b->ML.missile.Damage=MISSILE_DAMAGE;
	Set_Tank(&b->tank,x,y,z-0.6,Type);
	Set_Sata(&b->sata,x-2,y+4.5,z+2);

	Set_Box_Color(&b->box[0],0.5,0.6,0.5);
	Set_Box_Size(&b->box[0],2,4,6);
	Set_Box_Location(&b->box[0],-3,2,0);
	Set_Box_Rotation(&b->box[0],0,0,0);
	
	Set_Box_Color(&b->box[1],0.5,0.6,0.5);
	Set_Box_Size(&b->box[1],4,6,6);
	Set_Box_Location(&b->box[1],4,3,0);
	Set_Box_Rotation(&b->box[1],0,0,0);
	
	Set_Box_Color(&b->box[2],0.4,0.5,0.4);
	Set_Box_Size(&b->box[2],8,1,7);
	Set_Box_Location(&b->box[2],0,4,0);
	Set_Box_Rotation(&b->box[2],0,0,0);
	
	Set_Box_Color(&b->box[3],0.7,0.7,0.7);
	Set_Box_Size(&b->box[3],2,10,2);
	Set_Box_Location(&b->box[3],2,5,-2);
	Set_Box_Rotation(&b->box[3],0,0,0);
	
	Set_Box_Color(&b->box[4],0.8,0.8,0.2);
	Set_Box_Size(&b->box[4],3,0.5,3);
	Set_Box_Location(&b->box[4],2,9,-2);
	Set_Box_Rotation(&b->box[4],40,0,0);
	
	Set_Box_Color(&b->box[5],0.8,0.8,0.2);
	Set_Box_Size(&b->box[5],3,0.5,3);
	Set_Box_Location(&b->box[5],2,7,-2);
	Set_Box_Rotation(&b->box[5],40,0,0);

	Set_Box_Color(&b->box[6],0,0,0);
	Set_Box_Size(&b->box[6],4,4,4);
	Set_Box_Location(&b->box[6],0,2,0);
	Set_Box_Rotation(&b->box[6],0,0,0);

	Set_Box_Color(&b->Virtual_Boxes,1,0,0);
	Set_Box_Size(&b->Virtual_Boxes,10,4.5,6);
	Set_Box_Location(&b->Virtual_Boxes,1,2.25,0);
	Set_Box_Rotation(&b->Virtual_Boxes,0,0,0);

	Set_Box_Color(&b->Missile_Area,0,0,0);
	Set_Box_Size(&b->Missile_Area,15,15,15);
	Set_Box_Location(&b->Missile_Area,0,7.5,0);
	Set_Box_Rotation(&b->Missile_Area,0,0,0);
	
}
void Draw_Bullding_With_Tank(Bullding_With_Tank *b)
{
	Go_Location(b->location);
	Draw_Shapped_Box_Up(b->box[0],-0.5,0,0);
	Draw_Shapped_Box_Up(b->box[1],-1,0,0);
	Draw_Shapped_Box_Up(b->box[2],-1,0,-0.5);
	Draw_Shapped_Box_Up(b->box[3],0,0,0);
	Draw_Shapped_Box_Up(b->box[4],0,0,0);
	Draw_Shapped_Box_Up(b->box[5],0,0,0);
	Draw_Shapped_Box_Up(b->box[6],0,0,0);
	Back_Location(b->location);

	Draw_Sata(&b->sata);
	Draw_Missile_Launcher(&b->ML);
	Draw_Tank(&b->tank);
}
void Bullding_With_Tank_Movement(Bullding_With_Tank *b)
{
	if(b->tank.target!=nullptr)
		Tank_Movement(&b->tank);
	if(b->ML.target!=nullptr)
		MissileLauncher_Movment(&b->ML);
	if(b->tank.Health<0)
	{
		b->tank.rotation.y=0;
		b->tank.target=nullptr;
		Set_Tank(&b->tank,b->location.x,b->location.y,b->location.z,b->tank.Type);
	}
}
//Street
void Set_Street(Street *S,float x,float y,float z,float sx,float sz,int RotateY)
{
	Set_Location(&S->location,x,y,z);
	Set_Rotation(&S->rotation,0,RotateY,0);

	Set_Color(&S->body.color,0,0,0);
	Set_Size(&S->body.size,sx,0.1,sz);
	Set_Location(&S->body.location,0,0.001,0);
	Set_Rotation(&S->body.rotation,0,0,0);

	Set_Color(&S->line.color,1,1,1);
	Set_Size(&S->line.size,sx-1,0.11,sz/10);
	Set_Location(&S->line.location,0,0.01,0);
	Set_Rotation(&S->line.rotation,0,0,0);
}
void Draw_Street(Street *S)
{
	Go_Location(S->location);
	Rotation_Open(S->rotation,0,1,0);
	Draw_Box_TR(S->body);
	Draw_Box_TR(S->line);
	Rotation_Close(S->rotation,0,1,0);
	Back_Location(S->location);

}
//Tree
void Set_Tree(Tree *t,float x,float y,float z)
{
	Set_Location(&t->location,x,y,z);
}
void Draw_Tree(Tree *T)
{
	
	Go_Location(T->location);
	glRotatef(-90,1,0,0);
		glColor3f(0.4,0,0);
		glTranslatef(0,0,0.25);
		glutSolidCube(0.5);
		glColor3f(0,1,0);
		glTranslatef(0,0,0.25);
		glutSolidCone(1,3,5,5);
		glTranslatef(0,0,-0.50);
	glRotatef(90,1,0,0);
	Back_Location(T->location);

}
//Cloud
void Set_Cloud(Cloud *C,float x,float y,float z)
{
	Set_Location(&C->location,x,y,z);
}
void Draw_Cloud(Cloud *C)
{
	Go_Location(C->location);
	glColor3f(1,1,1);
	glutSolidSphere(2,5,5);

	glTranslatef(1.7,-0.5,-0.2);
	glutSolidSphere(1.5,5,5);
	glTranslatef(-1.7,0.5,0.2);

	glTranslatef(-2.5,0.25,0.1);
	glutSolidSphere(1.3,5,5);
	glTranslatef(2.5,-0.25,-0.1);

	Back_Location(C->location);
}
//Helicopter
void Shoot_Bomb(Helicopter *Heli)
{
	if(Heli->user->Type!=LEVEL_3||Heli->Bombs[Heli->bomb_index].Status !=NOT_ACTIVE)return;
	if(Heli->Reload!=0||Heli->Bomb_Cnt==0)return;
	Heli->Bomb_Cnt--;
	Heli->Reload=5;
	Copy_Location(&Heli->Bombs[Heli->bomb_index].location,Heli->location);
	Heli->Bombs[Heli->bomb_index++].Status=1;
	Heli->bomb_index%=4;
}
void Reset_Bomb(Bullet *b)
{
	Copy_Location(&b->Blow.location,b->location);
	b->Status=0;
	b->Blow.Radius=0.0001;
}
void Bomb_Movement(Bullet *b)
{
	if(b->Status==NOT_ACTIVE)
		return;
	b->location.y-=0.1;
	b->Status++;
	if(b->Status==100 || b->location.y<0)Reset_Bomb(b);
}
void Calculate_Speed(Speed *speed,Location *To,Location *From,int DivideSpeed)
{
	speed->x=(To->x-From->x)/DivideSpeed;
	speed->y=(To->y-From->y)/DivideSpeed;
	speed->z=(To->z-From->z)/DivideSpeed;
}
void Shoot_Bullet(Helicopter *Heli)
{
	if(Heli->bullet[Heli->bullet_index].Status!=NOT_ACTIVE)return;
	if(Heli->Reload!=0||Heli->Bullet_Cnt==0)return;
	Heli->Bullet_Cnt--;
	Heli->Reload=5;
	Copy_Location(&Heli->bullet[Heli->bullet_index].location,Heli->location);
	Calculate_Speed(&Heli->bullet[Heli->bullet_index].speed,&Heli->aim.location,&Heli->location,5);

	Heli->bullet[Heli->bullet_index++].Status=1;
	Heli->bullet_index%=5;
}
void Shoot_Missile(Helicopter *Heli)
{
	if(Heli->user->Type==LEVEL_1||Heli->missile[Heli->missile_index].status!=NOT_ACTIVE)return;
	if(Heli->Reload!=0||Heli->Missile_Cnt==0)return;
	Heli->Missile_Cnt--;
	Heli->Reload=5;
	Heli->Shoot.Radius=0.01;
	Copy_Location(&Heli->missile[Heli->missile_index].location,Heli->location);
	RotateUntil_XY(&Heli->missile[Heli->missile_index].rotation,Heli->location,Heli->aim.location,0);
	if(Heli->rotation.y<45&&Heli->rotation.y>-45||Heli->rotation.y>115||Heli->rotation.y<-115)
	{
		if(Heli->missile_index%2==0)
		{
			Heli->missile[Heli->missile_index].location.x-=1;
			Set_Location(&Heli->Shoot.location,-1,0,0);
		}
		else
		{
			Heli->missile[Heli->missile_index].location.x+=1;
			Set_Location(&Heli->Shoot.location,1,0,0);
		}
	}
	else
	{
		if(Heli->missile_index%2==0)
		{
			Heli->missile[Heli->missile_index].location.z+=1;
			Set_Location(&Heli->Shoot.location,0,0,1);
		}
		else
		{
			Heli->missile[Heli->missile_index].location.z-=1;
			Set_Location(&Heli->Shoot.location,0,0,-1);
		}
	}
	Calculate_Speed(&Heli->missile[Heli->missile_index].speed,&Heli->aim.location,&Heli->location,10);
	Heli->missile[Heli->missile_index++].status=1;
	Heli->missile_index%=4;
}
void Bullet_Movement(Bullet *b)
{
	if(b->Status==NOT_ACTIVE)return;
	/*if(b->Status==2)
		PlaySound(TEXT("shoot.wav"), NULL, SND_FILENAME|SND_ASYNC);
	if(b->Status==98)
		PlaySound( NULL, 0,0);*/
	b->location.x+=b->speed.x;
	b->location.y+=b->speed.y;
	b->location.z+=b->speed.z;
	b->Status++;
	if(b->Status==100|| b->location.y<0)Reset_Bomb(b);
}

void Helicopter_Missile_Movemet(Missile *m)
{
	for(int i=0;i<4;i++)
		if(m->smoke[i].Radius==0)
		{
			Copy_Location(&m->smoke[i].location,m->location);
			m->smoke[i].Radius+=0.001;
		}
	if(m->status==NOT_ACTIVE)return;
	m->location.x+=m->speed.x;
	m->location.y+=m->speed.y;
	m->location.z+=m->speed.z;
	m->status++;
	if(m->status==100|| m->location.y<0)
		Reset_Missile(m);
	
}
void Draw_Bullet(Bullet *b)
{
	if(b->Status==NOT_ACTIVE)return;

	Go_Location(b->location);
	glColor3f(0,0,1);
	glutSolidSphere(b->Radius,5,5);
	Back_Location(b->location);
}
void Set_Aim(Aim *aim)
{
	Set_Box_Color(&aim->B1,10,0,0);
	Set_Box_Size(&aim->B1,0.5,0.05,0.05);
	Set_Box_Location(&aim->B1,0.5,0,0);
	Set_Box_Rotation(&aim->B1,0,0,0);

	Set_Box_Color(&aim->B2,10,0,0);
	Set_Box_Size(&aim->B2,0.5,0.05,0.05);
	Set_Box_Location(&aim->B2,-0.5,0,0);
	Set_Box_Rotation(&aim->B2,0,0,0);

	Set_Box_Color(&aim->B3,10,0,0);
	Set_Box_Size(&aim->B3,0.05,0.5,0.05);
	Set_Box_Location(&aim->B3,0,0.5,0);
	Set_Box_Rotation(&aim->B3,0,0,0);

	Set_Box_Color(&aim->B4,10,0,0);
	Set_Box_Size(&aim->B4,0.05,0.5,0.05);
	Set_Box_Location(&aim->B4,0,-0.5,0);
	Set_Box_Rotation(&aim->B4,0,0,0);
}
void Draw_Aim(Aim *aim)
{
	Go_Location(aim->location);
	Rotation_Open(aim->rotation,1,1,1);
	Draw_Box_TR(aim->B1);
	Draw_Box_TR(aim->B2);
	Draw_Box_TR(aim->B3);
	Draw_Box_TR(aim->B4);
	Rotation_Close(aim->rotation,1,1,1);
	Back_Location(aim->location);
}
void Set_Helicopter_1(Helicopter *H)
{
		Set_Box_Size(&H->Engine,0,0,0);
		Set_Box_Size(&H->Wing,0,0,0);

		Set_Box_Color(&H->Body,0.5,0.5,0.5);
		Set_Box_Size(&H->Body,0.4,0.2,1.4);
		Set_Box_Location(&H->Body,0,0.2,0);
		Set_Box_Rotation(&H->Body,0,0,0);

		Set_Box_Size(&H->UpBody,0.5,0.5,3);
		Set_Box_Location(&H->UpBody,0,0.5,0);
		Set_Box_Rotation(&H->UpBody,0,0,0);

		Set_Box_Color(&H->BackWing,0.5,0.5,0.5);
		Set_Box_Size(&H->BackWing,0.1,1,0.3);
		Set_Box_Location(&H->BackWing,0,0.8,2.0);
		Set_Box_Rotation(&H->BackWing,45,0,0);

		Set_Box_Color(&H->BackFanStick,1,1,0.5);
		Set_Box_Size(&H->BackFanStick,0.5,0.05,0.05);
		Set_Box_Location(&H->BackFanStick,0.2,1.1,2.2);
		Set_Box_Rotation(&H->BackFanStick,0,0,0);

		Set_Box_Color(&H->BackFan,1,1,1);
		Set_Box_Size(&H->BackFan,0.05,1,0.2);
		Set_Box_Location(&H->BackFan,0.3,1.1,2.2);
		Set_Box_Rotation(&H->BackFan,0,0,0);

		Set_Box_Color(&H->Roof,0.5,0.5,0.5);
		Set_Box_Size(&H->Roof,0.3,1,0.3);
		Set_Box_Location(&H->Roof,0,0.6,-0.2);
		Set_Box_Rotation(&H->Roof,0,0,0);

		Set_Box_Color(&H->FanStick,0.5,0.5,0.5);
		Set_Box_Size(&H->FanStick,0.1,1.3,0.1);
		Set_Box_Location(&H->FanStick,0,0.9,-0.2);
		Set_Box_Rotation(&H->FanStick,0,0,0);

		Set_Box_Color(&H->Fan,1,1,1);
		Set_Box_Size(&H->Fan,4,0.1,0.2);
		Set_Box_Location(&H->Fan,0,1.4,-0.2);
		Set_Box_Rotation(&H->Fan,0,0,0);	
}
void Set_Helicopter_2(Helicopter *H)
{
	Set_Box_Color(&H->Body,0.5,0.5,0.5);
	Set_Box_Size(&H->Body,0.6,0.2,2);
	Set_Box_Location(&H->Body,0,0.2,0);
	Set_Box_Rotation(&H->Body,0,0,0);

	Set_Box_Size(&H->UpBody,0.5,0.5,3);
	Set_Box_Location(&H->UpBody,0,0.5,0);
	Set_Box_Rotation(&H->UpBody,0,0,0);

	Set_Box_Color(&H->BackWing,0.5,0.5,0.5);
	Set_Box_Size(&H->BackWing,0.1,1,0.3);
	Set_Box_Location(&H->BackWing,0,0.8,2);
	Set_Box_Rotation(&H->BackWing,45,0,0);

	Set_Box_Color(&H->Engine,0.2,0.2,0.2);
	Set_Box_Size(&H->Engine,0.8,0.3,1);
	Set_Box_Location(&H->Engine,0,0.4,0);
	Set_Box_Rotation(&H->Engine,0,0,0);

	Set_Box_Color(&H->BackFanStick,1,1,0.5);
	Set_Box_Size(&H->BackFanStick,0.5,0.05,0.05);
	Set_Box_Location(&H->BackFanStick,0.2,1.1,2.2);
	Set_Box_Rotation(&H->BackFanStick,0,0,0);

	Set_Box_Color(&H->BackFan,1,1,1);
	Set_Box_Size(&H->BackFan,0.05,1,0.2);
	Set_Box_Location(&H->BackFan,0.3,1.1,2.2);
	Set_Box_Rotation(&H->BackFan,0,0,0);

	Set_Box_Color(&H->Roof,0.5,0.5,0.5);
	Set_Box_Size(&H->Roof,0.3,1,0.3);
	Set_Box_Location(&H->Roof,0,0.6,-0.2);
	Set_Box_Rotation(&H->Roof,0,0,0);

	Set_Box_Color(&H->FanStick,0.5,0.5,0.5);
	Set_Box_Size(&H->FanStick,0.1,1.3,0.1);
	Set_Box_Location(&H->FanStick,0,0.9,-0.2);
	Set_Box_Rotation(&H->FanStick,0,0,0);

	Set_Box_Color(&H->Fan,1,1,1);
	Set_Box_Size(&H->Fan,4,0.1,0.2);
	Set_Box_Location(&H->Fan,0,1.4,-0.2);
	Set_Box_Rotation(&H->Fan,0,0,0);

	Set_Box_Color(&H->Wing,1,1,1);
	Set_Box_Size(&H->Wing,2,0.25,0.5);
	Set_Box_Location(&H->Wing,0,0.25,0);
	Set_Box_Rotation(&H->Wing,0,0,0);	
}
void Set_Helicopter(Helicopter *H,float x,float y ,float z,int X_Or_O,char *User_Name)
{
	H->user=Get_User(User_Name);
	H->FanSpeed=30;
	Set_Location(&H->location,x,y,z);
	Set_Speed(&H->speed,0,0,0);
	Set_Smoke(&H->Shoot,0.5,0.02,0.7,0.7,0.7);
	Set_Smoke(&H->Blow,6,0.04,0.7,0.7,0.7);
	H->Shoot.Radius=0;
	H->fuel=100;
	H->CameraZ=10;
	H->CameraY=2;
	H->CameraX=2;
	H->LookAround_X=0;
	H->LookAround_Y=0;
	H->Shake=0;
	H->Ready=0;
	H->aim.UPDown=0;
	Set_Aim(&H->aim);
	Set_Rotation(&H->rotation,0,0,0);
	for(int i=0;i<4;i++)
		H->missile[i].Damage=H->user->Missile_Damage*MISSILE_DAMAGE;
	for(int i=0;i<4;i++)
	{
		H->Bombs[i].Radius=0.3;
		Set_Box_Size(&H->Bombs[i].Bound,0.6,0.6,0.6);
		Set_Smoke(&H->Bombs[i].Blow,2,0.02,1,1,1);
		H->Bombs[i].Damage=(BOMB_DAMAGE*H->user->Bomb_Damage);
	}
	for(int i=0;i<5;i++)
	{
		H->bullet[i].Radius=0.1;
		Set_Box_Size(&H->bullet[i].Bound,0.2,0.2,0.2);
		Set_Smoke(&H->bullet[i].Blow,0.5,0.01,1,1,1);
		H->bullet[i].Damage=(BULLET_DAMAGE*H->user->Bullet_Damage);
	}
	if(H->user->Type==LEVEL_1)
		H->Health=100;
	if(H->user->Type==LEVEL_2)
		H->Health=150;
	if(H->user->Type==LEVEL_3)
		H->Health=200;
	if(H->user->Type==LEVEL_1||H->user->Type==LEVEL_2){
		Set_Box_Size(&H->BoundArea,0.5,1.5,3);
		Set_Box_Location(&H->BoundArea,0,0.6,0);
	}
	if(H->user->Type==LEVEL_3){
		Set_Box_Size(&H->BoundArea,2,3,2);
		Set_Box_Location(&H->BoundArea,0,0,0);
	}
	Set_Missile(&H->missile[0],1,0,0,1);
	Set_Missile(&H->missile[1],1,0,0,1);
	Set_Missile(&H->missile[2],-1,0,0,1);
	Set_Missile(&H->missile[3],-1,0,0,1);
	
	if(X_Or_O==0){
		Set_Box_Color(&H->UpBody,0,0,1);
		Set_Box_Color(&H->Robot[0],0,0,1);
	}
	if(X_Or_O==1){
		Set_Box_Color(&H->UpBody,1,0,0);
		Set_Box_Color(&H->Robot[0],1,0,0);
	}
	if(H->user->Type==LEVEL_1)
		Set_Helicopter_1(H);
	if(H->user->Type==LEVEL_2)
		Set_Helicopter_2(H);

	Set_Box_Size(&H->Robot[0],1.5,1.5,0.5);
	Set_Box_Location(&H->Robot[0],0,0,0);
	Set_Box_Rotation(&H->Robot[0],0,0,180);

	Set_Box_Color(&H->Robot[1],2,0,1);
	Set_Box_Size(&H->Robot[1],0.3,1,0.3);
	Set_Box_Location(&H->Robot[1],0,1,0);
	Set_Box_Rotation(&H->Robot[1],0,0,0);

	Set_Box_Color(&H->Robot[2],1,1,1);
	Set_Box_Size(&H->Robot[2],0.6,0.6,0.6);
	Set_Box_Location(&H->Robot[2],0,1.5,0);
	Set_Box_Rotation(&H->Robot[2],0,0,0);

	Set_Box_Color(&H->Robot[3],0,0,0);
	Set_Box_Size(&H->Robot[3],0.8,0.4,0.8);
	Set_Box_Location(&H->Robot[3],0,1.4,0.2);
	Set_Box_Rotation(&H->Robot[3],180,0,0);

	Set_Box_Color(&H->Robot[4],1,1,0);
	Set_Box_Size(&H->Robot[4],0.1,1,0.1);
	Set_Box_Location(&H->Robot[4],0.2,1.5,0);
	Set_Box_Rotation(&H->Robot[4],10,0,-30);

	Set_Box_Color(&H->Robot[5],1,1,0);
	Set_Box_Size(&H->Robot[5],0.1,1,0.1);
	Set_Box_Location(&H->Robot[5],-0.2,1.5,0);
	Set_Box_Rotation(&H->Robot[5],10,0,30);

	Set_Box_Color(&H->Robot[6],0.3,0.3,0.3);
	Set_Box_Size(&H->Robot[6],0.5,1,0.5);
	Set_Box_Location(&H->Robot[6],0.5,-1,-0.2);
	Set_Box_Rotation(&H->Robot[6],210,0,0);

	Set_Box_Color(&H->Robot[7],0.3,0.3,0.3);
	Set_Box_Size(&H->Robot[7],0.5,1,0.5);
	Set_Box_Location(&H->Robot[7],-0.5,-1,-0.2);
	Set_Box_Rotation(&H->Robot[7],210,0,0);

	Set_Box_Color(&H->Robot[8],0.3,0.3,0.3);
	Set_Box_Size(&H->Robot[8],0.5,1,0.5);
	Set_Box_Location(&H->Robot[8],0.5,-1,0.2);
	Set_Box_Rotation(&H->Robot[8],-210,0,0);

	Set_Box_Color(&H->Robot[9],0.3,0.3,0.3);
	Set_Box_Size(&H->Robot[9],0.5,1,0.5);
	Set_Box_Location(&H->Robot[9],-0.5,-1,0.2);
	Set_Box_Rotation(&H->Robot[9],-210,0,0);
		
	Set_Box_Color(&H->Robot[10],0.3,0.3,0.3);
	Set_Box_Size(&H->Robot[10],0.7,1,0.5);
	Set_Box_Location(&H->Robot[10],0,1,0.2);
	Set_Box_Rotation(&H->Robot[10],-30,0,0);

	Set_Box_Color(&H->Robot[11],0.3,0.3,1);
	Set_Box_Size(&H->Robot[11],2.5,0.5,0.1);
	Set_Box_Location(&H->Robot[11],0.5,0,0.5);
	Set_Box_Rotation(&H->Robot[11],-30,0,-70);

	Set_Box_Color(&H->Robot[12],0.3,0.3,1);
	Set_Box_Size(&H->Robot[12],2.5,0.5,0.1);
	Set_Box_Location(&H->Robot[12],-0.5,0,0.5);
	Set_Box_Rotation(&H->Robot[12],-30,0,70);

	Set_Box_Color(&H->Robot[13],1,0.3,0);
	Set_Box_Size(&H->Robot[13],2,0.51,0.1);
	Set_Box_Location(&H->Robot[13],1,0,0.5);
	Set_Box_Rotation(&H->Robot[13],-35,0,-45);

	Set_Box_Color(&H->Robot[14],1,0.3,0);
	Set_Box_Size(&H->Robot[14],2,0.51,0.1);
	Set_Box_Location(&H->Robot[14],-1,0,0.5);
	Set_Box_Rotation(&H->Robot[14],-35,0,45);

	Set_Box_Color(&H->Robot[15],0.3,0.3,0.3);
	Set_Box_Size(&H->Robot[15],0.5,0.5,1.5);
	Set_Box_Location(&H->Robot[15],0.8,0.5,0);
	Set_Box_Rotation(&H->Robot[15],-25,0,45);

	Set_Box_Color(&H->Robot[16],0.3,0.3,0.3);
	Set_Box_Size(&H->Robot[16],0.5,0.5,1.5);
	Set_Box_Location(&H->Robot[16],-0.8,0.5,0);
	Set_Box_Rotation(&H->Robot[16],-25,0,45);

	Set_Box_Color(&H->Robot[17],0,0,1);
	Set_Box_Size(&H->Robot[17],0.2,1,0.2);
	Set_Box_Location(&H->Robot[17],0,0.1,-0.2);
	Set_Box_Rotation(&H->Robot[17],0,0,0);

	Set_Smoke(&H->RobotSmoke[0],0.4,0.01,1,0,0);
	Set_Smoke(&H->RobotSmoke[1],0.4,0.01,1,1,0);
	Set_Smoke(&H->RobotSmoke[2],0.4,0.01,1,1,0);
	Set_Smoke(&H->RobotSmoke[3],0.4,0.01,1,0,0);
	Set_Smoke(&H->RobotSmoke[4],0.4,0.01,1,0,0);
}
void Draw_Helicopter(Helicopter *H)
{	
	H->Fan.rotation.y+=H->FanSpeed;
	H->Fan.rotation.y%=360;
	H->BackFan.rotation.x+=H->FanSpeed;
	H->BackFan.rotation.x%=360;
	Go_Location(H->location);
	Rotation_Open(H->rotation,0,0,0);
	glRotatef(H->LookAround_X,1,0,0);
	glRotatef(H->LookAround_Y,0,1,0);

	Draw_Shapped_Box_Up(H->Body,0,0,0.2);
	Draw_Shapped_Box_Up(H->UpBody,-0.1,0,-0.2);
	if(H->Shoot.Radius!=0)
		Draw_Smoke(&H->Shoot,0);
	Draw_Box_TR(H->BackWing);
	Draw_Box_TR(H->BackFanStick);
	Draw_Box_TR(H->BackFan);
	Draw_Box_TR(H->Roof);
	Draw_Box_TR(H->Engine);
	Draw_Box_TR(H->FanStick);
	Draw_Shapped_Box_Up(H->Fan,-0.2,0,0);
	Draw_Shapped_Box_Up(H->Wing,-0.5,0,0);
	if(H->MyXo!=nullptr)
		Draw_XO_Box(H->MyXo);
	Rotation_Close(H->rotation,0,1,0);
	Rotation_Close(H->rotation,1,0,1);
	Back_Location(H->location);
	glColor3f(0,0,0);
	glTranslatef(H->location.x,0.2,H->location.z);
	Rotation_Open(H->rotation,0,1,0);
	glBegin(GL_QUADS);
	glVertex3f(0.5,0,1.5);
	glVertex3f(0.5,0,-1.5);
	glVertex3f(-0.5,0,-1.5);
	glVertex3f(-0.5,0,1.5);
	glEnd();
	Rotation_Close(H->rotation,0,1,0);
	glTranslatef(-H->location.x,-0.2,-H->location.z);

}
void Draw_Robot(Helicopter *H)
{

	for (int i=0;i<5;i++){
		if(H->RobotSmoke[i].Radius==0)H->RobotSmoke[i].Radius=0.1;
	}
	
	Go_Location(H->location);
	Rotation_Open(H->rotation,0,0,0);
	glRotatef(H->LookAround_X,1,0,0);
	glRotatef(H->LookAround_Y,0,1,0);
	glTranslatef(0,0.3,0.8);
	glRotatef(-40,1,0,0);
	glScalef(0.5,4,0.5);
	Draw_Smoke(&H->RobotSmoke[0],0);
	glScalef(2,0.25,2);
	glRotatef(40,1,0,0);
	glTranslatef(0,-0.3,-0.8);

	glTranslatef(0.2,-0.8,0);
	glScalef(0.5,4,0.5);
	Draw_Smoke(&H->RobotSmoke[1],0);
	glScalef(2,0.25,2);
	glTranslatef(-0.2,0.8,0);

	glTranslatef(-0.2,-0.8,0);
	glScalef(0.5,4,0.5);
	Draw_Smoke(&H->RobotSmoke[2],0);
	glScalef(2,0.25,2);
	glTranslatef(0.2,0.8,0);

	glTranslatef(0.2,-0.8,0);
	glScalef(2,1,2);
	Draw_Smoke(&H->RobotSmoke[3],0);
	glScalef(0.5,1,0.5);
	glTranslatef(-0.2,0.8,0);

	glTranslatef(-0.2,-0.8,0);
	glScalef(2,1,2);
	Draw_Smoke(&H->RobotSmoke[4],0);
	glScalef(0.5,1,0.5);
	glTranslatef(0.2,0.8,0);
	Draw_Shapped_Box_Up(H->Robot[0],-0.4,0,0.2);
	Draw_Box_TR(H->Robot[1]);
	Draw_Box_TR(H->Robot[2]);
	Draw_Shapped_Box_Up(H->Robot[3],0.2,0,0.2);
	Draw_Box_TR(H->Robot[4]);
	Draw_Box_TR(H->Robot[5]);
	Draw_Box_TR(H->Robot[10]);
	Draw_Shapped_Box_Up(H->Robot[11],0.2,0,0);
	Draw_Shapped_Box_Up(H->Robot[12],0.2,0,0);
	Draw_Shapped_Box_Up(H->Robot[13],0.2,0,0);
	Draw_Shapped_Box_Up(H->Robot[14],0.2,0,0);
	Draw_Box_TR(H->Robot[15]);
	Draw_Box_TR(H->Robot[16]);
	Draw_Shapped_Box_Up(H->Robot[17],0.3,0,0);

	if(H->MyXo!=nullptr)
		Draw_XO_Box(H->MyXo);
	Rotation_Close(H->rotation,0,1,0);
	Rotation_Close(H->rotation,1,0,1);
	Back_Location(H->location);

	
	glColor3f(0,0,0);
	glTranslatef(H->location.x,0.2,H->location.z);
	Rotation_Open(H->rotation,0,1,0);
	glBegin(GL_QUADS);
	glVertex3f(1,0,1);
	glVertex3f(1,0,-1);
	glVertex3f(-1,0,-1);
	glVertex3f(-1,0,1);
	glEnd();
	Rotation_Close(H->rotation,0,1,0);
	glTranslatef(-H->location.x,-0.2,-H->location.z);
}
void Draw_Player(Helicopter *H)
{
	Draw_Square(0,4.5,6,1,1,1);
	Draw_String_int(0,0,0,-2.8,1.6,-2.9,"Health : %d",H->Health);
	Draw_String_float(0,0,0,-2.8,1.5,-2.9,"High : %2.2f",H->location.y);
	Draw_String_float(0,0,0,-2.2,1.6,-2.9,"Fuel : %2.2f",H->fuel);
	Draw_String(0,0,0,-1.6,1.6,-2.9,H->user->User_Name);
	if(H->MyXo!=nullptr)
		Draw_String_float(1,0,0,-2.2,1.5,-2.9,"Catched %d",H->MyXo->Status);
	Draw_String_int(1,0,0,0,1.5,-2.9,"Coin's : %d ",H->Coins);
	Draw_String_int(1,0,0,0,1.6,-2.9,"Bullets : %d ",H->Bullet_Cnt);
	Draw_String_int(1,0,0,0.5,1.6,-2.9,"Missiles : %d ",H->Missile_Cnt);
	Draw_String_int(1,0,0,1.1,1.6,-2.9,"Bombs : %d ",H->Bomb_Cnt);
	if(H->Ready==0)	
		Draw_String(0,0,1,1.2,1.5,-2.9,"Press X To Start ESC To Exit With Draw");
	glTranslatef(-(H->location.x+H->CameraX),-(H->location.y+H->CameraY),-(H->location.z+H->CameraZ));
	
	if(H->Health>0)
	{
		if(H->user->Type==LEVEL_1 || H->user->Type==LEVEL_2)
			Draw_Helicopter(H);
		if(H->user->Type==LEVEL_3)
			Draw_Robot(H);
		Draw_Aim(&H->aim);
	}
	else
	{
		Go_Location(H->location);
		Rotation_Close(H->rotation,0,1,0);
		Back_Location(H->location);
	}

	for(int i=0;i<5;i++){
		if(H->bullet[i].Blow.Radius!=0)
			Draw_Blow_Smoke(&H->bullet[i].Blow);
		Draw_Bullet(&H->bullet[i]);
	}
	for(int i=0;i<4;i++)
	{
		if(H->missile[i].Blow.Radius!=0)
			Draw_Blow_Smoke(&H->missile[i].Blow);
		if(H->missile[i].status!=NOT_ACTIVE)
			Draw_Missile(&H->missile[i]);

		if(H->Bombs[i].Blow.Radius!=0)
			Draw_Blow_Smoke(&H->Bombs[i].Blow);
		Draw_Bullet(&H->Bombs[i]);
	}
	if(H->Blow.Radius!=0)
		Draw_Blow_Smoke(&H->Blow);
}
void Draw_Wainting_Player(Helicopter *H)
{
	if(H->user->Type==0|| H->user->Type==1)
		Draw_Helicopter(H);
	if(H->user->Type==2)
		Draw_Robot(H);
}
void Helicopter_Movement(Helicopter *H)
{
	if(H->Health<=0)
		return;
	if(H->user->Type==LEVEL_1||H->user->Type==LEVEL_2)
	{
		if(H->rotation.y<10&&H->rotation.y>-10||H->rotation.y>170||H->rotation.y<-170)
				Set_Box_Size(&H->BoundArea,0.5,1.5,3);
		else if(H->rotation.y<100&&H->rotation.y>80||H->rotation.y>-100&&H->rotation.y<-80)
				Set_Box_Size(&H->BoundArea,3,1.5,0.5);
		else
			Set_Box_Size(&H->BoundArea,2,1.5,2);
	}
	if(H->Reload>0)H->Reload--;
	if(H->Ready==NOT_READY)return;
	H->fuel-=0.05;
	if(H->Shake>0)
	{
		if(H->Shake%2==0)H->location.x+=0.5;
		else H->location.x-=0.5;
		H->Shake--;
	}
	Set_Location(&H->aim.location,
		H->location.x+5*(sin((PI*(H->rotation.y+180))/180)),
		H->location.y+H->aim.UPDown,
		H->location.z+5*(cos((PI*(H->rotation.y+180))/180)));
	RotateUntil_Y(&H->aim.rotation,H->aim.location,H->location,0);

	if(H->Status==LEFT_BOUND)
	{			
		H->Health-=5;
		H->speed.x*=-1;
		H->rotation.z*=-1;
		H->rotation.z/=2;
		H->location.x+=0.1;
	}
	if(H->Status==RIGHT_BOUND)
	{
		H->Health-=5;
		H->speed.x*=-1;
		H->rotation.z*=-1;
		H->rotation.z/=2;
		H->location.x-=0.1;
	}
	if(H->Status==BACK_BOUND)
	{
		H->Health-=5;
		H->speed.z*=-1;
		H->rotation.x*=-1;
		H->rotation.x/=2;
		H->location.z+=0.1;
	}
	if( H->Status==FRONT_BOUND)
	{
		H->Health-=5;
		H->speed.z*=-1;
		H->rotation.x*=-1;
		H->rotation.x/=2;
		H->location.z-=0.1;
	}
	if(H->Status==DAWN_BOUND)
	{
		H->location.y+=0.1;
		H->FanSpeed=30;
	}
	if(H->Status==UP_BOUND)
	{
		H->Health-=5;
		H->location.y-=0.1;
		H->FanSpeed=30;
	}
	
	if(H->rotation.z<0){
		if(H->speed.x<=0.2)(H->speed.x>0)?H->speed.x+=(H->rotation.z*-0.01*GlobalSpeed)/100:H->speed.x+=(H->rotation.z*-0.01*GlobalSpeed)/50;
	}else{
		if(H->speed.x>-0.2)(H->speed.x<0)?H->speed.x+=(H->rotation.z*-0.01*GlobalSpeed)/100:H->speed.x+=(H->rotation.z*-0.01*GlobalSpeed)/50;
	}
	if(H->rotation.x<0)
	{
		if(H->speed.z>=-0.2)(H->speed.z>0)?H->speed.z+=(H->rotation.x*0.01*GlobalSpeed)/50:H->speed.z+=(H->rotation.x*0.01*GlobalSpeed)/100;
	}else{
		if(H->speed.z<0.2)(H->speed.z<0)?H->speed.z+=(H->rotation.x*0.01*GlobalSpeed)/50:H->speed.z+=(H->rotation.x*0.01*GlobalSpeed)/100;
	}
	H->location.y+=(H->FanSpeed-30)*0.01*GlobalSpeed;
	H->location.z+=H->speed.z*GlobalSpeed*0.5;
	H->location.x+=H->speed.x*GlobalSpeed*0.5;
	for(int i=0;i<5;i++)
		Bullet_Movement(&H->bullet[i]);
	for(int i=0;i<4;i++)
		Helicopter_Missile_Movemet(&H->missile[i]);
	for(int i=0;i<4;i++)
		Bomb_Movement(&H->Bombs[i]);
}
void MoveLeft(Helicopter *H)
{
	if(H->rotation.z<10)
		H->rotation.z+=1;
}
void MoveRight(Helicopter *H)
{
	if(H->rotation.z>-10)
		H->rotation.z-=1;
}
void MoveForWord(Helicopter *H)
{
	if(H->rotation.x>-10)
		H->rotation.x-=1;
} 
void MoveBack(Helicopter *H)
{
	if(H->rotation.x<10)
		H->rotation.x+=1;
}
void Throw_Xo(Helicopter *H)
{
	if(H->MyXo==nullptr)return;
	H->MyXo->Status=FALLEN;
	Copy_Location(&H->MyXo->location,H->location);
	H->MyXo=nullptr;
}
//Bounds
int BoundFunc(Box B1 ,Location L1,Box B2,Location L2)
{
	Add_Location(&B1.location,L1);
	Add_Location(&B2.location,L2);	
	if(B1.location.x>(B2.location.x-B2.size.x/2-B1.size.x/2) && B1.location.x<(B2.location.x+B2.size.x/2+B1.size.x/2))
		if(B1.location.y>(B2.location.y-B2.size.y/2-B1.size.y/2) && B1.location.y<(B2.location.y+B2.size.y/2+B1.size.y/2))
			if(B1.location.z>(B2.location.z-B2.size.z/2-B1.size.z/2) && B1.location.z<(B2.location.z+B2.size.z/2+B1.size.z/2))
				return 1;
	return 0;
}
int Bound_Status(Box B1,Location L1,Box B2,Location L2)
{
	Add_Location(&B1.location,L1);
	Add_Location(&B2.location,L2);
		float Loc1,Loc2;
		if(B1.location.z>B2.location.z-(B2.size.z/2+B1.size.z/2) && B1.location.z<B2.location.z+(B2.size.z/2+B1.size.z/2))
		{
			if(B1.location.x>B2.location.x-(B2.size.x/2+B1.size.x/2) && B1.location.x<B2.location.x+(B2.size.x/2+B1.size.x/2))
			{
				 Loc1=(B1.location.y-B1.size.y/2);
				 Loc2=(B2.location.y+B2.size.y/2);
				 if(Loc1<Loc2 && Loc1>Loc2-BOUND_DISTANCE)
					return DAWN_BOUND;

				 Loc1=(B1.location.y+B1.size.y/2);
				 Loc2=(B2.location.y-B2.size.y/2);
				 if(Loc1>Loc2 && Loc1<Loc2+BOUND_DISTANCE)
					return UP_BOUND;
			}
		}
		if(B1.location.y>B2.location.y-(B2.size.y/2+B1.size.y/2) && B1.location.y<B2.location.y+(B2.size.y/2+B1.size.y/2))
		{
			if(B1.location.z>B2.location.z-(B2.size.z/2+B1.size.z/2)&&B1.location.z<B2.location.z+(B2.size.z/2+B1.size.z/2))
			{
				 Loc1=(B1.location.x-B1.size.x/2);
				 Loc2=(B2.location.x+B2.size.x/2);
				if(Loc1<Loc2 && Loc1>Loc2-BOUND_DISTANCE)
					return LEFT_BOUND;

				 Loc1=(B1.location.x+B1.size.x/2);
				 Loc2=(B2.location.x-B2.size.x/2);
				if(Loc1>Loc2 && Loc1<Loc2+BOUND_DISTANCE)
					return RIGHT_BOUND;
			}
			if(B1.location.x>B2.location.x-(B2.size.x/2+B1.size.x/2) &&B1.location.x<B2.location.x+(B2.size.x/2+B1.size.x/2))
			{
				 Loc1=(B1.location.z-B1.size.z/2);
				 Loc2=(B2.location.z+B2.size.z/2);
				if(Loc1<Loc2 && Loc1>Loc2-BOUND_DISTANCE)
					return BACK_BOUND;

				 Loc1=(B1.location.z+B1.size.z/2);
				 Loc2=(B2.location.z-B2.size.z/2);
				if(Loc1>Loc2 && Loc1<Loc2+BOUND_DISTANCE)
					return FRONT_BOUND;
			}
		}
		return 0;
}
int Bound_Status_Box(Box B1,Location L1,Box B2)
{
	Add_Location(&B1.location,L1);
		float Loc1,Loc2;
		if(B1.location.z>B2.location.z-(B2.size.z/2+B1.size.z/2) && B1.location.z<B2.location.z+(B2.size.z/2+B1.size.z/2))
		{
			if(B1.location.x>B2.location.x-(B2.size.x/2+B1.size.x/2) && B1.location.x<B2.location.x+(B2.size.x/2+B1.size.x/2))
			{
				 Loc1=(B1.location.y-B1.size.y/2);
				 Loc2=(B2.location.y+B2.size.y/2);
				 if(Loc1<Loc2 && Loc1>Loc2-BOUND_DISTANCE)
					return DAWN_BOUND;

				 Loc1=(B1.location.y+B1.size.y/2);
				 Loc2=(B2.location.y-B2.size.y/2);
				 if(Loc1>Loc2 && Loc1<Loc2+BOUND_DISTANCE)
					return UP_BOUND;
			}
		}
		if(B1.location.y>B2.location.y-(B2.size.y/2+B1.size.y/2) && B1.location.y<B2.location.y+(B2.size.y/2+B1.size.y/2))
		{
			if(B1.location.z>B2.location.z-(B2.size.z/2+B1.size.z/2)&&B1.location.z<B2.location.z+(B2.size.z/2+B1.size.z/2))
			{
				 Loc1=(B1.location.x-B1.size.x/2);
				 Loc2=(B2.location.x+B2.size.x/2);
				if(Loc1<Loc2 && Loc1>Loc2-BOUND_DISTANCE)
					return LEFT_BOUND;

				 Loc1=(B1.location.x+B1.size.x/2);
				 Loc2=(B2.location.x-B2.size.x/2);
				if(Loc1>Loc2 && Loc1<Loc2+BOUND_DISTANCE)
					return RIGHT_BOUND;
			}
			if(B1.location.x>B2.location.x-(B2.size.x/2+B1.size.x/2) &&B1.location.x<B2.location.x+(B2.size.x/2+B1.size.x/2))
			{
				 Loc1=(B1.location.z-B1.size.z/2);
				 Loc2=(B2.location.z+B2.size.z/2);
				if(Loc1<Loc2 && Loc1>Loc2-BOUND_DISTANCE)
					return BACK_BOUND;

				 Loc1=(B1.location.z+B1.size.z/2);
				 Loc2=(B2.location.z-B2.size.z/2);
				if(Loc1>Loc2 && Loc1<Loc2+BOUND_DISTANCE)
					return FRONT_BOUND;
			}
		}
		return 0;
}
int Bound_Helicopter_Tank(Helicopter *H,Tank *T)
{
	if(T->Health<0)return 0;
	if(Bound_Status(H->BoundArea,H->location,T->Tank_Bound_Area,T->location))
	{
		T->Health=-1;
		H->Shake=30;
		H->Health-=50;
		Blow_Tank(T);
		return 0;
	}
	if(T->Start_Tank==0 && T->ML.missile.status==0 && Bound_Status(H->BoundArea,H->location,T->Missile_Area,T->location))
	{
		T->ML.missile.target=&H->location;
		T->ML.missile.status=1;
		T->ML.missile.Helicopter_target=H;
		T->ML.target=&H->location;
		if(T->Type!=2&&T->Type!=3)
			T->target=&H->location;
		return 1;
	}
	return 0;
}
void Bound_Helicopter_Build(Helicopter *H,Bullding_With_Tank *B)
{
	if(Bound_Helicopter_Tank(H,&B->tank))
		B->tank.target=&H->location;
	if(B->ML.missile.status==0 && Bound_Status(H->BoundArea,H->location,B->Missile_Area,B->location))
	{
		B->ML.missile.target=&H->location;
		B->ML.missile.status=1;
		B->ML.missile.Helicopter_target=H;
		B->ML.target=&H->location;
		B->tank.target=&H->location;
	}
	H->Status=Bound_Status(H->BoundArea,H->location,B->Virtual_Boxes,B->location);
	if(H->Status)return;
	H->Status=Bound_Status(H->BoundArea,H->location,B->box[3],B->location);
	if(H->Status)return;
	H->Status=Bound_Status(H->BoundArea,H->location,B->box[1],B->location);
}
void Bound_Helicopter_Bridge(Helicopter *H,Bridge *B)
{
	for(int i=0;i<B->Size;i++)
	{
		H->Status=Bound_Status(H->BoundArea,H->location,B->Roof[i],B->location);
		if(H->Status)return;
		H->Status=Bound_Status(H->BoundArea,H->location,B->Base[i],B->location);
		if(H->Status)return;
	}
}
void Bound_Helicopter_Building(Helicopter *H,Building *B)
{
	for(int i=0;i<B->Size;i++)
	{
		H->Status=Bound_Status(H->BoundArea,H->location,B->arr[i],B->location);
		if(H->Status && B->Type==Map_4_Build_2)
			H->Health=-1;
		
		if(H->Status)return;
	}
}
void Bound_Helicopter_Bonus(Helicopter *H,Bonus *B)
{
	if(BoundFunc(H->BoundArea,H->location,B->Bound,B->location))
	{
		if(B->Type==0)
			H->Bullet_Cnt+=10;
		if(B->Type==1)
			H->Missile_Cnt+=5;
		if(B->Type==2)
			H->Bomb_Cnt+=5;
		if(B->Type==3)
			H->Coins+=20;
		if(B->Type==4)
			H->fuel+=100;
		B->location.y+=150;
		B->Status=FALLEN;
	}
}
void Bound_Helicopter_Trailer(Helicopter *H,Trailer *T)
{
	if(Bound_Status(H->BoundArea,H->location,T->B1,T->location))
		H->Health=-1;
	if(T->Type==1 || T->Type==2)
	if(T->ML.missile.status==0 && Bound_Status(H->BoundArea,H->location,T->Missile_Area,T->location))
	{
		T->ML.missile.target=&H->location;
		T->ML.missile.status=1;
		T->ML.missile.Helicopter_target=H;
		T->ML.target=&H->location;
	}
}
void Bound_Helicopter_Gun(Helicopter *H,Gun *G)
{
	if(G->Health<=0)
		return;
	if(BoundFunc(H->BoundArea,H->location,G->Bound_Area,G->location))
	{
		H->Health=-1;
		return;
	}
	if(BoundFunc(H->BoundArea,H->location,G->Gun_Area,G->location))
	{
		G->target=&H->location;
		G->Heli=H;
		G->Status=1;
	}
	else
		G->Status=0;
}

void Bound_Helicopter_XO_Table(Helicopter *H,XO_Table *B)
{
	H->Status=Bound_Status(H->BoundArea,H->location,B->Body,B->location);
	if(H->Status)return;
	
	for(int i=0;i<10;i++)
	{
		H->Status=Bound_Status(H->BoundArea,H->location,B->Stand[i],B->location);
		if(H->Status)return;
	}
}
void Bound_Tank_Tank(Tank *T1,Tank *T2)
{
	if(BoundFunc(T1->Tank_Bound_Area,T1->location,T2->Tank_Bound_Area,T2->location))
	{
		if(T1->target==nullptr||T2->target==nullptr)return;
		float Dis1=abs(sqrt(pow((T1->location.x-T1->target->x),2)+pow((T1->location.z-T1->target->z),2)));
		float Dis2=abs(sqrt(pow((T2->location.x-T2->target->x),2)+pow((T2->location.z-T2->target->z),2)));
		if(Dis1>Dis2)
		{
			T1->speed.x=T1->speed.z=0;
			T1->Status=8;
			T2->Status=7;
		}
		else
		{
			T2->speed.x=T2->speed.z=0;
			T1->Status=7;
			T2->Status=8;
		}
	}
	else
		T1->Status=T2->Status=0;
}
void Bound_Tank_Build_With_Tank(Tank *T,Bullding_With_Tank *B)
{
	if(T!=&B->tank)Bound_Tank_Tank(T,&B->tank);
	if(T->Status)return;
	T->Status=Bound_Status(T->Tank_Bound_Area,T->location,B->Virtual_Boxes,B->location);
}
void Bound_Tank_Bridge(Tank *T,Bridge *B)
{
	for(int i=0;i<B->Size;i++)
	{
		T->Status=Bound_Status(T->Tank_Bound_Area,T->location,B->Base[i],B->location);
		if(T->Status)return;
	}
}
void Bound_Tank_Building(Tank *H,Building *B)
{
	if(B->Type==4)
	{
		H->Status=Bound_Status(H->Tank_Bound_Area,H->location,B->arr[0],B->location);
		if(H->Status)return;
		H->Status=Bound_Status(H->Tank_Bound_Area,H->location,B->arr[1],B->location);
		if(H->Status)return;
	}
	else
	{
		H->Status=Bound_Status(H->Tank_Bound_Area,H->location,B->Tank_Bound,B->location);
		if(H->Status)return;
	}
}
void Bound_Tank_Train(Tank *tank,Train *T)
{
	for(int i=0;i<10;i++)
	{
		if(BoundFunc(tank->Tank_Bound_Area,tank->location,T->trailer[i].B1,T->trailer[i].location))
		{
			tank->Health=-1;
			Blow_Tank(tank);
			return;
		}
	}
}
void Bound_Helicopter_XOBox(Helicopter *H , XO *xo)
{
	if(H->MyXo != nullptr || xo->Status==FALLEN || xo->Status==HIDE)
		return;
	if(BoundFunc(H->BoundArea,H->location,xo->Body,xo->location))
	{
		H->MyXo=xo;
		xo->Status=CATCHED;
		Set_Location(&xo->location,0,-0.3,1);
		Set_Location(&xo->Body.location,0,0.2,0);
		Set_Location(&xo->Body1.location,0,0.2,0);
		Set_Rotation(&xo->Body.rotation,0,0,0);
		Set_Rotation(&xo->Body1.rotation,0,0,0);
	}
}
void Bound_Tank_Gun(Tank *T,Gun *G)
{
	T->Status=Bound_Status(T->Tank_Bound_Area,T->location,G->Bound_Area,G->location);
	if(T->Status)return;
}
void Bound_XOBox_Bridge(XO *xo,Bridge *bri)
{
	if(xo->Status != FALLEN) return;
	for(int i=0;i< bri->Size;i++)
	{
		xo->Status=Bound_Status(xo->Body,xo->location,bri->Roof[i],bri->location);
		if(xo->Status==0)xo->Status=FALLEN;
		if(xo->Status==DAWN_BOUND)return;
	}
}
void Bound_XOBox_Building(XO *xo,Building *B)
{
	if(xo->Status != FALLEN) return;
	for(int i=0;i< B->Size;i++)
	{
		xo->Status=Bound_Status(xo->Body,xo->location,B->arr[i],B->location);
		if(xo->Status==0)xo->Status=FALLEN;
		if(xo->Status==DAWN_BOUND)return;
	}
}
void Bound_XOBox_Build_With_Tank(XO *xo,Bullding_With_Tank *B)
{
	if(xo->Status != FALLEN) return;
	xo->Status=Bound_Status(xo->Body,xo->location,B->Virtual_Boxes,B->location);
	if(xo->Status==0)xo->Status=FALLEN;
	if(xo->Status==DAWN_BOUND)return;
	xo->Status=Bound_Status(xo->Body,xo->location,B->box[3],B->location);
	if(xo->Status==0)xo->Status=FALLEN;
	if(xo->Status==DAWN_BOUND)return;
	xo->Status=Bound_Status(xo->Body,xo->location,B->box[1],B->location);
	if(xo->Status==0)xo->Status=FALLEN;
}
int Bound_XOBox_Table(XO *xo,XO_Table *table)
{
	if(xo->Status != FALLEN) return 0;
	for(int i=0;i< 9;i++)
	{
		if(BoundFunc(xo->Body,xo->location,table->arr[i],table->location) && table->arr[i].color.g==1)
		{
			if(xo->X_Or_O==BLUE_X)
				Set_Color(&table->arr[i].color,0,0,1);
			else
				Set_Color(&table->arr[i].color,1,0,0);
			table->arr[i].location.y-=0.4;
			xo->Status=HIDE;
			return 1;
		}
	}
	if(xo->Status != FALLEN) return 0;
	for(int i=0;i< 10;i++)
	{
		xo->Status=Bound_Status(xo->Body,xo->location,table->Stand[i],table->location);
		if(xo->Status==0)xo->Status=FALLEN;
		if(xo->Status==DAWN_BOUND)return 0;
		
	}
	xo->Status=Bound_Status(xo->Body,xo->location,table->Body,table->location);
	if(xo->Status==0)xo->Status=FALLEN;
	return 0;
}

void Bound_Bonus_Bridge(Bonus *bonus,Bridge *bri)
{
	if(bonus->Status != FALLEN) return;
	for(int i=0;i< bri->Size;i++)
	{
		bonus->Status=Bound_Status(bonus->Bound,bonus->location,bri->Roof[i],bri->location);
		if(bonus->Status==0)bonus->Status=FALLEN;
		if(bonus->Status==DAWN_BOUND)return;
	}
}
void Bound_Bonus_Building(Bonus *bonus,Building *B)
{
	if(bonus->Status != FALLEN) return;
	for(int i=0;i< B->Size;i++)
	{
		bonus->Status=Bound_Status(bonus->Bound,bonus->location,B->arr[i],B->location);
		if(bonus->Status==0)bonus->Status=FALLEN;
		if(bonus->Status==DAWN_BOUND)return;
	}
}
void Bound_Bonus_Build_With_Tank(Bonus *bonus,Bullding_With_Tank *B)
{
	if(bonus->Status != FALLEN) return;
	bonus->Status=Bound_Status(bonus->Bound,bonus->location,B->Virtual_Boxes,B->location);
	if(bonus->Status==0)bonus->Status=FALLEN;
	if(bonus->Status==DAWN_BOUND)return;
	bonus->Status=Bound_Status(bonus->Bound,bonus->location,B->box[3],B->location);
	if(bonus->Status==0)bonus->Status=FALLEN;
	if(bonus->Status==DAWN_BOUND)return;
	bonus->Status=Bound_Status(bonus->Bound,bonus->location,B->box[1],B->location);
	if(bonus->Status==0)bonus->Status=FALLEN;
}
 
int Bound_Missile_Tank(Missile *missile,Tank *T,int Size)
{
	if(missile->status==0)return 0;
	for(int i=0;i<Size;i++)
	{
		if(&T[i].ML.missile==missile);
		else if(T[i].Health>-1&&BoundFunc(missile->Top,missile->location,T[i].Tank_Bound_Area,T[i].location))
		{	
			T[i].Health-=missile->Damage;
			if(T[i].Health<0){
				Blow_Tank(&T[i]);
				Reset_Missile(missile);
				return TANK_DESTROYED_BONUS;
			}
			Reset_Missile(missile);
			return HIT_TANK_BONUS;
		}
	}
	return 0;
}
int Bound_Missile_Bullding_With_Tank(Missile *missile,Bullding_With_Tank *B,int Size)
{
	if(missile->status==0)return 0;
	for(int i=0;i<Size;i++)
	{
		if(Bound_Missile_Tank(missile,&B[i].tank,1))
			return HIT_TANK_BONUS;
		if(BoundFunc(missile->Top,missile->location,B[i].Virtual_Boxes,B[i].location))
		{
			Reset_Missile(missile);
			return 0 ;
		}
		if(BoundFunc(missile->Top,missile->location,B[i].box[3],B[i].location))
		{
			Reset_Missile(missile);
			return 0;
		}
		if(BoundFunc(missile->Top,missile->location,B[i].box[1],B[i].location))
		{
			Reset_Missile(missile);
			return 0;
		}
	}
	return 0;
}
void Bound_Missile_Bridge(Missile *missile,Bridge *B,int Size)
{
	if(missile->status==0)return;
	for(int i=0;i<Size;i++)
	{
		for(int j=0;j<B[i].Size;j++){
			if(BoundFunc(missile->Top,missile->location,B[i].Roof[j],B[i].location))
			{
				Reset_Missile(missile);
				return;
			}
			if(BoundFunc(missile->Top,missile->location,B[i].Base[j],B[i].location))
			{
				Reset_Missile(missile);
				return;
			}
		}
	}

}
int Bound_Missile_Building(Missile *missile,Building *B,int Size)
{
	if(missile->status==0)return 0;
	for(int i=0;i<Size;i++)
		for(int j=0;j<B[i].Size;j++)
			if(B[i].Health>-1&&BoundFunc(missile->Top,missile->location,B[i].arr[j],B[i].location))
			{	
				B[i].Health-=missile->Damage;
				if(B[i].Health<0)
					return BUILD_DESTROYED_BONUS;
				Reset_Missile(missile);
				return 0;
			}
		
	return 0;
}
int Bound_Missile_Train(Missile *missile,Train *T,int size)
{
	if(missile->status==0)return 0;
	for(int i=0;i<size;i++)
		for(int j=0;j<10;j++)
			if(BoundFunc(missile->Top,missile->location,T[i].trailer[j].B1,T[i].trailer[j].location))
			{	
				Reset_Missile(missile);
				return TRAIN_HIT_BONUS;
			}
	return 0;
}
int Bound_Missile_Gun(Missile *missile,Gun *G,int Size)
{
	if(missile->status==0)return 0;
	for(int i=0;i<Size;i++)
	{
		if(G[i].Health>-1&&BoundFunc(missile->Top,missile->location,G[i].Bound_Area,G[i].location))
		{	
			G[i].Health-=missile->Damage;
			if(G[i].Health<0){
				Blow_Gun(&G[i]);
				Reset_Missile(missile);
				return TANK_DESTROYED_BONUS;
			}
			Reset_Missile(missile);
			return HIT_TANK_BONUS;
		}
	}
	return 0;
}

int Bound_Bomb_Tank(Bullet *bomb,Tank *tank,int Size)
{
	if(bomb->Status==0)return 0;
	for(int i=0;i<Size;i++)
		if(tank[i].Health>-1&&BoundFunc(bomb->Bound,bomb->location,tank[i].Tank_Bound_Area,tank[i].location))
		{	
			tank[i].Health-=bomb->Damage;
			if(tank[i].Health<0){
				Blow_Tank(&tank[i]);
				Reset_Bomb(bomb);
				return TANK_DESTROYED_BONUS;
			}
			Reset_Bomb(bomb);
			return HIT_TANK_BONUS;
		}
		return 0;
}
int Bound_Bomb_Bullding_With_Tank(Bullet *bomb,Bullding_With_Tank *B,int size)
{
	if(bomb->Status==0)return 0;
	for(int i=0;i<size;i++)
	{
		if(Bound_Bomb_Tank(bomb,&B[i].tank,1))
			return HIT_TANK_BONUS;
		if(BoundFunc(bomb->Bound,bomb->location,B[i].Virtual_Boxes,B[i].location))
		{
			Reset_Bomb(bomb);
			return 0;
		}
		if(BoundFunc(bomb->Bound,bomb->location,B[i].box[3],B[i].location))
		{
			Reset_Bomb(bomb);
			return 0;
		}
		if(BoundFunc(bomb->Bound,bomb->location,B[i].box[1],B[i].location))
		{
			Reset_Bomb(bomb);
			return 0;
		}
	}
	return 0;
}
void Bound_Bomb_Bridge(Bullet *bomb,Bridge *B,int size)
{
	if(bomb->Status==0)return;
	for(int i=0;i<size;i++)
	{
		for(int j=0;j<B[i].Size;j++){
			if(BoundFunc(bomb->Bound,bomb->location,B[i].Roof[j],B[i].location))
			{
				Reset_Bomb(bomb);
				return;
			}
			if(BoundFunc(bomb->Bound,bomb->location,B[i].Base[j],B[i].location))
			{
				Reset_Bomb(bomb);
				return;
			}
		}
	}
}
int Bound_Bomb_Building(Bullet *bomb,Building *B,int Size)
{
	if(bomb->Status==0)return 0;
	for(int i=0;i<Size;i++)
		for(int j=0;j<B[i].Size;j++)
			if(B[i].Health>-1&&BoundFunc(bomb->Bound,bomb->location,B[i].arr[j],B[i].location))
			{	
				B[i].Health-=bomb->Damage;
				if(B[i].Health<0)return BUILD_DESTROYED_BONUS;
				Reset_Bomb(bomb);
				return 0;
			}
	return 0;
}
int Bound_Bomb_Train(Bullet *bomb,Train *T,int size)
{
	if(bomb->Status==0)return 0;
	for(int i=0;i<size;i++)
		for(int j=0;j<10;j++)
			if(BoundFunc(bomb->Bound,bomb->location,T[i].trailer[j].B1,T[i].trailer[j].location))
			{	
				Reset_Bomb(bomb);
				return TRAIN_HIT_BONUS;
			}
	return 0;
}
int Bound_Bomb_Gun(Bullet *bomb,Gun *G,int Size)
{
	if(bomb->Status==0)return 0;
	for(int i=0;i<Size;i++)
	{
		if(G[i].Health>-1&&BoundFunc(bomb->Bound,bomb->location,G[i].Bound_Area,G[i].location))
		{	
			G[i].Health-=bomb->Damage;
			if(G[i].Health<0){
				Blow_Gun(&G[i]);
				Reset_Bomb(bomb);
				return TANK_DESTROYED_BONUS;
			}
			Reset_Bomb(bomb);
			return HIT_TANK_BONUS;
		}
	}
	return 0;
}

//Bridge
void Set_Bridge(Bridge *B,float x,float y,float z,int Count,float eachSize,float height,int Horizon)
{
	Set_Location(&B->location,x,y,z);
	B->Size=Count;
	B->Base=(Box*)malloc(sizeof(Box)*B->Size);
	B->Roof=(Box*)malloc(sizeof(Box)*B->Size);

	if(Horizon)
		Set_Street(&B->street,0,height*2+0.5,(Count*eachSize)/2-eachSize/2,(Count*eachSize),3,Horizon*90);
	else
		Set_Street(&B->street,(Count*eachSize)/2-eachSize/2,height*2+0.5,0,(Count*eachSize),3,Horizon*90);

	if(!Horizon)
		for(int i=0;i<B->Size;i++)
		{
			Set_Box_Color(&B->Roof[i],0.7,0.7,0.7);
			Set_Box_Size(&B->Roof[i],eachSize,0.5,3);
			Set_Box_Location(&B->Roof[i],i*eachSize,height*2+0.25,0);
			Set_Box_Rotation(&B->Roof[i],0,0,0);

			Set_Box_Color(&B->Base[i],0.7,0.7,0.7);
			Set_Box_Size(&B->Base[i],1,height*2,1);
			Set_Box_Location(&B->Base[i],i*eachSize,height,0);
			Set_Box_Rotation(&B->Base[i],0,0,0);
		}
	else
		for(int i=0;i<B->Size;i++)
		{
			Set_Box_Color(&B->Roof[i],0.7,0.7,0.7);
			Set_Box_Size(&B->Roof[i],3,0.5,eachSize);
			Set_Box_Location(&B->Roof[i],0,height*2+0.25,i*eachSize);
			Set_Box_Rotation(&B->Roof[i],0,0,0);

			Set_Box_Color(&B->Base[i],0.7,0.7,0.7);
			Set_Box_Size(&B->Base[i],1,height*2,1);
			Set_Box_Location(&B->Base[i],0,height,i*eachSize);
			Set_Box_Rotation(&B->Base[i],0,0,0);
		}
}
void Draw_Bridge(Bridge *B)
{
	Go_Location(B->location);
	Draw_Street(&B->street);
	for(int i=0;i<B->Size;i++)
	{
		Draw_Box_TR(B->Base[i]);
		Draw_Box_TR(B->Roof[i]);
	}
	Back_Location(B->location);	
}
//XO
void Set_XO_Box(XO *xo,float x,float y,float z, int X_OR_O)
{
	Set_Location(&xo->location,x,y,z);
	xo->X_Or_O=X_OR_O;
	
	Set_Box_Color(&xo->Body,0,0,1);
	Set_Box_Size(&xo->Body,0.8,0.6,0.2);
	Set_Box_Location(&xo->Body,0,0.3,0);
	Set_Box_Rotation(&xo->Body,0,0,0);

	Set_Box_Color(&xo->Body1,0,0,1);
	Set_Box_Size(&xo->Body1,0.2,0.6,0.8);
	Set_Box_Location(&xo->Body1,0,0.3,0);
	Set_Box_Rotation(&xo->Body1,0,0,0);
}
void Draw_XO_Box(XO *xo)
{
	if(xo->Status==HIDE)return;
	if(xo->Status!=9)
	{
		xo->Body.rotation.y++;
		xo->Body.rotation.y%=360;
		xo->Body1.rotation.y++;
		xo->Body1.rotation.y%=360;
		if(xo->MoveFlag ==0)
		{
			xo->Body.location.y+=0.01;
			xo->Body1.location.y+=0.01;
		}
		else 
		{
			xo->Body.location.y-=0.01;
			xo->Body1.location.y-=0.01;
		}
		if(xo->Body.location.y >0.6) xo->MoveFlag=1;
		if(xo->Body.location.y <0.3) xo->MoveFlag=0;
	}
	if(xo->X_Or_O==1)
	{
		Go_Location(xo->location);
		Draw_Box_TR(xo->Body);
		Draw_Box_TR(xo->Body1);
		Back_Location(xo->location);
	}
	else
	{
		Go_Location(xo->location);
		Go_Location(xo->Body.location);
		glColor3f(1,0,0);
		glutSolidSphere(0.3,10,10);
		Back_Location(xo->Body.location);
		Back_Location(xo->location);

	}
}
void XO_Box_Movement(XO *xo)
{
	if(xo->Status==HIDE)return;
	if(xo->Status == DAWN_BOUND || xo->location.y<0 && xo->Status!=CATCHED){
		xo->location.y+=0.1;
		xo->Status=0;
	}
	if(xo->Status == FALLEN && xo->location.y>0)
		xo->location.y-=0.1*GlobalSpeed;
}
//Building
void Building_Type_0(Building *B)
{
	B->Size=5;
		B->arr=(Box*)malloc(sizeof(Box)*5);

		Set_Box_Color(&B->Tank_Bound,1,1,1);
		Set_Box_Size(&B->Tank_Bound,3,1,3);
		Set_Box_Location(&B->Tank_Bound,0,0,0);
		Set_Box_Rotation(&B->Tank_Bound,0,0,0);

		Set_Box_Color(&B->arr[0],1,1,1);
		Set_Box_Size(&B->arr[0],4,0.2,4);
		Set_Box_Location(&B->arr[0],0,0.1,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);

		Set_Box_Color(&B->arr[1],1,1,0);
		Set_Box_Size(&B->arr[1],5,1.5,5);
		Set_Box_Location(&B->arr[1],0,15,0);
		Set_Box_Rotation(&B->arr[1],0,0,0);

		Set_Box_Color(&B->arr[2],1,1,0);
		Set_Box_Size(&B->arr[2],3.8,1,3.8);
		Set_Box_Location(&B->arr[2],0,11,0);
		Set_Box_Rotation(&B->arr[2],0,0,0);


		Set_Box_Color(&B->arr[3],1,1,0.5);
		Set_Box_Size(&B->arr[3],4,1.2,4);
		Set_Box_Location(&B->arr[3],0,3,0);
		Set_Box_Rotation(&B->arr[3],0,0,0);

		Set_Box_Color(&B->arr[4],0.6,0.7,1);
		Set_Box_Size(&B->arr[4],3.5,18,3.5);
		Set_Box_Location(&B->arr[4],0,9,0);
		Set_Box_Rotation(&B->arr[4],0,0,0);
}
void Building_Type_1(Building *B)
{
	B->Size=6;
		B->arr=(Box*)malloc(sizeof(Box)*6);

		Set_Box_Color(&B->Tank_Bound,1,1,1);
		Set_Box_Size(&B->Tank_Bound,6.3,1,11.3);
		Set_Box_Location(&B->Tank_Bound,0,0,0);
		Set_Box_Rotation(&B->Tank_Bound,0,0,0);

		Set_Box_Color(&B->arr[0],0.6,0.7,1);
		Set_Box_Size(&B->arr[0],3.1,14,7);
		Set_Box_Location(&B->arr[0],0,7,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);

		Set_Box_Color(&B->arr[1],1,1,0);
		Set_Box_Size(&B->arr[1],3.5,1,7.5);
		Set_Box_Location(&B->arr[1],0,11,0);
		Set_Box_Rotation(&B->arr[1],0,0,0);

		Set_Box_Color(&B->arr[2],1,1,0);
		Set_Box_Size(&B->arr[2],3.5,1,7.5);
		Set_Box_Location(&B->arr[2],0,8,0);
		Set_Box_Rotation(&B->arr[2],0,0,0);

		Set_Box_Color(&B->arr[3],1,1,1);
		Set_Box_Size(&B->arr[3],3,5,9);
		Set_Box_Location(&B->arr[3],1,2.5,0);
		Set_Box_Rotation(&B->arr[3],0,0,0);

		Set_Box_Color(&B->arr[4],1,1,1);
		Set_Box_Size(&B->arr[4],6,3,11);
		Set_Box_Location(&B->arr[4],0,1.5,0);
		Set_Box_Rotation(&B->arr[4],0,0,0);

		Set_Box_Color(&B->arr[5],1,1,1);
		Set_Box_Size(&B->arr[5],6.3,0.2,11.3);
		Set_Box_Location(&B->arr[5],0,0.1,0);
		Set_Box_Rotation(&B->arr[5],0,0,0);
}
void Building_Type_2(Building *B)
{
		B->Size=10;
		B->arr=(Box*)malloc(sizeof(Box)*10);

		Set_Box_Color(&B->Tank_Bound,1,1,1);
		Set_Box_Size(&B->Tank_Bound,10,1,10);
		Set_Box_Location(&B->Tank_Bound,0,0,0);
		Set_Box_Rotation(&B->Tank_Bound,0,0,0);

		Set_Box_Color(&B->arr[0],0.7,0.7,0.7);
		Set_Box_Size(&B->arr[0],5,10,5);
		Set_Box_Location(&B->arr[0],0,5,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);

		Set_Box_Color(&B->arr[1],0.7,0.7,0.7);
		Set_Box_Size(&B->arr[1],10,1,10);
		Set_Box_Location(&B->arr[1],0,6,0);
		Set_Box_Rotation(&B->arr[1],0,0,0);

		Set_Box_Color(&B->arr[2],0.7,0.7,0.7);
		Set_Box_Size(&B->arr[2],1,5.5,1);
		Set_Box_Location(&B->arr[2],4,2.75,4);
		Set_Box_Rotation(&B->arr[2],0,0,0);

		Set_Box_Color(&B->arr[3],0.7,0.7,0.7);
		Set_Box_Size(&B->arr[3],1,5.5,1);
		Set_Box_Location(&B->arr[3],4,2.75,-4);
		Set_Box_Rotation(&B->arr[3],0,0,0);

		Set_Box_Color(&B->arr[4],0.7,0.7,0.7);
		Set_Box_Size(&B->arr[4],1,5.5,1);
		Set_Box_Location(&B->arr[4],-4,2.75,-4);
		Set_Box_Rotation(&B->arr[4],0,0,0);

		Set_Box_Color(&B->arr[5],0.7,0.7,0.7);
		Set_Box_Size(&B->arr[5],1,5.5,1);
		Set_Box_Location(&B->arr[5],-4,2.75,4);
		Set_Box_Rotation(&B->arr[5],0,0,0);

		Set_Box_Color(&B->arr[6],0.7,0.9,0.7);
		Set_Box_Size(&B->arr[6],10,5,10);
		Set_Box_Location(&B->arr[6],0,2.5,0);
		Set_Box_Rotation(&B->arr[6],0,0,0);

		Set_Box_Color(&B->arr[7],0.5,0.5,0.5);
		Set_Box_Size(&B->arr[7],6,3,0.1);
		Set_Box_Location(&B->arr[7],-3,7.5,-1.5);
		Set_Box_Rotation(&B->arr[7],0,0,0);

		Set_Box_Color(&B->arr[8],0.5,0.5,0.5);
		Set_Box_Size(&B->arr[8],6,3,0.1);
		Set_Box_Location(&B->arr[8],-3,7.5,1.5);
		Set_Box_Rotation(&B->arr[8],0,0,0);

		Set_Box_Color(&B->arr[9],0.5,0.5,0.5);
		Set_Box_Size(&B->arr[9],6,0.1,3);
		Set_Box_Location(&B->arr[9],-3,9,0);
		Set_Box_Rotation(&B->arr[9],0,0,0);
}
void Building_Type_3(Building *B)
{
		B->Size=10;
		B->arr=(Box*)malloc(sizeof(Box)*10);

		Set_Box_Color(&B->Tank_Bound,1,1,1);
		Set_Box_Size(&B->Tank_Bound,10,1,10);
		Set_Box_Location(&B->Tank_Bound,0,0,0);
		Set_Box_Rotation(&B->Tank_Bound,0,0,0);

		Set_Box_Color(&B->arr[0],0.7,0.7,0.7);
		Set_Box_Size(&B->arr[0],5,10,5);
		Set_Box_Location(&B->arr[0],0,5,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);

		Set_Box_Color(&B->arr[1],0.7,0.7,0.7);
		Set_Box_Size(&B->arr[1],10,1,10);
		Set_Box_Location(&B->arr[1],0,6,0);
		Set_Box_Rotation(&B->arr[1],0,0,0);

		Set_Box_Color(&B->arr[2],0.7,0.7,0.7);
		Set_Box_Size(&B->arr[2],1,5.5,1);
		Set_Box_Location(&B->arr[2],4,2.75,4);
		Set_Box_Rotation(&B->arr[2],0,0,0);

		Set_Box_Color(&B->arr[3],0.7,0.7,0.7);
		Set_Box_Size(&B->arr[3],1,5.5,1);
		Set_Box_Location(&B->arr[3],4,2.75,-4);
		Set_Box_Rotation(&B->arr[3],0,0,0);

		Set_Box_Color(&B->arr[4],0.7,0.7,0.7);
		Set_Box_Size(&B->arr[4],1,5.5,1);
		Set_Box_Location(&B->arr[4],-4,2.75,-4);
		Set_Box_Rotation(&B->arr[4],0,0,0);

		Set_Box_Color(&B->arr[5],0.7,0.7,0.7);
		Set_Box_Size(&B->arr[5],1,5.5,1);
		Set_Box_Location(&B->arr[5],-4,2.75,4);
		Set_Box_Rotation(&B->arr[5],0,0,0);

		Set_Box_Color(&B->arr[6],0.7,0.9,0.7);
		Set_Box_Size(&B->arr[6],10,5,10);
		Set_Box_Location(&B->arr[6],0,2.5,0);
		Set_Box_Rotation(&B->arr[6],0,0,0);

		Set_Box_Color(&B->arr[7],0.5,0.5,0.5);
		Set_Box_Size(&B->arr[7],6,3,0.1);
		Set_Box_Location(&B->arr[7],3,7.5,-1.5);
		Set_Box_Rotation(&B->arr[7],0,0,0);

		Set_Box_Color(&B->arr[8],0.5,0.5,0.5);
		Set_Box_Size(&B->arr[8],6,3,0.1);
		Set_Box_Location(&B->arr[8],3,7.5,1.5);
		Set_Box_Rotation(&B->arr[8],0,0,0);

		Set_Box_Color(&B->arr[9],0.5,0.5,0.5);
		Set_Box_Size(&B->arr[9],6,0.1,3);
		Set_Box_Location(&B->arr[9],3,9,0);
		Set_Box_Rotation(&B->arr[9],0,0,0);
		
}
void Building_Type_4(Building *B)
{
	B->Size=10;
		B->arr=(Box*)malloc(sizeof(Box)*10);

		Set_Box_Color(&B->arr[0],0.7,0.7,0.7);
		Set_Box_Size(&B->arr[0],1,16,4);
		Set_Box_Location(&B->arr[0],3,8,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);

		Set_Box_Color(&B->arr[1],0.7,0.7,0.7);
		Set_Box_Size(&B->arr[1],1,16,4);
		Set_Box_Location(&B->arr[1],-3,8,0);
		Set_Box_Rotation(&B->arr[1],0,0,0);

		Set_Box_Color(&B->arr[2],0.7,0.7,1);
		Set_Box_Size(&B->arr[2],7,1,4.5);
		Set_Box_Location(&B->arr[2],0,6,0);
		Set_Box_Rotation(&B->arr[2],0,0,0);

		Set_Box_Color(&B->arr[3],1,1,0.7);
		Set_Box_Size(&B->arr[3],1,4,5);
		Set_Box_Location(&B->arr[3],-2,6,0);
		Set_Box_Rotation(&B->arr[3],0,0,45);

		Set_Box_Color(&B->arr[4],1,1,0.7);
		Set_Box_Size(&B->arr[4],1,4,5);
		Set_Box_Location(&B->arr[4],2,6,0);
		Set_Box_Rotation(&B->arr[4],0,0,-45);

		Set_Box_Color(&B->arr[5],0.7,0.7,1);
		Set_Box_Size(&B->arr[5],7,1,4.5);
		Set_Box_Location(&B->arr[5],0,13,0);
		Set_Box_Rotation(&B->arr[5],0,0,0);

		Set_Box_Color(&B->arr[6],1,1,0.7);
		Set_Box_Size(&B->arr[6],1,4,5);
		Set_Box_Location(&B->arr[6],-2,13,0);
		Set_Box_Rotation(&B->arr[6],0,0,-45);

		Set_Box_Color(&B->arr[7],1,1,0.7);
		Set_Box_Size(&B->arr[7],1,4,5);
		Set_Box_Location(&B->arr[7],2,13,0);
		Set_Box_Rotation(&B->arr[7],0,0,45);

		Set_Box_Color(&B->arr[8],1,1,1);
		Set_Box_Size(&B->arr[8],1.2,0.2,4.2);
		Set_Box_Location(&B->arr[8],3,0.1,0);
		Set_Box_Rotation(&B->arr[8],0,0,0);

		Set_Box_Color(&B->arr[9],1,1,1);
		Set_Box_Size(&B->arr[9],1.2,0.2,4.2);
		Set_Box_Location(&B->arr[9],-3,0.1,0);
		Set_Box_Rotation(&B->arr[9],0,0,0);
}
void Building_Type_5(Building *B)
{
	B->Size=7;
		B->arr=(Box*)malloc(sizeof(Box)*7);

		Set_Box_Color(&B->Tank_Bound,1,1,1);
		Set_Box_Size(&B->Tank_Bound,3,1,3);
		Set_Box_Location(&B->Tank_Bound,0,0,0);
		Set_Box_Rotation(&B->Tank_Bound,0,0,0);

		Set_Box_Color(&B->arr[0],1,1,1);
		Set_Box_Size(&B->arr[0],5.3,0.4,5.3);
		Set_Box_Location(&B->arr[0],0,0.2,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);

		Set_Box_Color(&B->arr[1],1,1,1);
		Set_Box_Size(&B->arr[1],5,6,5);
		Set_Box_Location(&B->arr[1],0,3,0);
		Set_Box_Rotation(&B->arr[1],0,0,0);

		Set_Box_Color(&B->arr[2],1,1,1);
		Set_Box_Size(&B->arr[2],5,3,5);
		Set_Box_Location(&B->arr[2],0,12,0);
		Set_Box_Rotation(&B->arr[2],0,0,0);


		Set_Box_Color(&B->arr[3],1,0,0);
		Set_Box_Size(&B->arr[3],0.5,15,0.5);
		Set_Box_Location(&B->arr[3],2.27,7.5,2.27);
		Set_Box_Rotation(&B->arr[3],0,0,0);

		Set_Box_Color(&B->arr[4],1,0,0);
		Set_Box_Size(&B->arr[4],0.5,15,0.5);
		Set_Box_Location(&B->arr[4],2.27,7.5,-2.27);
		Set_Box_Rotation(&B->arr[4],0,0,0);

		Set_Box_Color(&B->arr[5],1,0,0);
		Set_Box_Size(&B->arr[5],0.5,15,0.5);
		Set_Box_Location(&B->arr[5],-2.27,7.5,-2.27);
		Set_Box_Rotation(&B->arr[5],0,0,0);

		Set_Box_Color(&B->arr[6],1,0,0);
		Set_Box_Size(&B->arr[6],0.5,15,0.5);
		Set_Box_Location(&B->arr[6],-2.27,7.5,2.27);
		Set_Box_Rotation(&B->arr[6],0,0,0);
}
void Building_Type_6(Building *B)
{
	B->Size=8;
		B->arr=(Box*)malloc(sizeof(Box)*8);

		Set_Box_Color(&B->Tank_Bound,1,1,1);
		Set_Box_Size(&B->Tank_Bound,11,1,6);
		Set_Box_Location(&B->Tank_Bound,0,0,0);
		Set_Box_Rotation(&B->Tank_Bound,0,0,0);

		Set_Box_Color(&B->arr[0],1,0.5,0);
		Set_Box_Size(&B->arr[0],11,0.4,6);
		Set_Box_Location(&B->arr[0],0,0.2,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);

		Set_Box_Color(&B->arr[1],1,1,1);
		Set_Box_Size(&B->arr[1],10,4,5);
		Set_Box_Location(&B->arr[1],0,2,0);
		Set_Box_Rotation(&B->arr[1],0,0,0);

		Set_Box_Color(&B->arr[2],1,0,0);
		Set_Box_Size(&B->arr[2],2,8,2);
		Set_Box_Location(&B->arr[2],-3,4,0);
		Set_Box_Rotation(&B->arr[2],0,0,0);

		Set_Box_Color(&B->arr[3],1,0,0);
		Set_Box_Size(&B->arr[3],2,12,2);
		Set_Box_Location(&B->arr[3],3,6,0);
		Set_Box_Rotation(&B->arr[3],0,0,0);

		Set_Box_Color(&B->arr[4],1,1,1);
		Set_Box_Size(&B->arr[4],6,1,2.1);
		Set_Box_Location(&B->arr[4],0,7,-0);
		Set_Box_Rotation(&B->arr[4],0,0,0);

		Set_Box_Color(&B->arr[5],1,0.5,0);
		Set_Box_Size(&B->arr[5],11,3,6);
		Set_Box_Location(&B->arr[5],0,3.5,0);
		Set_Box_Rotation(&B->arr[5],0,0,0);

		Set_Box_Color(&B->arr[6],1,1,0);
		Set_Box_Size(&B->arr[6],3,2,3);
		Set_Box_Location(&B->arr[6],3,12,0);
		Set_Box_Rotation(&B->arr[6],0,0,0);

		Set_Box_Color(&B->arr[7],1,1,0);
		Set_Box_Size(&B->arr[7],3,2,3);
		Set_Box_Location(&B->arr[7],-3,8,0);
		Set_Box_Rotation(&B->arr[7],0,0,0);
}
void Building_Type_7(Building *B)
{
	B->Size=8;
		B->arr=(Box*)malloc(sizeof(Box)*8);

		Set_Box_Color(&B->Tank_Bound,1,1,1);
		Set_Box_Size(&B->Tank_Bound,6,1,11);
		Set_Box_Location(&B->Tank_Bound,0,0,0);
		Set_Box_Rotation(&B->Tank_Bound,0,0,0);

		Set_Box_Color(&B->arr[0],1,0.5,0);
		Set_Box_Size(&B->arr[0],6,0.4,11);
		Set_Box_Location(&B->arr[0],0,0.2,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);

		Set_Box_Color(&B->arr[1],1,1,1);
		Set_Box_Size(&B->arr[1],5,4,10);
		Set_Box_Location(&B->arr[1],0,2,0);
		Set_Box_Rotation(&B->arr[1],0,0,0);

		Set_Box_Color(&B->arr[2],1,0,0);
		Set_Box_Size(&B->arr[2],2,8,2);
		Set_Box_Location(&B->arr[2],0,4,-3);
		Set_Box_Rotation(&B->arr[2],0,0,0);

		Set_Box_Color(&B->arr[3],1,0,0);
		Set_Box_Size(&B->arr[3],2,12,2);
		Set_Box_Location(&B->arr[3],0,6,3);
		Set_Box_Rotation(&B->arr[3],0,0,0);

		Set_Box_Color(&B->arr[4],1,1,1);
		Set_Box_Size(&B->arr[4],2.1,1,6);
		Set_Box_Location(&B->arr[4],0,7,0);
		Set_Box_Rotation(&B->arr[4],0,0,0);

		Set_Box_Color(&B->arr[5],1,0.5,0);
		Set_Box_Size(&B->arr[5],6,3,11);
		Set_Box_Location(&B->arr[5],0,3.5,0);
		Set_Box_Rotation(&B->arr[5],0,0,0);

		Set_Box_Color(&B->arr[6],1,1,0);
		Set_Box_Size(&B->arr[6],3,2,3);
		Set_Box_Location(&B->arr[6],0,12,3);
		Set_Box_Rotation(&B->arr[6],0,0,0);

		Set_Box_Color(&B->arr[7],1,1,0);
		Set_Box_Size(&B->arr[7],3,2,3);
		Set_Box_Location(&B->arr[7],0,8,-3);
		Set_Box_Rotation(&B->arr[7],0,0,0);
}
void Building_Type_8(Building *B)
{
	B->Size=3;
		B->arr=(Box*)malloc(sizeof(Box)*3);

		Set_Box_Color(&B->Tank_Bound,1,1,1);
		Set_Box_Size(&B->Tank_Bound,3,1,3);
		Set_Box_Location(&B->Tank_Bound,0,0,0);
		Set_Box_Rotation(&B->Tank_Bound,0,0,0);

		Set_Box_Color(&B->arr[0],1,0.5,0);
		Set_Box_Size(&B->arr[0],3,0.4,3);
		Set_Box_Location(&B->arr[0],0,0.2,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);


		Set_Box_Color(&B->arr[1],1,1,1);
		Set_Box_Size(&B->arr[1],2.5,16,2.5);
		Set_Box_Location(&B->arr[1],0,8,0);
		Set_Box_Rotation(&B->arr[1],0,0,0);

		Set_Box_Color(&B->arr[2],1,0.5,0);
		Set_Box_Size(&B->arr[2],2,3,2);
		Set_Box_Location(&B->arr[2],0,17.5,0);
		Set_Box_Rotation(&B->arr[2],0,0,0);

}
void Building_Type_9(Building *B)
{
	B->Size=3;
	B->arr=(Box*)malloc(sizeof(Box)*3);

	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,3,1,3);
	Set_Box_Location(&B->Tank_Bound,0,0,0);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],1,0.5,0);
	Set_Box_Size(&B->arr[0],3,0.4,3);
	Set_Box_Location(&B->arr[0],0,0.2,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);


	Set_Box_Color(&B->arr[1],1,1,1);
	Set_Box_Size(&B->arr[1],2.5,20,2.5);
	Set_Box_Location(&B->arr[1],0,10,0);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],1,0.5,0);
	Set_Box_Size(&B->arr[2],2,4,2);
	Set_Box_Location(&B->arr[2],0,22,0);
	Set_Box_Rotation(&B->arr[2],0,0,0);
}
void Building_Type_11(Building *B)
{
	B->Size=9;
	B->arr=(Box*)malloc(sizeof(Box)*9);

	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,15,1,15);
	Set_Box_Location(&B->Tank_Bound,0,0,0);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],0.8,0.7,0);
	Set_Box_Size(&B->arr[0],15,15,15);
	Set_Box_Location(&B->arr[0],0,7.5,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],1,0.7,0.1);
	Set_Box_Size(&B->arr[1],3,10,3);
	Set_Box_Location(&B->arr[1],-5,5,0);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],1,0.7,0.1);
	Set_Box_Size(&B->arr[2],3,10,3);
	Set_Box_Location(&B->arr[2],5,5,0);
	Set_Box_Rotation(&B->arr[2],0,0,0);

	Set_Box_Color(&B->arr[3],1,0.7,0.1);
	Set_Box_Size(&B->arr[3],3,10,3);
	Set_Box_Location(&B->arr[3],0,5,5);
	Set_Box_Rotation(&B->arr[3],0,0,0);

	Set_Box_Color(&B->arr[4],1,0.7,0.1);
	Set_Box_Size(&B->arr[4],3,10,3);
	Set_Box_Location(&B->arr[4],0,5,-5);
	Set_Box_Rotation(&B->arr[4],0,0,0);

	Set_Box_Color(&B->arr[5],1,0.5,0);
	Set_Box_Size(&B->arr[5],5,3,0.5);
	Set_Box_Location(&B->arr[5],8,1.5,-1.5);
	Set_Box_Rotation(&B->arr[5],0,0,0);

	Set_Box_Color(&B->arr[6],1,0.5,0);
	Set_Box_Size(&B->arr[6],5,3,0.5);
	Set_Box_Location(&B->arr[6],8,1.5,1.5);
	Set_Box_Rotation(&B->arr[6],0,0,0);

	Set_Box_Color(&B->arr[7],1,0.5,0);
	Set_Box_Size(&B->arr[7],5,0.5,3.5);
	Set_Box_Location(&B->arr[7],8,3.25,0);
	Set_Box_Rotation(&B->arr[7],0,0,0);

	Set_Box_Color(&B->arr[8],0,0,0);
	Set_Box_Size(&B->arr[8],0.2,3,3);
	Set_Box_Location(&B->arr[8],9,1.5,0);
	Set_Box_Rotation(&B->arr[8],0,0,0);
}
void Building_Type_12(Building *B)
{
	B->Size=9;
	B->arr=(Box*)malloc(sizeof(Box)*9);

	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,15,1,15);
	Set_Box_Location(&B->Tank_Bound,0,0,0);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],0.8,0.7,0);
	Set_Box_Size(&B->arr[0],15,15,15);
	Set_Box_Location(&B->arr[0],0,7.5,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],1,0.7,0.1);
	Set_Box_Size(&B->arr[1],3,10,3);
	Set_Box_Location(&B->arr[1],-5,5,0);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],1,0.7,0.1);
	Set_Box_Size(&B->arr[2],3,10,3);
	Set_Box_Location(&B->arr[2],5,5,0);
	Set_Box_Rotation(&B->arr[2],0,0,0);

	Set_Box_Color(&B->arr[3],1,0.7,0.1);
	Set_Box_Size(&B->arr[3],3,10,3);
	Set_Box_Location(&B->arr[3],0,5,5);
	Set_Box_Rotation(&B->arr[3],0,0,0);

	Set_Box_Color(&B->arr[4],1,0.7,0.1);
	Set_Box_Size(&B->arr[4],3,10,3);
	Set_Box_Location(&B->arr[4],0,5,-5);
	Set_Box_Rotation(&B->arr[4],0,0,0);

	Set_Box_Color(&B->arr[5],1,0.5,0);
	Set_Box_Size(&B->arr[5],5,3,0.5);
	Set_Box_Location(&B->arr[5],-8,1.5,-1.5);
	Set_Box_Rotation(&B->arr[5],0,0,0);

	Set_Box_Color(&B->arr[6],1,0.5,0);
	Set_Box_Size(&B->arr[6],5,3,0.5);
	Set_Box_Location(&B->arr[6],-8,1.5,1.5);
	Set_Box_Rotation(&B->arr[6],0,0,0);

	Set_Box_Color(&B->arr[7],1,0.5,0);
	Set_Box_Size(&B->arr[7],5,0.5,3.5);
	Set_Box_Location(&B->arr[7],-8,3.25,0);
	Set_Box_Rotation(&B->arr[7],0,0,0);

	Set_Box_Color(&B->arr[8],0,0,0);
	Set_Box_Size(&B->arr[8],0.2,3,3);
	Set_Box_Location(&B->arr[8],-9,1.5,0);
	Set_Box_Rotation(&B->arr[8],0,0,0);
}
void Building_Type_13(Building *B)
{
	B->Size=5;
	B->arr=(Box*)malloc(sizeof(Box)*5);

	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,3,1,3);
	Set_Box_Location(&B->Tank_Bound,0,0,0);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],0.8,0.7,0.6);
	Set_Box_Size(&B->arr[0],3,0.4,3);
	Set_Box_Location(&B->arr[0],0,0.2,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],0.8,0.7,0.1);
	Set_Box_Size(&B->arr[1],2.5,20,2.5);
	Set_Box_Location(&B->arr[1],0,10,0);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],0.4,0.7,1);
	Set_Box_Size(&B->arr[2],2,4,2);
	Set_Box_Location(&B->arr[2],0,22,0);
	Set_Box_Rotation(&B->arr[2],0,0,0);

	Set_Box_Color(&B->arr[3],0.4,0.7,1);
	Set_Box_Size(&B->arr[3],2.8,20,0.2);
	Set_Box_Location(&B->arr[3],0,10,0);
	Set_Box_Rotation(&B->arr[3],0,0,0);
	
	Set_Box_Color(&B->arr[4],0.4,0.7,1);
	Set_Box_Size(&B->arr[4],0.2,20,2.8);
	Set_Box_Location(&B->arr[4],0,10,0);
	Set_Box_Rotation(&B->arr[4],0,0,0);
}
void Building_Type_14(Building *B)
{
	B->Size=9;
	B->arr=(Box*)malloc(sizeof(Box)*9);

	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,3,1,3);
	Set_Box_Location(&B->Tank_Bound,0,0,0);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],0.8,0.7,0);
	Set_Box_Size(&B->arr[0],3,1,3);
	Set_Box_Location(&B->arr[0],0,0.5,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],0.8,0.7,0.1);
	Set_Box_Size(&B->arr[1],2,8,2);
	Set_Box_Location(&B->arr[1],0,4.5,0);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],0.8,0.7,0);
	Set_Box_Size(&B->arr[2],3,1,3);
	Set_Box_Location(&B->arr[2],0,8.5,0);
	Set_Box_Rotation(&B->arr[2],0,0,180);

	Set_Box_Color(&B->arr[3],0.4,0.7,1);
	Set_Box_Size(&B->arr[3],3.9,0.2,3.9);
	Set_Box_Location(&B->arr[3],0,8.5,0);
	Set_Box_Rotation(&B->arr[3],0,0,0);

	Set_Box_Color(&B->arr[4],0.4,0.7,1);
	Set_Box_Size(&B->arr[4],2.2,0.2,2.2);
	Set_Box_Location(&B->arr[4],0,4.5,0);
	Set_Box_Rotation(&B->arr[4],0,0,0);

	Set_Box_Color(&B->arr[5],0.4,0.7,1);
	Set_Box_Size(&B->arr[5],2.2,0.2,2.2);
	Set_Box_Location(&B->arr[5],0,1.5,0);
	Set_Box_Rotation(&B->arr[5],0,0,0);

	Set_Box_Color(&B->arr[6],0.4,0.7,1);
	Set_Box_Size(&B->arr[6],2.5,3,2.5);
	Set_Box_Location(&B->arr[6],0,2,0);
	Set_Box_Rotation(&B->arr[6],0,0,0);

	Set_Box_Color(&B->arr[7],0.4,0.7,1);
	Set_Box_Size(&B->arr[7],2.5,3,2.5);
	Set_Box_Location(&B->arr[7],0,7,0);
	Set_Box_Rotation(&B->arr[7],0,0,180);

	Set_Box_Color(&B->arr[8],0,0,0);
	Set_Box_Size(&B->arr[8],2,2,2);
	Set_Box_Location(&B->arr[8],0,10,0);
	Set_Box_Rotation(&B->arr[8],0,0,0);
}
void Building_Type_15(Building *B)
{
	B->Size=5;
	B->arr=(Box*)malloc(sizeof(Box)*5);
	
	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,10,1,4);
	Set_Box_Location(&B->Tank_Bound,0,0,0);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],0.8,0.7,0.5);
	Set_Box_Size(&B->arr[0],10,0.5,4);
	Set_Box_Location(&B->arr[0],0,0.25,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],0.8,0.7,0.1);
	Set_Box_Size(&B->arr[1],8,7,3);
	Set_Box_Location(&B->arr[1],0,3.5,0);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],0,1,0);
	Set_Box_Size(&B->arr[2],8.2,1,3.2);
	Set_Box_Location(&B->arr[2],0,3,0);
	Set_Box_Rotation(&B->arr[2],0,0,0);

	Set_Box_Color(&B->arr[3],0.4,0.7,1);
	Set_Box_Size(&B->arr[3],8.2,7,0.3);
	Set_Box_Location(&B->arr[3],0,3.6,-1);
	Set_Box_Rotation(&B->arr[3],0,0,0);

	Set_Box_Color(&B->arr[4],0.4,0.7,1);
	Set_Box_Size(&B->arr[4],8.2,7,0.3);
	Set_Box_Location(&B->arr[4],0,3.6,1);
	Set_Box_Rotation(&B->arr[4],0,0,0);
}
void Building_Type_16(Building *B)
{
	B->Size=5;
	B->arr=(Box*)malloc(sizeof(Box)*5);
	
	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,4,1,10);
	Set_Box_Location(&B->Tank_Bound,0,0,0);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],0.8,0.7,0.5);
	Set_Box_Size(&B->arr[0],4,0.5,10);
	Set_Box_Location(&B->arr[0],0,0.25,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],0.8,0.7,0.1);
	Set_Box_Size(&B->arr[1],3,4,8);
	Set_Box_Location(&B->arr[1],0,2,0);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],0,1,0);
	Set_Box_Size(&B->arr[2],3.2,0.5,8.2);
	Set_Box_Location(&B->arr[2],0,3,0);
	Set_Box_Rotation(&B->arr[2],0,0,0);

	Set_Box_Color(&B->arr[3],0.4,0.7,1);
	Set_Box_Size(&B->arr[3],0.3,4,8.2);
	Set_Box_Location(&B->arr[3],-1,2.1,0);
	Set_Box_Rotation(&B->arr[3],0,0,0);

	Set_Box_Color(&B->arr[4],0.4,0.7,1);
	Set_Box_Size(&B->arr[4],0.3,4,8.2);
	Set_Box_Location(&B->arr[4],1,2.1,0);
	Set_Box_Rotation(&B->arr[4],0,0,0);
}
void Building_Type_17(Building *B)
{
	B->Size=10;
	B->arr=(Box*)malloc(sizeof(Box)*10);
	
	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,4,1,15);
	Set_Box_Location(&B->Tank_Bound,0,0,0);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],0.8,0.7,0.5);
	Set_Box_Size(&B->arr[0],4,0.5,15);
	Set_Box_Location(&B->arr[0],0,0.25,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],0.8,0.7,0.1);
	Set_Box_Size(&B->arr[1],3,4,4);
	Set_Box_Location(&B->arr[1],0,2,-3);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],0.4,0.7,1);
	Set_Box_Size(&B->arr[2],3.2,0.5,4.2);
	Set_Box_Location(&B->arr[2],0,3,-3);
	Set_Box_Rotation(&B->arr[2],0,0,0);

	Set_Box_Color(&B->arr[3],0.8,0.7,1);
	Set_Box_Size(&B->arr[3],0.3,4,4.2);
	Set_Box_Location(&B->arr[3],-1,2.1,-3);
	Set_Box_Rotation(&B->arr[3],0,0,0);

	Set_Box_Color(&B->arr[4],0.8,0.7,1);
	Set_Box_Size(&B->arr[4],0.3,4,4.2);
	Set_Box_Location(&B->arr[4],1,2.1,-3);
	Set_Box_Rotation(&B->arr[4],0,0,0);

	Set_Box_Color(&B->arr[5],0.8,0.7,0.1);
	Set_Box_Size(&B->arr[5],3,6,4);
	Set_Box_Location(&B->arr[5],0,3,4);
	Set_Box_Rotation(&B->arr[5],0,0,0);

	Set_Box_Color(&B->arr[6],0,1,0);
	Set_Box_Size(&B->arr[6],3.2,0.5,4.2);
	Set_Box_Location(&B->arr[6],0,5,4);
	Set_Box_Rotation(&B->arr[6],0,0,0);

	Set_Box_Color(&B->arr[7],0.4,0.7,1);
	Set_Box_Size(&B->arr[7],0.3,6.2,4.2);
	Set_Box_Location(&B->arr[7],-1,3,4);
	Set_Box_Rotation(&B->arr[7],0,0,0);

	Set_Box_Color(&B->arr[8],0.4,0.7,1);
	Set_Box_Size(&B->arr[8],0.3,6.2,4.2);
	Set_Box_Location(&B->arr[8],1,3,4);
	Set_Box_Rotation(&B->arr[8],0,0,0);

	Set_Box_Color(&B->arr[9],0,1,0);
	Set_Box_Size(&B->arr[9],3.2,0.5,4.2);
	Set_Box_Location(&B->arr[9],0,3,4);
	Set_Box_Rotation(&B->arr[9],0,0,0);
}
void Building_Type_18(Building *B)
{
	B->Size=3;
	B->arr=(Box*)malloc(sizeof(Box)*3);

	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,10,1,4);
	Set_Box_Location(&B->Tank_Bound,0,0,0);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],0.8,0.7,0.6);
	Set_Box_Size(&B->arr[0],10,1,4);
	Set_Box_Location(&B->arr[0],0,0.5,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],0.4,0.7,1);
	Set_Box_Size(&B->arr[1],8,1,2);
	Set_Box_Location(&B->arr[1],0,1.5,0);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],0.8,0.7,0.6);
	Set_Box_Size(&B->arr[2],10,1,4);
	Set_Box_Location(&B->arr[2],0,2.5,0);
	Set_Box_Rotation(&B->arr[2],180,0,0);

}
void Building_Type_19(Building *B)
{
	B->Size=3;
	B->arr=(Box*)malloc(sizeof(Box)*3);

	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,4,1,10);
	Set_Box_Location(&B->Tank_Bound,0,0,0);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],0.8,0.7,0.6);
	Set_Box_Size(&B->arr[0],4,1,10);
	Set_Box_Location(&B->arr[0],0,0.5,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],0.4,0.7,1);
	Set_Box_Size(&B->arr[1],2,1,8);
	Set_Box_Location(&B->arr[1],0,1.5,0);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],0.8,0.7,0.6);
	Set_Box_Size(&B->arr[2],4,1,10);
	Set_Box_Location(&B->arr[2],0,2.5,0);
	Set_Box_Rotation(&B->arr[2],180,0,0);
}
void Building_Type_20(Building *B)
{
	B->Size=4;
	B->arr=(Box*)malloc(sizeof(Box)*4);

	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,4,1,10);
	Set_Box_Location(&B->Tank_Bound,0,0,0);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],0.4,0.4,0.4);
	Set_Box_Size(&B->arr[0],9,4,0.3);
	Set_Box_Location(&B->arr[0],0,2,1.3);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],0.4,0.4,0.4);
	Set_Box_Size(&B->arr[1],9,4,0.3);
	Set_Box_Location(&B->arr[1],0,2,-1.3);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],0.4,0.4,0.4);
	Set_Box_Size(&B->arr[2],9,0.3,3);
	Set_Box_Location(&B->arr[2],0,4.15,0);
	Set_Box_Rotation(&B->arr[2],0,0,0);

	Set_Box_Color(&B->arr[3],0,0,0);
	Set_Box_Size(&B->arr[3],8,4,2.5);
	Set_Box_Location(&B->arr[3],0,2,0);
	Set_Box_Rotation(&B->arr[3],0,0,0);

}
void Building_Type_21(Building *B)
{
	B->Size=27;
	B->arr=(Box*)malloc(sizeof(Box)*27);

	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,13,0.5,13);
	Set_Box_Location(&B->Tank_Bound,0,0,-1);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[0],13,0.5,13);
	Set_Box_Location(&B->arr[0],0,0.25,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[1],2,4.5,2);
	Set_Box_Location(&B->arr[1],2,2.25,0);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[2],2,4.5,2);
	Set_Box_Location(&B->arr[2],-2,2.25,0);
	Set_Box_Rotation(&B->arr[2],0,0,0);

	Set_Box_Color(&B->arr[3],0.6,0.5,0.1);
	Set_Box_Size(&B->arr[3],2.2,2.2,2.2);
	Set_Box_Location(&B->arr[3],-2,5.5,0);
	Set_Box_Rotation(&B->arr[3],0,0,0);

	Set_Box_Color(&B->arr[4],0.6,0.5,0.1);
	Set_Box_Size(&B->arr[4],2.2,2.2,2.2);
	Set_Box_Location(&B->arr[4],2,5.5,0);
	Set_Box_Rotation(&B->arr[4],0,0,0);

	Set_Box_Color(&B->arr[5],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[5],2.5,5,2.5);
	Set_Box_Location(&B->arr[5],-2,9,0);
	Set_Box_Rotation(&B->arr[5],0,0,0);

	Set_Box_Color(&B->arr[6],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[6],2.5,5,2.5);
	Set_Box_Location(&B->arr[6],2,9,0);
	Set_Box_Rotation(&B->arr[6],0,0,0);

	Set_Box_Color(&B->arr[7],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[7],2.5,3,3.5);
	Set_Box_Location(&B->arr[7],-2,0,-1);
	Set_Box_Rotation(&B->arr[7],0,180,0);

	Set_Box_Color(&B->arr[8],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[8],2.5,3,3.5);
	Set_Box_Location(&B->arr[8],2,0,-1);
	Set_Box_Rotation(&B->arr[8],0,180,0);

	Set_Box_Color(&B->arr[9],0.9,0.9,0);
	Set_Box_Size(&B->arr[9],8,9,4);
	Set_Box_Location(&B->arr[9],0,14,0);
	Set_Box_Rotation(&B->arr[9],0,0,180);

	Set_Box_Color(&B->arr[10],0.5,0.5,0);
	Set_Box_Size(&B->arr[10],3,3,3);
	Set_Box_Location(&B->arr[10],5,18,0);
	Set_Box_Rotation(&B->arr[10],0,0,0);

	Set_Box_Color(&B->arr[11],0.5,0.5,0);
	Set_Box_Size(&B->arr[11],3,3,3);
	Set_Box_Location(&B->arr[11],-5,18,0);
	Set_Box_Rotation(&B->arr[11],0,0,0);

	Set_Box_Color(&B->arr[12],0.8,0.7,0.1);
	Set_Box_Size(&B->arr[12],2,5,2);
	Set_Box_Location(&B->arr[12],5,15,0);
	Set_Box_Rotation(&B->arr[12],0,0,0);

	Set_Box_Color(&B->arr[13],0.8,0.7,0.1);
	Set_Box_Size(&B->arr[13],2,5,2);
	Set_Box_Location(&B->arr[13],-5,15,0);
	Set_Box_Rotation(&B->arr[13],0,0,0);


	Set_Box_Color(&B->arr[14],0.5,0.5,0.1);
	Set_Box_Size(&B->arr[14],2.2,2,2.2);
	Set_Box_Location(&B->arr[14],5,12,0);
	Set_Box_Rotation(&B->arr[14],0,0,0);

	Set_Box_Color(&B->arr[15],0.5,0.5,0.1);
	Set_Box_Size(&B->arr[15],2.2,2,2.2);
	Set_Box_Location(&B->arr[15],-5,12,0);
	Set_Box_Rotation(&B->arr[15],0,0,0);

	Set_Box_Color(&B->arr[16],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[16],1.5,4,1.5);
	Set_Box_Location(&B->arr[16],-5,10,0);
	Set_Box_Rotation(&B->arr[16],0,0,0);

	Set_Box_Color(&B->arr[17],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[17],1.5,1.5,4);
	Set_Box_Location(&B->arr[17],5,12,-2);
	Set_Box_Rotation(&B->arr[17],0,0,0);

	Set_Box_Color(&B->arr[18],0.6,0.4,0.1);
	Set_Box_Size(&B->arr[18],1.6,1.6,1.6);
	Set_Box_Location(&B->arr[18],-5,8,0);
	Set_Box_Rotation(&B->arr[18],0,0,0);

	Set_Box_Color(&B->arr[19],0.6,0.4,0.1);
	Set_Box_Size(&B->arr[19],1.6,1.6,1.6);
	Set_Box_Location(&B->arr[19],5,12,-4);
	Set_Box_Rotation(&B->arr[19],0,0,0);

	Set_Box_Color(&B->arr[20],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[20],1,24,1);
	Set_Box_Location(&B->arr[20],5,12,-4);
	Set_Box_Rotation(&B->arr[20],0,0,0);

	Set_Box_Color(&B->arr[21],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[21],1.5,1.5,1.5);
	Set_Box_Location(&B->arr[21],0,19,0);
	Set_Box_Rotation(&B->arr[21],0,0,0);

	Set_Box_Color(&B->arr[22],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[22],3,3,4);
	Set_Box_Location(&B->arr[22],0,21,0);
	Set_Box_Rotation(&B->arr[22],0,180,0);

	Set_Box_Color(&B->arr[23],0.6,0.7,0.3);
	Set_Box_Size(&B->arr[23],5,3,5);
	Set_Box_Location(&B->arr[23],0,21,1);
	Set_Box_Rotation(&B->arr[23],0,0,0);

	Set_Box_Color(&B->arr[24],0.6,0.7,0.5);
	Set_Box_Size(&B->arr[24],0.6,2,0.6);
	Set_Box_Location(&B->arr[24],1,23,0);
	Set_Box_Rotation(&B->arr[24],0,0,0);

	Set_Box_Color(&B->arr[25],0.6,0.7,0.5);
	Set_Box_Size(&B->arr[25],0.6,2,0.6);
	Set_Box_Location(&B->arr[25],-1,23,0);
	Set_Box_Rotation(&B->arr[25],0,0,0);

	Set_Box_Color(&B->arr[26],0,0,0);
	Set_Box_Size(&B->arr[26],2,2,2);
	Set_Box_Location(&B->arr[26],5,25,-4);
	Set_Box_Rotation(&B->arr[26],0,0,0);

}
void Building_Type_22(Building *B)
{
	B->Size=27;
	B->arr=(Box*)malloc(sizeof(Box)*27);

	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,13,0.5,13);
	Set_Box_Location(&B->Tank_Bound,0,0,-1);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[0],13,0.5,13);
	Set_Box_Location(&B->arr[0],0,0.25,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[1],2,4.5,2);
	Set_Box_Location(&B->arr[1],2,2.25,0);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[2],2,4.5,2);
	Set_Box_Location(&B->arr[2],-2,2.25,0);
	Set_Box_Rotation(&B->arr[2],0,0,0);

	Set_Box_Color(&B->arr[3],0.6,0.5,0.1);
	Set_Box_Size(&B->arr[3],2.2,2.2,2.2);
	Set_Box_Location(&B->arr[3],-2,5.5,0);
	Set_Box_Rotation(&B->arr[3],0,0,0);

	Set_Box_Color(&B->arr[4],0.6,0.5,0.1);
	Set_Box_Size(&B->arr[4],2.2,2.2,2.2);
	Set_Box_Location(&B->arr[4],2,5.5,0);
	Set_Box_Rotation(&B->arr[4],0,0,0);

	Set_Box_Color(&B->arr[5],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[5],2.5,5,2.5);
	Set_Box_Location(&B->arr[5],-2,9,0);
	Set_Box_Rotation(&B->arr[5],0,0,0);

	Set_Box_Color(&B->arr[6],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[6],2.5,5,2.5);
	Set_Box_Location(&B->arr[6],2,9,0);
	Set_Box_Rotation(&B->arr[6],0,0,0);

	Set_Box_Color(&B->arr[7],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[7],2.5,3,3.5);
	Set_Box_Location(&B->arr[7],-2,0,1);
	Set_Box_Rotation(&B->arr[7],0,0,0);

	Set_Box_Color(&B->arr[8],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[8],2.5,3,3.5);
	Set_Box_Location(&B->arr[8],2,0,1);
	Set_Box_Rotation(&B->arr[8],0,0,0);

	Set_Box_Color(&B->arr[9],0.9,0.9,0);
	Set_Box_Size(&B->arr[9],8,9,4);
	Set_Box_Location(&B->arr[9],0,14,0);
	Set_Box_Rotation(&B->arr[9],0,0,180);

	Set_Box_Color(&B->arr[10],0.5,0.5,0);
	Set_Box_Size(&B->arr[10],3,3,3);
	Set_Box_Location(&B->arr[10],5,18,0);
	Set_Box_Rotation(&B->arr[10],0,0,0);

	Set_Box_Color(&B->arr[11],0.5,0.5,0);
	Set_Box_Size(&B->arr[11],3,3,3);
	Set_Box_Location(&B->arr[11],-5,18,0);
	Set_Box_Rotation(&B->arr[11],0,0,0);

	Set_Box_Color(&B->arr[12],0.8,0.7,0.1);
	Set_Box_Size(&B->arr[12],2,5,2);
	Set_Box_Location(&B->arr[12],5,15,0);
	Set_Box_Rotation(&B->arr[12],0,0,0);

	Set_Box_Color(&B->arr[13],0.8,0.7,0.1);
	Set_Box_Size(&B->arr[13],2,5,2);
	Set_Box_Location(&B->arr[13],-5,15,0);
	Set_Box_Rotation(&B->arr[13],0,0,0);


	Set_Box_Color(&B->arr[14],0.5,0.5,0.1);
	Set_Box_Size(&B->arr[14],2.2,2,2.2);
	Set_Box_Location(&B->arr[14],5,12,0);
	Set_Box_Rotation(&B->arr[14],0,0,0);

	Set_Box_Color(&B->arr[15],0.5,0.5,0.1);
	Set_Box_Size(&B->arr[15],2.2,2,2.2);
	Set_Box_Location(&B->arr[15],-5,12,0);
	Set_Box_Rotation(&B->arr[15],0,0,0);

	Set_Box_Color(&B->arr[16],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[16],1.5,4,1.5);
	Set_Box_Location(&B->arr[16],-5,10,0);
	Set_Box_Rotation(&B->arr[16],0,0,0);

	Set_Box_Color(&B->arr[17],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[17],1.5,1.5,4);
	Set_Box_Location(&B->arr[17],5,12,2);
	Set_Box_Rotation(&B->arr[17],0,0,0);

	Set_Box_Color(&B->arr[18],0.6,0.4,0.1);
	Set_Box_Size(&B->arr[18],1.6,1.6,1.6);
	Set_Box_Location(&B->arr[18],-5,8,0);
	Set_Box_Rotation(&B->arr[18],0,0,0);

	Set_Box_Color(&B->arr[19],0.6,0.4,0.1);
	Set_Box_Size(&B->arr[19],1.6,1.6,1.6);
	Set_Box_Location(&B->arr[19],5,12,4);
	Set_Box_Rotation(&B->arr[19],0,0,0);

	Set_Box_Color(&B->arr[20],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[20],1,24,1);
	Set_Box_Location(&B->arr[20],5,12,4);
	Set_Box_Rotation(&B->arr[20],0,0,0);

	Set_Box_Color(&B->arr[21],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[21],1.5,1.5,1.5);
	Set_Box_Location(&B->arr[21],0,19,0);
	Set_Box_Rotation(&B->arr[21],0,0,0);

	Set_Box_Color(&B->arr[22],0.6,0.7,0.1);
	Set_Box_Size(&B->arr[22],3,3,4);
	Set_Box_Location(&B->arr[22],0,21,0);
	Set_Box_Rotation(&B->arr[22],0,0,0);

	Set_Box_Color(&B->arr[23],0.6,0.7,0.3);
	Set_Box_Size(&B->arr[23],5,3,5);
	Set_Box_Location(&B->arr[23],0,21,-1);
	Set_Box_Rotation(&B->arr[23],0,0,0);

	Set_Box_Color(&B->arr[24],0.6,0.7,0.5);
	Set_Box_Size(&B->arr[24],0.6,2,0.6);
	Set_Box_Location(&B->arr[24],1,23,0);
	Set_Box_Rotation(&B->arr[24],0,0,0);

	Set_Box_Color(&B->arr[25],0.6,0.7,0.5);
	Set_Box_Size(&B->arr[25],0.6,2,0.6);
	Set_Box_Location(&B->arr[25],-1,23,0);
	Set_Box_Rotation(&B->arr[25],0,0,0);

	Set_Box_Color(&B->arr[26],0,0,0);
	Set_Box_Size(&B->arr[26],2,2,2);
	Set_Box_Location(&B->arr[26],5,25,4);
	Set_Box_Rotation(&B->arr[26],0,0,0);

}
void Building_Type_23(Building *B)
{
	B->Size=27;
	B->arr=(Box*)malloc(sizeof(Box)*27);

	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,13,0.5,13);
	Set_Box_Location(&B->Tank_Bound,0,0,-1);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],1,1,1);
	Set_Box_Size(&B->arr[0],13,0.5,13);
	Set_Box_Location(&B->arr[0],0,0.25,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],1,0.9,1);
	Set_Box_Size(&B->arr[1],2,4.5,2);
	Set_Box_Location(&B->arr[1],2,2.25,0);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],1,0.9,1);
	Set_Box_Size(&B->arr[2],2,4.5,2);
	Set_Box_Location(&B->arr[2],-2,2.25,0);
	Set_Box_Rotation(&B->arr[2],0,0,0);

	Set_Box_Color(&B->arr[3],0.6,0.5,0.2);
	Set_Box_Size(&B->arr[3],2.2,2.2,2.2);
	Set_Box_Location(&B->arr[3],-2,5.5,0);
	Set_Box_Rotation(&B->arr[3],0,0,0);

	Set_Box_Color(&B->arr[4],0.6,0.5,0.2);
	Set_Box_Size(&B->arr[4],2.2,2.2,2.2);
	Set_Box_Location(&B->arr[4],2,5.5,0);
	Set_Box_Rotation(&B->arr[4],0,0,0);

	Set_Box_Color(&B->arr[5],1,0.9,1);
	Set_Box_Size(&B->arr[5],2.5,5,2.5);
	Set_Box_Location(&B->arr[5],-2,9,0);
	Set_Box_Rotation(&B->arr[5],0,0,0);

	Set_Box_Color(&B->arr[6],1,0.9,1);
	Set_Box_Size(&B->arr[6],2.5,5,2.5);
	Set_Box_Location(&B->arr[6],2,9,0);
	Set_Box_Rotation(&B->arr[6],0,0,0);

	Set_Box_Color(&B->arr[7],0.5,0.5,0.5);
	Set_Box_Size(&B->arr[7],2.5,3,3.5);
	Set_Box_Location(&B->arr[7],-2,0,-1);
	Set_Box_Rotation(&B->arr[7],0,180,0);

	Set_Box_Color(&B->arr[8],0.5,0.5,0.5);
	Set_Box_Size(&B->arr[8],2.5,3,3.5);
	Set_Box_Location(&B->arr[8],2,0,-1);
	Set_Box_Rotation(&B->arr[8],0,180,0);

	Set_Box_Color(&B->arr[9],0.7,0.7,0.7);
	Set_Box_Size(&B->arr[9],8,9,4);
	Set_Box_Location(&B->arr[9],0,14,0);
	Set_Box_Rotation(&B->arr[9],0,0,180);

	Set_Box_Color(&B->arr[10],0.5,1,1);
	Set_Box_Size(&B->arr[10],3,3,3);
	Set_Box_Location(&B->arr[10],5,18,0);
	Set_Box_Rotation(&B->arr[10],0,0,0);

	Set_Box_Color(&B->arr[11],0.5,1,1);
	Set_Box_Size(&B->arr[11],3,3,3);
	Set_Box_Location(&B->arr[11],-5,18,0);
	Set_Box_Rotation(&B->arr[11],0,0,0);

	Set_Box_Color(&B->arr[12],0.6,0.7,1);
	Set_Box_Size(&B->arr[12],2,5,2);
	Set_Box_Location(&B->arr[12],5,15,-2);
	Set_Box_Rotation(&B->arr[12],30,0,0);

	Set_Box_Color(&B->arr[13],0.6,0.7,1);
	Set_Box_Size(&B->arr[13],2,5,2);
	Set_Box_Location(&B->arr[13],-5,15,-2);
	Set_Box_Rotation(&B->arr[13],30,0,0);


	Set_Box_Color(&B->arr[14],0.8,0.8,0.1);
	Set_Box_Size(&B->arr[14],2.2,2,2.2);
	Set_Box_Location(&B->arr[14],5,12.5,-3);
	Set_Box_Rotation(&B->arr[14],0,0,0);

	Set_Box_Color(&B->arr[15],0.8,0.8,0.1);
	Set_Box_Size(&B->arr[15],2.2,2,2.2);
	Set_Box_Location(&B->arr[15],-5,12.5,-3);
	Set_Box_Rotation(&B->arr[15],0,0,0);

	Set_Box_Color(&B->arr[16],0.6,0.7,0.9);
	Set_Box_Size(&B->arr[16],1.5,1.5,5);
	Set_Box_Location(&B->arr[16],-3,12.5,-4.5);
	Set_Box_Rotation(&B->arr[16],0,-70,0);

	Set_Box_Color(&B->arr[17],0.6,0.7,0.9);
	Set_Box_Size(&B->arr[17],1.5,1.5,5);
	Set_Box_Location(&B->arr[17],3,12.5,-4.5);
	Set_Box_Rotation(&B->arr[17],0,70,0);

	Set_Box_Color(&B->arr[18],1,1,1);
	Set_Box_Size(&B->arr[18],1.8,1.8,1.8);
	Set_Box_Location(&B->arr[18],0,12.5,-6);
	Set_Box_Rotation(&B->arr[18],0,0,0);

	Set_Box_Color(&B->arr[19],1,1,1);
	Set_Box_Size(&B->arr[19],0.8,2,0.8);
	Set_Box_Location(&B->arr[19],0,13.5,-6);
	Set_Box_Rotation(&B->arr[19],0,0,0);

	Set_Box_Color(&B->arr[20],1,1,1);
	Set_Box_Size(&B->arr[20],4,1,1);
	Set_Box_Location(&B->arr[20],0,14.5,-6);
	Set_Box_Rotation(&B->arr[20],0,0,0);

	Set_Box_Color(&B->arr[21],1,1,1);
	Set_Box_Size(&B->arr[21],1.5,1.5,1.5);
	Set_Box_Location(&B->arr[21],0,19,0);
	Set_Box_Rotation(&B->arr[21],0,0,0);

	Set_Box_Color(&B->arr[22],1,0.9,0.8);
	Set_Box_Size(&B->arr[22],3,3,4);
	Set_Box_Location(&B->arr[22],0,21,0);
	Set_Box_Rotation(&B->arr[22],0,180,0);

	Set_Box_Color(&B->arr[23],1,1,0);
	Set_Box_Size(&B->arr[23],5,5,5);
	Set_Box_Location(&B->arr[23],0,19,2);
	Set_Box_Rotation(&B->arr[23],0,0,0);

	Set_Box_Color(&B->arr[24],1,0.4,0.5);
	Set_Box_Size(&B->arr[24],0.6,2.5,0.6);
	Set_Box_Location(&B->arr[24],1,23,0);
	Set_Box_Rotation(&B->arr[24],-45,0,0);

	Set_Box_Color(&B->arr[25],1,0.4,0.5);
	Set_Box_Size(&B->arr[25],0.6,2.5,0.6);
	Set_Box_Location(&B->arr[25],-1,23,0);
	Set_Box_Rotation(&B->arr[25],-45,0,0);

	Set_Box_Color(&B->arr[26],1,1,1);
	Set_Box_Size(&B->arr[26],3,15,0.8);
	Set_Box_Location(&B->arr[26],0,22,-6);
	Set_Box_Rotation(&B->arr[26],0,0,0);
}
void Building_Type_24(Building *B)
{

	B->Size=27;
	B->arr=(Box*)malloc(sizeof(Box)*27);

	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,13,0.5,13);
	Set_Box_Location(&B->Tank_Bound,0,0,-1);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],1*4,1,1);
	Set_Box_Size(&B->arr[0],13,0.5,13);
	Set_Box_Location(&B->arr[0],0,0.25,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],1,0.9,1);
	Set_Box_Size(&B->arr[1],2,4.5,2);
	Set_Box_Location(&B->arr[1],2,2.25,0);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],1,0.9,1);
	Set_Box_Size(&B->arr[2],2,4.5,2);
	Set_Box_Location(&B->arr[2],-2,2.25,0);
	Set_Box_Rotation(&B->arr[2],0,0,0);

	Set_Box_Color(&B->arr[3],0.6,0.5,0.2);
	Set_Box_Size(&B->arr[3],2.2,2.2,2.2);
	Set_Box_Location(&B->arr[3],-2,5.5,0);
	Set_Box_Rotation(&B->arr[3],0,0,0);

	Set_Box_Color(&B->arr[4],0.6,0.5,0.2);
	Set_Box_Size(&B->arr[4],2.2,2.2,2.2);
	Set_Box_Location(&B->arr[4],2,5.5,0);
	Set_Box_Rotation(&B->arr[4],0,0,0);

	Set_Box_Color(&B->arr[5],1,0.9,1);
	Set_Box_Size(&B->arr[5],2.5,5,2.5);
	Set_Box_Location(&B->arr[5],-2,9,0);
	Set_Box_Rotation(&B->arr[5],0,0,0);

	Set_Box_Color(&B->arr[6],1,0.9,1);
	Set_Box_Size(&B->arr[6],2.5,5,2.5);
	Set_Box_Location(&B->arr[6],2,9,0);
	Set_Box_Rotation(&B->arr[6],0,0,0);

	Set_Box_Color(&B->arr[7],0.5,0.5,0.5);
	Set_Box_Size(&B->arr[7],2.5,3,3.5);
	Set_Box_Location(&B->arr[7],-2,0,1);
	Set_Box_Rotation(&B->arr[7],0,0,0);

	Set_Box_Color(&B->arr[8],0.5,0.5,0.5);
	Set_Box_Size(&B->arr[8],2.5,3,3.5);
	Set_Box_Location(&B->arr[8],2,0,1);
	Set_Box_Rotation(&B->arr[8],0,0,0);

	Set_Box_Color(&B->arr[9],0.7,0.7,0.7);
	Set_Box_Size(&B->arr[9],8,9,4);
	Set_Box_Location(&B->arr[9],0,14,0);
	Set_Box_Rotation(&B->arr[9],0,0,0);

	Set_Box_Color(&B->arr[10],0.5,1,1);
	Set_Box_Size(&B->arr[10],3,3,3);
	Set_Box_Location(&B->arr[10],5,18,0);
	Set_Box_Rotation(&B->arr[10],0,0,0);

	Set_Box_Color(&B->arr[11],0.5,1,1);
	Set_Box_Size(&B->arr[11],3,3,3);
	Set_Box_Location(&B->arr[11],-5,18,0);
	Set_Box_Rotation(&B->arr[11],0,0,0);

	Set_Box_Color(&B->arr[12],0.6,0.7,1);
	Set_Box_Size(&B->arr[12],2,5,2);
	Set_Box_Location(&B->arr[12],5,15,2);
	Set_Box_Rotation(&B->arr[12],-30,0,0);

	Set_Box_Color(&B->arr[13],0.6,0.7,1);
	Set_Box_Size(&B->arr[13],2,5,2);
	Set_Box_Location(&B->arr[13],-5,15,2);
	Set_Box_Rotation(&B->arr[13],-30,0,0);


	Set_Box_Color(&B->arr[14],0.8,0.8,0.1);
	Set_Box_Size(&B->arr[14],2.2,2,2.2);
	Set_Box_Location(&B->arr[14],5,12.5,3);
	Set_Box_Rotation(&B->arr[14],0,0,0);

	Set_Box_Color(&B->arr[15],0.8,0.8,0.1);
	Set_Box_Size(&B->arr[15],2.2,2,2.2);
	Set_Box_Location(&B->arr[15],-5,12.5,3);
	Set_Box_Rotation(&B->arr[15],0,0,0);

	Set_Box_Color(&B->arr[16],0.6,0.7,0.9);
	Set_Box_Size(&B->arr[16],1.5,1.5,5);
	Set_Box_Location(&B->arr[16],-3,12.5,4.5);
	Set_Box_Rotation(&B->arr[16],0,70,0);

	Set_Box_Color(&B->arr[17],0.6,0.7,0.9);
	Set_Box_Size(&B->arr[17],1.5,1.5,5);
	Set_Box_Location(&B->arr[17],3,12.5,4.5);
	Set_Box_Rotation(&B->arr[17],0,-70,0);

	Set_Box_Color(&B->arr[18],1,1,1);
	Set_Box_Size(&B->arr[18],1.8,1.8,1.8);
	Set_Box_Location(&B->arr[18],0,12.5,6);
	Set_Box_Rotation(&B->arr[18],0,0,0);

	Set_Box_Color(&B->arr[19],1,1,1);
	Set_Box_Size(&B->arr[19],0.8,2,0.8);
	Set_Box_Location(&B->arr[19],0,13.5,6);
	Set_Box_Rotation(&B->arr[19],0,0,0);

	Set_Box_Color(&B->arr[20],1,1,1);
	Set_Box_Size(&B->arr[20],4,1,1);
	Set_Box_Location(&B->arr[20],0,14.5,6);
	Set_Box_Rotation(&B->arr[20],0,0,0);

	Set_Box_Color(&B->arr[21],1,1,1);
	Set_Box_Size(&B->arr[21],1.5,1.5,1.5);
	Set_Box_Location(&B->arr[21],0,19,0);
	Set_Box_Rotation(&B->arr[21],0,0,0);

	Set_Box_Color(&B->arr[22],1,0.9,0.8);
	Set_Box_Size(&B->arr[22],3,3,4);
	Set_Box_Location(&B->arr[22],0,21,0);
	Set_Box_Rotation(&B->arr[22],0,0,0);

	Set_Box_Color(&B->arr[23],1,1,0);
	Set_Box_Size(&B->arr[23],5,5,5);
	Set_Box_Location(&B->arr[23],0,19,-2);
	Set_Box_Rotation(&B->arr[23],0,0,0);

	Set_Box_Color(&B->arr[24],1,0.4,0.5);
	Set_Box_Size(&B->arr[24],0.6,2.5,0.6);
	Set_Box_Location(&B->arr[24],1,23,0);
	Set_Box_Rotation(&B->arr[24],45,0,0);

	Set_Box_Color(&B->arr[25],1,0.4,0.5);
	Set_Box_Size(&B->arr[25],0.6,2.5,0.6);
	Set_Box_Location(&B->arr[25],-1,23,0);
	Set_Box_Rotation(&B->arr[25],45,0,0);

	Set_Box_Color(&B->arr[26],1,1,1);
	Set_Box_Size(&B->arr[26],3,15,0.8);
	Set_Box_Location(&B->arr[26],0,22,6);
	Set_Box_Rotation(&B->arr[26],0,0,0);
}
void Building_Type_25(Building *B)
{
	B->Size=8;
	B->arr=(Box*)malloc(sizeof(Box)*8);

	Set_Box_Color(&B->Tank_Bound,1,1,1);
	Set_Box_Size(&B->Tank_Bound,8,1,8);
	Set_Box_Location(&B->Tank_Bound,0,0,0);
	Set_Box_Rotation(&B->Tank_Bound,0,0,0);

	Set_Box_Color(&B->arr[0],0.6,0.6,0.6);
	Set_Box_Size(&B->arr[0],2,2,2);
	Set_Box_Location(&B->arr[0],0,0,0);
	Set_Box_Rotation(&B->arr[0],0,0,0);

	Set_Box_Color(&B->arr[1],0.2,0.2,0.2);
	Set_Box_Size(&B->arr[1],0.5,2,2);
	Set_Box_Location(&B->arr[1],0,-1,0);
	Set_Box_Rotation(&B->arr[1],0,0,0);

	Set_Box_Color(&B->arr[2],0.2,0.2,0.2);
	Set_Box_Size(&B->arr[2],2,2,0.5);
	Set_Box_Location(&B->arr[2],0,-3,0);
	Set_Box_Rotation(&B->arr[2],0,0,0);

	Set_Box_Color(&B->arr[3],0.2,0.2,0.2);
	Set_Box_Size(&B->arr[3],0.5,2,2);
	Set_Box_Location(&B->arr[3],0,-5,0);
	Set_Box_Rotation(&B->arr[3],0,0,0);

	Set_Box_Color(&B->arr[4],0.2,0.2,0.2);
	Set_Box_Size(&B->arr[4],2,2,0.5);
	Set_Box_Location(&B->arr[4],0,-7,0);
	Set_Box_Rotation(&B->arr[4],0,0,0);

	Set_Box_Color(&B->arr[5],0.2,0.2,0.2);
	Set_Box_Size(&B->arr[5],0.5,2,2);
	Set_Box_Location(&B->arr[5],0,-9,0);
	Set_Box_Rotation(&B->arr[5],0,0,0);

	Set_Box_Color(&B->arr[6],0.2,0.2,0.2);
	Set_Box_Size(&B->arr[6],2,2,0.5);
	Set_Box_Location(&B->arr[6],0,-11,0);
	Set_Box_Rotation(&B->arr[6],0,0,0);

	Set_Box_Color(&B->arr[7],0.7,0.7,0.7);
	Set_Box_Size(&B->arr[7],5,5,5);
	Set_Box_Location(&B->arr[7],0,-15,0);
	Set_Box_Rotation(&B->arr[7],0,0,0);
}

void Set_Building(Building *B,float x,float y,float z,int Type)
{
	Set_Location(&B->location,x,y,z);
	Set_Rotation(&B->rotation,0,0,0);
	B->Health=100;
	B->Type=Type;
	switch (Type)
	{
	case 0:
		Building_Type_0(B);
			break;
	case 1:
		Building_Type_1(B);
			break;
	case 2:
		Building_Type_2(B);
			break;
	case 3:
		Building_Type_3(B);
			break;
	case 4:
		Building_Type_4(B);
			break;
	case 5:
		Building_Type_5(B);
			break;
	case 6:
		Building_Type_6(B);
			break;
	case 7:
		Building_Type_7(B);
			break;
	case 8:
		Building_Type_8(B);
			break;
	case 9:
		Building_Type_9(B);
			break;
	case 11:
		Building_Type_11(B);
			break;
	case 12:
		Building_Type_12(B);
			break;
	case 13:
		Building_Type_13(B);
			break;
	case 14:
		Building_Type_14(B);
			break;
	case 15:
		Building_Type_15(B);
			break;
	case 16:
		Building_Type_16(B);
			break;
	case 17:
		Building_Type_17(B);
			break;
	case 18:
		Building_Type_18(B);
			break;
	case 19:
		Building_Type_19(B);
			break;
	case 20:
		Building_Type_20(B);
			break;
	case 21:
		Building_Type_21(B);
			break;
	case 22:
		Building_Type_22(B);
			break;
	case 23:
		Building_Type_23(B);
			break;
	case 24:
		Building_Type_24(B);
			break;
	case 25:
		Building_Type_25(B);
			break;

	default:
		Building_Type_0(B);
		break;
	}

}
void Set_Wall(Building *B,float x,float y,float z,float Size_x,float Size_y,float Size_z)
{
		Set_Location(&B->location,x,y,z);
		Set_Rotation(&B->rotation,0,0,0);
		B->Health=100;
		B->Type=10;
		B->Size=1;
		B->arr=(Box*)malloc(sizeof(Box)*1);

		Set_Box_Color(&B->Tank_Bound,1,1,1);
		Set_Box_Size(&B->Tank_Bound,Size_x,Size_y,Size_z);
		Set_Box_Location(&B->Tank_Bound,0,Size_y/2,0);
		Set_Box_Rotation(&B->Tank_Bound,0,0,0);

		Set_Box_Color(&B->arr[0],0.7,0.9,0.3);
		Set_Box_Size(&B->arr[0],Size_x,Size_y,Size_z);
		Set_Box_Location(&B->arr[0],0,Size_y/2,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);

}
void Draw_Building(Building *B)
{
	if(B->Type==Map_4_Build_2)
	{
		Go_Location(B->location);
		Rotation_Open(B->rotation,0,1,0);
		for(int i=0;i<B->Size-1;i++)
			Draw_Box_TR(B->arr[i]);
		Go_Location(B->arr[7].location);
			Color_On(B->arr[7].color);
			glutSolidSphere(2.5,32,32);
		Back_Location(B->arr[7].location);
		Rotation_Close(B->rotation,0,1,0);
		Back_Location(B->location);
		return;
	}
	if(B->Type==8 || B->Type==9)
	{
		Go_Location(B->location);
		Rotation_Open(B->rotation,0,1,0);
		Draw_Box_TR(B->arr[0]);
		Draw_Shapped_Box_Up(B->arr[1],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[2],-1,0,-1);
		Rotation_Close(B->rotation,0,1,0);
		Back_Location(B->location);
		return;
	}
	if(B->Type==6 || B->Type==7)
	{
		Go_Location(B->location);
		Rotation_Open(B->rotation,0,1,0);
		for(int i=0;i<5;i++)
			Draw_Box_TR(B->arr[i]);
		Draw_Shapped_Box_Up(B->arr[5],-1,0,-0.5);
		Draw_Shapped_Box_Up(B->arr[6],-0.5,0,-0.5);
		Draw_Shapped_Box_Up(B->arr[7],-0.5,0,-0.5);
		Rotation_Close(B->rotation,0,1,0);
		Back_Location(B->location);
		return;
	}
	if(B->Type==0 ||
	   B->Type==1 ||
	   B->Type==4 || 
	   B->Type==25 ||
	   B->Type==10  ||
	   B->Type==5  )
	{
		Go_Location(B->location);
		Rotation_Open(B->rotation,0,1,0);
		for(int i=0;i<B->Size;i++)
			Draw_Box_TR(B->arr[i]);
		Rotation_Close(B->rotation,0,1,0);
		Back_Location(B->location);
		return;
	}
	if(B->Type==2 || B->Type==3)
	{
		Go_Location(B->location);
		Rotation_Open(B->rotation,0,1,0);
		for(int i=0;i<6;i++)
			Draw_Box_TR(B->arr[i]);
		Draw_Shapped_Box_Up(B->arr[6],-5,0,-5);
		for(int i=7;i<B->Size;i++)
			Draw_Box_TR(B->arr[i]);
		Rotation_Close(B->rotation,0,1,0);
		Back_Location(B->location);
		return;
	}
	if(B->Type==11 || B->Type==12)
	{
		Go_Location(B->location);
		Rotation_Open(B->rotation,0,1,0);
		Draw_Shapped_Box_Up(B->arr[0],-7.5,0,-7.5);
		Draw_Shapped_Box_Up(B->arr[1],-0.5,0,-0.5);
		Draw_Shapped_Box_Up(B->arr[2],-0.5,0,-0.5);
		Draw_Shapped_Box_Up(B->arr[3],-0.5,0,-0.5);
		Draw_Shapped_Box_Up(B->arr[4],-0.5,0,-0.5);
		Draw_Shapped_Box_Up(B->arr[5],-0.4,0,0);
		Draw_Shapped_Box_Up(B->arr[6],-0.4,0,0);
		Draw_Shapped_Box_Up(B->arr[7],0.4,0,-0.2);
		Draw_Shapped_Box_Up(B->arr[8],0,0,0);	
		Rotation_Close(B->rotation,0,1,0);
		Back_Location(B->location);
		return;
	}
	if(B->Type==13)
	{
		Go_Location(B->location);
		Rotation_Open(B->rotation,0,1,0);
		Draw_Box_TR(B->arr[0]);
		Draw_Shapped_Box_Up(B->arr[1],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[2],-1,0,-1);
		Draw_Shapped_Box_Up(B->arr[3],-0.25,0,0);
		Draw_Shapped_Box_Up(B->arr[4],0,0,-0.25);
		Rotation_Close(B->rotation,0,1,0);
		Back_Location(B->location);
		return;
	}
	if(B->Type==14)
	{
		Go_Location(B->location);
		Rotation_Open(B->rotation,0,1,0);
		Draw_Shapped_Box_Up(B->arr[0],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[1],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[2],-0.05,0,-0.05);
		for(int i=3;i<6;i++)
			Draw_Box_TR(B->arr[i]);
		Draw_Shapped_Box_Up(B->arr[6],-0.5,0,-0.5);
		Draw_Shapped_Box_Up(B->arr[7],-0.5,0,-0.5);
		Draw_Shapped_Box_Up(B->arr[8],-1,0,-1);
		glColor3f(0,1,0);
		glTranslatef(0,10,0);
		glutSolidSphere(1,10,10);
		glTranslatef(0,-10,0);
		Rotation_Close(B->rotation,0,1,0);
		Back_Location(B->location);
		return;
	}
	if(B->Type==15)
	{
		Go_Location(B->location);
		Rotation_Open(B->rotation,0,1,0);
		Draw_Shapped_Box_Up(B->arr[0],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[1],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[2],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[3],-0.1,0,-0.1);
		Draw_Shapped_Box_Up(B->arr[4],-0.1,0,-0.1);
		Rotation_Close(B->rotation,0,1,0);
		Back_Location(B->location);
		return;
	}
	if(B->Type==16)
	{
		Go_Location(B->location);
		Rotation_Open(B->rotation,0,1,0);
		Draw_Shapped_Box_Up(B->arr[0],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[1],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[2],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[3],-0.1,0,-0.1);
		Draw_Shapped_Box_Up(B->arr[4],-0.1,0,-0.1);
		Rotation_Close(B->rotation,0,1,0);
		Back_Location(B->location);
		return;
	}
	if(B->Type==17)
	{
		Go_Location(B->location);
		Rotation_Open(B->rotation,0,1,0);
		Draw_Shapped_Box_Up(B->arr[0],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[1],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[2],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[3],-0.1,0,-0.1);
		Draw_Shapped_Box_Up(B->arr[4],-0.1,0,-0.1);
		Draw_Shapped_Box_Up(B->arr[5],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[6],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[7],-0.1,0,-0.1);
		Draw_Shapped_Box_Up(B->arr[8],-0.1,0,-0.1);
		Draw_Shapped_Box_Up(B->arr[9],-0.1,0,-0.1);
		Rotation_Close(B->rotation,0,1,0);
		Back_Location(B->location);
		return;
	}
	if(B->Type==18 || B->Type==19)
	{
		Go_Location(B->location);
		Rotation_Open(B->rotation,0,1,0);
		Draw_Shapped_Box_Up(B->arr[0],-0.25,0,-0.25);
		Draw_Shapped_Box_Up(B->arr[1],0,0,0);
		Draw_Shapped_Box_Up(B->arr[2],-0.25,0,-0.25);
		Rotation_Close(B->rotation,0,1,0);
		Back_Location(B->location);
		return;
	}
	if(B->Type==20)
	{
		Go_Location(B->location);
		Rotation_Open(B->rotation,0,1,0);
		Draw_Shapped_Box_Up(B->arr[0],-0.5,0,0);
		Draw_Shapped_Box_Up(B->arr[1],-0.5,0,0);
		Draw_Shapped_Box_Up(B->arr[2],0.2,0,0);
		Draw_Shapped_Box_Up(B->arr[3],0,0,0);
		Rotation_Close(B->rotation,0,1,0);
		Back_Location(B->location);
		return;
	}
	if(B->Type==21||B->Type==22||B->Type==23||B->Type==24)
	{
	glDisable(GL_FOG);
		Go_Location(B->location);
		Rotation_Open(B->rotation,0,1,0);
		Draw_Shapped_Box_Up(B->arr[0],0,0,0);
		Draw_Shapped_Box_Up(B->arr[1],0,0,0.2);
		Draw_Shapped_Box_Up(B->arr[2],0,0,0.2);
		Draw_Shapped_Box_Up(B->arr[3],0,0,0);
		Draw_Shapped_Box_Up(B->arr[4],0,0,0);
		Draw_Shapped_Box_Up(B->arr[5],0,0,0);
		Draw_Shapped_Box_Up(B->arr[6],0,0,0);
		Draw_Shapped_Box_Front(B->arr[7],0,-1,0);
		Draw_Shapped_Box_Front(B->arr[8],0,-1,0);
		Draw_Shapped_Box_Up(B->arr[9],-0.6,0,-0.5);
		Draw_Shapped_Box_Up(B->arr[10],0,0,0);
		Draw_Shapped_Box_Up(B->arr[11],0,0,0);
		Draw_Shapped_Box_Up(B->arr[12],0,0,0);
		Draw_Shapped_Box_Up(B->arr[13],0,0,0);
		Draw_Shapped_Box_Up(B->arr[14],0,0,0);
		Draw_Shapped_Box_Up(B->arr[15],0,0,0);
		Draw_Shapped_Box_Up(B->arr[16],0,0,0);
		Draw_Shapped_Box_Up(B->arr[17],0,0,0);
		Draw_Shapped_Box_Up(B->arr[18],0,0,0);
		Draw_Shapped_Box_Up(B->arr[19],0,0,0);
		Draw_Shapped_Box_Up(B->arr[20],0,0,0);
		Draw_Shapped_Box_Up(B->arr[21],0,0,0);
		Draw_Shapped_Box_Front(B->arr[22],0,-0.5,0);
		Draw_Shapped_Box_Up(B->arr[23],-2,0,-2);
		Draw_Shapped_Box_Up(B->arr[24],-0.3,0,-0.3);
		Draw_Shapped_Box_Up(B->arr[25],-0.3,0,-0.3);
		if(B->Type==23||B->Type==24)
			Draw_Shapped_Box_Up(B->arr[26],-1.5,0,-0.4);
		if(B->Type==21||B->Type==22)
		{
			Draw_Shapped_Box_Up(B->arr[26],-1,0,-1);
			glColor3f(0.4,0.5,1);
			Go_Location(B->arr[26].location);
			glutSolidSphere(1,8,8);
			Back_Location(B->arr[26].location);
		}
		Rotation_Close(B->rotation,0,1,0);
		Back_Location(B->location);
	glEnable(GL_FOG);
	}
}
void Build_Movement(Building *B)
{
	if(B->Type==Map_4_Build_2)
	{
		if(B->arr[7].rotation.x>80 || B->arr[7].rotation.x<-80)
			B->MoveFlag=!B->MoveFlag;
		Set_Location(&B->arr[7].location,0
			,-15*cos(B->arr[7].rotation.x*PI/180)
			,-15*sin(B->arr[7].rotation.x*PI/180));
		for(int i=1;i<7;i++)
			Set_Location(&B->arr[i].location,0
			,-i*2*cos(B->arr[7].rotation.x*PI/180)
			,-i*2*sin(B->arr[7].rotation.x*PI/180));
		if(B->MoveFlag)
			for(int i=1;i<8;i++)
				B->arr[i].rotation.x++;
		else
			for(int i=1;i<8;i++)
				B->arr[i].rotation.x--;
	}

	if(B->location.y<-25)return;
	if(B->Type==Map_4_Build_1||
	   B->Type==Map_3_Build_11||
	   B->Type==Map_3_Build_10||
	   B->Type==Map_3_Build_1||
	   B->Type==Map_3_Build_2||
	   B->Type==Map_1_Build_6||
	   B->Type==Map_1_Build_5||
	   B->Type==Map_Wall ||
	   B->Type==Map_4_Build_2)return;

		if(B->Health<0)
			if(B->location.y>-25)
			{
				B->location.y-=0.05;
				if(B->Shake%2==0)
					B->location.x+=0.2;
				else 
					B->location.x-=0.2;
				B->Shake++;
			}
}
//Button
void Set_Button(Button *btn,float x,float y,float Side,float r,float g,float b,char *str)
{
	int i=0;
	while(*(str+i)!=0)
		btn->str[i]=*(str+(i++));
	Set_Color(&btn->color,r,g,b);
	btn->x=x;
	btn->y=y;
	btn->Side=Side;
}
void Draw_Button(Button *btn)
{
	Color_On(btn->color);
	glBegin(GL_LINE_LOOP);
        glVertex3f(btn->x+btn->Side , btn->y+btn->Side/3 ,-5);
        glVertex3f(btn->x-btn->Side , btn->y+btn->Side/3 ,-5);
        glVertex3f(btn->x-btn->Side , btn->y-btn->Side/3 ,-5);
        glVertex3f(btn->x+btn->Side , btn->y-btn->Side/3 ,-5);
    glEnd();
	btn->strPointer=btn->str;
	glColor3f(0,0,0);
	glRasterPos3f(btn->x-0.5, btn->y, -5);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *btn->strPointer); while (*(++btn->strPointer));
}
int ClickButton(Button btn,int x,int y)
{
	if(x>770+(btn.x*150)-(btn.Side*150) && x<770 +(btn.x*150)+(btn.Side*150))
		if(y>430+(btn.y*-150)-(btn.Side*50) && y<430 +(btn.y*-150)+(btn.Side*50))
		{
			return 1;
		}
	return 0;
}
void Type_Name(char *str,char ch)
{
	if(strlen(str)>10)return;
	int i=0;
	while(*(str+i)!=0)
		i++;
	*(str+(i++))=ch;
	*(str+i)=0;
}
void Remove_Char(char *str)
{
	int i=0;
	if(str=="")return;
	*(str+(strlen(str)-1))=0;
}
void Copy_String(char *str1,char *str2)
{
	int i=0;
	while(*(str2+i)!=0)
		*(str1+i)=*(str2+(i++));
	*(str1+i)=0;
}
//GameList
GameList *Create_Game(float x,float y,char *str1,char *str2,char *Winner)
{
	GameList *NewGameList;
	NewGameList=(GameList*)malloc(sizeof(GameList));
	NewGameList->x=x;
	NewGameList->y=y;
	Copy_String(NewGameList->Player1,str1);
	Copy_String(NewGameList->Player2,str2);
	Copy_String(NewGameList->Winner,Winner);
	
	NewGameList->next=nullptr;
	return NewGameList;
}
GameList *Add_GameList(GameList *head,GameList *NewGameList)
{
	GameList *tmp;
	if(head==nullptr)
	{
		head=NewGameList;
		return head;
	}
	tmp=head;
	while(tmp->next!=nullptr)
		tmp=tmp->next;
	tmp->next=NewGameList;
	return head;
}
void Draw_Gamelist(GameList *Game_List)
{
	glColor3f(0,0,0);
	Game_List->str=Game_List->Player1;
	glRasterPos3f(Game_List->x-1, Game_List->y, -5);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *Game_List->str); while (*(++Game_List->str));

	Game_List->str=Game_List->Player2;
	glRasterPos3f(Game_List->x, Game_List->y, -5);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *Game_List->str); while (*(++Game_List->str));

	glColor3f(1,1,0);
	Game_List->str=Game_List->Winner;
	glRasterPos3f(Game_List->x+1.5, Game_List->y, -5);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *Game_List->str); while (*(++Game_List->str));
}
//String
void Draw_String_int(float r,float g,float b,float x,float y,float z,char *s,int val)
{
	char str[80];
	Copy_String(str,s);
	sprintf_s(str,s,val);
	char *strP=str;
	glColor3f(r,g,b);
	glRasterPos3f(x, y, z);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *strP); while (*(++strP));
}
void Draw_String_float(float r,float g,float b,float x,float y,float z,char *s,float val)
{
	char str[80];
	Copy_String(str,s);
	sprintf_s(str,s,val);
	char *strP=str;
	glColor3f(r,g,b);
	glRasterPos3f(x, y, z);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *strP); while (*(++strP));
}
void Draw_String(float r,float g,float b,float x,float y,float z,char *s)
{
	char *strP=s;
	glColor3f(r,g,b);
	glRasterPos3f(x, y, z);
	do glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *strP); while (*(++strP));
}
void Draw_Square(float x,float y,float Side,float r,float g,float b)
{
	glColor3f(r,g,b);
	glBegin(GL_POLYGON);
        glVertex3f( x + Side, y+ Side/3,-5.01);
        glVertex3f( x- Side,  y+ Side/3,-5.01);
        glVertex3f( x- Side,  y- Side/3,-5.01);
        glVertex3f( x+ Side,  y- Side/3,-5.01);
    glEnd();
    glFlush();
}
//Bonus
void Set_Bouns(Bonus *B,float x,float y,float z,int Type)
{
	Set_Location(&B->location,x,y,z);
	Set_Box_Color(&B->Bound,0,0,1);
	Set_Box_Size(&B->Bound,1,1,1);
	Set_Box_Location(&B->Bound,0,0.5,0);
	Set_Box_Rotation(&B->Bound,0,0,0);

	B->Type=Type;
	if(Type==0)
	{
		Set_Box_Color(&B->arr[0],0,0,1);
		Set_Box_Size(&B->arr[0],0.2,1,0.2);
		Set_Box_Location(&B->arr[0],0,0.7,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);

		Set_Box_Color(&B->arr[1],0,0,1);
		Set_Box_Size(&B->arr[1],0.2,1,0.2);
		Set_Box_Location(&B->arr[1],0.5,0.5,0);
		Set_Box_Rotation(&B->arr[1],0,0,0);

		Set_Box_Color(&B->arr[2],0,0,1);
		Set_Box_Size(&B->arr[2],0.2,1,0.2);
		Set_Box_Location(&B->arr[2],-0.5,0.5,0);
		Set_Box_Rotation(&B->arr[2],0,0,0);
	}
	if(Type==1)
	{

		Set_Box_Color(&B->arr[0],1,1,1);
		Set_Box_Size(&B->arr[0],0.2,1,0.2);
		Set_Box_Location(&B->arr[0],0,0.5,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);

		Set_Box_Color(&B->arr[1],1,0,0);
		Set_Box_Size(&B->arr[1],0.2,0.2,0.2);
		Set_Box_Location(&B->arr[1],0,1.1,0);
		Set_Box_Rotation(&B->arr[1],0,0,0);

		Set_Box_Color(&B->arr[2],0,0,1);
		Set_Box_Size(&B->arr[2],0.5,0.2,0.2);
		Set_Box_Location(&B->arr[2],0,0,0);
		Set_Box_Rotation(&B->arr[2],0,0,0);
	}
	if(Type==2)
	{
		Set_Box_Color(&B->arr[0],0,1,0);
		Set_Box_Size(&B->arr[0],1,0.2,0.2);
		Set_Box_Location(&B->arr[0],0,0.5,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);

		Set_Box_Color(&B->arr[1],0,1,0);
		Set_Box_Size(&B->arr[1],1.2,0.2,0.2);
		Set_Box_Location(&B->arr[1],0,0.7,0);
		Set_Box_Rotation(&B->arr[1],0,0,0);

		Set_Box_Color(&B->arr[2],0,1,0);
		Set_Box_Size(&B->arr[2],1,0.2,0.2);
		Set_Box_Location(&B->arr[2],0,0.9,0);
		Set_Box_Rotation(&B->arr[2],0,0,0);
	}
	if(Type==3)
	{
		Set_Box_Color(&B->arr[0],1,1,0);
		Set_Box_Size(&B->arr[0],0.3,0.2,0.2);
		Set_Box_Location(&B->arr[0],0,0.5,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);

		Set_Box_Color(&B->arr[1],1,1,0);
		Set_Box_Size(&B->arr[1],0.5,0.2,0.2);
		Set_Box_Location(&B->arr[1],0,0.7,0);
		Set_Box_Rotation(&B->arr[1],0,0,0);

		Set_Box_Color(&B->arr[2],1,1,0);
		Set_Box_Size(&B->arr[2],0.3,0.2,0.2);
		Set_Box_Location(&B->arr[2],0,0.9,0);
		Set_Box_Rotation(&B->arr[2],0,0,0);
	}
	if(Type==4)
	{
		Set_Box_Color(&B->arr[0],1,0,0);
		Set_Box_Size(&B->arr[0],0.5,0.7,0.2);
		Set_Box_Location(&B->arr[0],0,0.5,0);
		Set_Box_Rotation(&B->arr[0],0,0,0);

		Set_Box_Color(&B->arr[1],1,0,0);
		Set_Box_Size(&B->arr[1],0.1,1,0.2);
		Set_Box_Location(&B->arr[1],0.3,0.6,0);
		Set_Box_Rotation(&B->arr[1],0,0,-45);

		Set_Box_Color(&B->arr[2],1,0,0);
		Set_Box_Size(&B->arr[2],0.2,0.2,0.2);
		Set_Box_Location(&B->arr[2],-0.1,0.9,0);
		Set_Box_Rotation(&B->arr[2],0,0,0);
	}
}
void Draw_Bonus(Bonus *B)
{
	if(B->Type==-1)return;
	B->rotation.y+=2;
	B->rotation.y%=360;
	Go_Location(B->location);
	Rotation_Open(B->rotation,0,1,0);
	Draw_Box_TR(B->arr[0]);
	Draw_Box_TR(B->arr[1]);
	Draw_Box_TR(B->arr[2]);
	Rotation_Close(B->rotation,0,1,0);
	Back_Location(B->location);
}
void Bonus_Movement(Bonus *B)
{
	if(B->Status == DAWN_BOUND || B->location.y<0 && B->Status!=CATCHED){
		B->location.y+=0.1;
		B->Status=0;
	}
	if(B->Status == FALLEN && B->location.y>0)
		B->location.y-=0.05*GlobalSpeed;
}
//Trailer_And_Train
void Trailer_Launch_Missile(Trailer *T,int Height)
{
	if(T->ML.missile.status!=NOT_ACTIVE)
	{
		if(T->ML.missile.status==2)
		{
			Copy_Location(&T->ML.missile.location,T->location);
			T->ML.missile.location.y+=Height;
			for(int i=0;i<4;i++){
				Copy_Location(&T->ML.missile.smoke[i].location,T->ML.missile.location);
				T->ML.missile.smoke[i].Radius=i*0.2;
			}
		}
	}
}
void Set_Trailer(Trailer *T,float x,float y,float z,int Type)
{
	Set_Location(&T->location,x,y,z);
	T->rotation.y=90;
	T->Type=Type;

	Set_Wheel(&T->wheel[0], 0.4,0.3,1,0.4);
	Set_Wheel(&T->wheel[1], 0.4,0.3,-1,0.4);
	Set_Wheel(&T->wheel[2],-0.4,0.3,1,0.4);
	Set_Wheel(&T->wheel[3],-0.4,0.3,-1,0.4);

	if(Type==0)
	{
		Set_Box_Color(&T->B1,0.5,0.5,0.5);
		Set_Box_Size(&T->B1,1.5,1,3);
		Set_Box_Location(&T->B1,0,1,0);
		Set_Box_Rotation(&T->B1,0,0,0);

		Set_Box_Color(&T->B2,0,0,1);
		Set_Box_Size(&T->B2,1,1,0.8);
		Set_Box_Location(&T->B2,0,1.5,-0.5);
		Set_Box_Rotation(&T->B2,0,0,0);

		Set_Box_Color(&T->B3,0,0,1);
		Set_Box_Size(&T->B3,0.3,1.5,0.3);
		Set_Box_Location(&T->B3,0,2.25,0.7);
		Set_Box_Rotation(&T->B3,0,0,0);
	}
	if(Type==1)
	{
		Set_Box_Color(&T->B1,0.5,0.5,0.5);
		Set_Box_Size(&T->B1,1.5,0.5,3);
		Set_Box_Location(&T->B1,0,1,0);
		Set_Box_Rotation(&T->B1,0,0,0);

		Set_Box_Color(&T->B2,0.4,0.4,0.4);
		Set_Box_Size(&T->B2,0.2,0.2,4);
		Set_Box_Location(&T->B2,0,0.5,2);
		Set_Box_Rotation(&T->B2,0,0,0);

		Set_Box_Color(&T->Missile_Area,0,0,0);
		Set_Box_Size(&T->Missile_Area,20,20,20);
		Set_Box_Location(&T->Missile_Area,0,10,0);
		Set_Box_Rotation(&T->Missile_Area,0,0,0);
		T->ML.missile.Damage=MISSILE_DAMAGE;
		Set_MissileLauncher(&T->ML,0,1.5,0,Type-1);
		T->ML.Launch_Location=&T->location;
		T->ML.trailer=T;
	}
	if(Type==2)
	{
		Set_Box_Color(&T->B1,0.5,0.5,0.5);
		Set_Box_Size(&T->B1,1.5,0.5,3);
		Set_Box_Location(&T->B1,0,1,0);
		Set_Box_Rotation(&T->B1,0,0,0);

		Set_Box_Color(&T->B2,0.4,0.4,0.4);
		Set_Box_Size(&T->B2,0.2,0.2,4);
		Set_Box_Location(&T->B2,0,0.5,2);
		Set_Box_Rotation(&T->B2,0,0,0);

		Set_Box_Color(&T->Missile_Area,0,0,0);
		Set_Box_Size(&T->Missile_Area,15,15,15);
		Set_Box_Location(&T->Missile_Area,0,7.5,0);
		Set_Box_Rotation(&T->Missile_Area,0,0,0);

		T->ML.missile.Damage=MISSILE_DAMAGE;
		T->ML.Launch_Location=&T->location;
		Set_MissileLauncher(&T->ML,0,1.5,0,Type-1);
		T->ML.trailer=T;
	}
	if(Type==3)
	{
		Set_Box_Color(&T->B1,0.5,0.5,0.5);
		Set_Box_Size(&T->B1,1.5,0.5,3);
		Set_Box_Location(&T->B1,0,1,0);
		Set_Box_Rotation(&T->B1,0,0,0);

		Set_Box_Color(&T->B2,0.4,0.4,0.4);
		Set_Box_Size(&T->B2,0.8,1,2.5);
		Set_Box_Location(&T->B2,0,1.5,0);
		Set_Box_Rotation(&T->B2,0,0,0);

		Set_Box_Color(&T->B3,0.4,0.4,0.4);
		Set_Box_Size(&T->B3,0.2,0.2,4);
		Set_Box_Location(&T->B3,0,0.5,2);
		Set_Box_Rotation(&T->B3,0,0,0);
	}
}
void Draw_Trailer(Trailer *T)
{
	if(T->Type==0)
	{
		Go_Location(T->location);
		Rotation_Open(T->rotation,1,1,0);
		Draw_Shapped_Box_Up(T->B1,-0.2,0,-0.2);
		Draw_Box_TR(T->B2);
		Draw_Box_TR(T->B3);
		Draw_Wheel(&T->wheel[0]);
		Draw_Wheel(&T->wheel[1]);
		Draw_Wheel(&T->wheel[2]);
		Draw_Wheel(&T->wheel[3]);
		Rotation_Close(T->rotation,1,1,0);
		Back_Location(T->location);
	}
	if(T->Type==1 || T->Type==2)
	{
		Go_Location(T->location);
		Rotation_Open(T->rotation,1,1,0);
		Draw_Shapped_Box_Up(T->B1,-0.2,0,-0.2);
		Draw_Box_TR(T->B2);
		Draw_Wheel(&T->wheel[0]);
		Draw_Wheel(&T->wheel[1]);
		Draw_Wheel(&T->wheel[2]);
		Draw_Wheel(&T->wheel[3]);
		Draw_Missile_Launcher(&T->ML);
		Rotation_Close(T->rotation,1,1,0);
		Back_Location(T->location);

		if(T->ML.missile.status!=NOT_ACTIVE)
			Draw_Missile(&T->ML.missile);
		if(T->ML.missile.Blow.Radius!=0)
			Draw_Blow_Smoke(&T->ML.missile.Blow);
	}
	if(T->Type==3)
	{
		Go_Location(T->location);
		Rotation_Open(T->rotation,1,1,0);
		Draw_Shapped_Box_Up(T->B1,-0.2,0,-0.2);
		Draw_Box_TR(T->B2);
		Draw_Box_TR(T->B3);
		Draw_Wheel(&T->wheel[0]);
		Draw_Wheel(&T->wheel[1]);
		Draw_Wheel(&T->wheel[2]);
		Draw_Wheel(&T->wheel[3]);
		Rotation_Close(T->rotation,1,1,0);
		Back_Location(T->location);
	}
}
void Trailer_Movement(Trailer *T)
{		
	if(T->Type!=1&&T->Type!=2 || T->ML.target==nullptr)return;
	RotateUntil_Y(&T->ML.rotation,T->location,*T->ML.target,-90);
	RotateUntil_X_Half(&T->ML.Hold.rotation,T->location,*T->ML.target,0);
	if(T->ML.missile.status!=NOT_ACTIVE)
		Missile_Movment(&T->ML.missile);
	Trailer_Launch_Missile(T,2);
}
void Set_Train(Train *T,float x,float y,float z,float x1 ,float y1,float z1)
{
	Set_Location(&T->location_1,x,y,z);
	Set_Location(&T->location_2,x1,y1,z1);
	T->speed.x=0.1;
	Set_Trailer(&T->trailer[0],x,y,z,0);
	Set_Trailer(&T->trailer[1],x-4,y,z,3);
	Set_Trailer(&T->trailer[2],x-8,y,z,3);
	Set_Trailer(&T->trailer[3],x-12,y,z,1);
	Set_Trailer(&T->trailer[4],x-16,y,z,1);
	Set_Trailer(&T->trailer[5],x-20,y,z,2);
	Set_Trailer(&T->trailer[6],x-24,y,z,3);
	Set_Trailer(&T->trailer[7],x-28,y,z,2);
	Set_Trailer(&T->trailer[8],x-32,y,z,2);
	Set_Trailer(&T->trailer[9],x-36,y,z,3);

	Set_Box_Color(&T->B1,0,0,0);
	Set_Box_Size(&T->B1,abs(x-x1),0.2,0.1);
	Set_Box_Location(&T->B1,0,0.1,z+0.4);
	Set_Box_Rotation(&T->B1,0,0,0);

	Set_Box_Color(&T->B2,0,0,0);
	Set_Box_Size(&T->B2,abs(x-x1),0.2,0.1);
	Set_Box_Location(&T->B2,0,0.1,z-0.4);
	Set_Box_Rotation(&T->B2,0,0,0);
}
void Draw_Train(Train *T)
{
	for(int i=0;i<10;i++)
		if(T->trailer[i].location.x > T->location_1.x)
			Draw_Trailer(&T->trailer[i]);
	Draw_Box_TR(T->B1);
	Draw_Box_TR(T->B2);
}
void Train_Movement(Train *T)
{
	for(int i=0;i<10;i++){
		Trailer_Movement(&T->trailer[i]);
		T->trailer[i].location.x+=T->speed.x;
		if(T->trailer[i].location.x>T->location_2.x)
			T->trailer[i].location.x=T->location_1.x-5;
	}
}
//XO_Table
int CheckXO(Box *B)
{
	if(B->color.b==1)
		return BLUE_X;
	if(B->color.r==1)
		return RED_O;
	
	return 0;
}
int Check_Winner(XO_Table *table)
{
	for(int i=1;i<=2;i++)
	{
		if(CheckXO(&table->arr[0])==i&&CheckXO(&table->arr[1])==i&&CheckXO(&table->arr[2])==i)
		return i;
		if(CheckXO(&table->arr[3])==i&&CheckXO(&table->arr[4])==i&&CheckXO(&table->arr[5])==i)
		return i;
		if(CheckXO(&table->arr[6])==i&&CheckXO(&table->arr[7])==i&&CheckXO(&table->arr[8])==i)
		return i;
		if(CheckXO(&table->arr[0])==i&&CheckXO(&table->arr[3])==i&&CheckXO(&table->arr[6])==i)
		return i;
		if(CheckXO(&table->arr[1])==i&&CheckXO(&table->arr[4])==i&&CheckXO(&table->arr[7])==i)
		return i;
		if(CheckXO(&table->arr[2])==i&&CheckXO(&table->arr[5])==i&&CheckXO(&table->arr[8])==i)
		return i;
		if(CheckXO(&table->arr[0])==i&&CheckXO(&table->arr[4])==i&&CheckXO(&table->arr[8])==i)
		return i;
		if(CheckXO(&table->arr[2])==i&&CheckXO(&table->arr[4])==i&&CheckXO(&table->arr[6])==i)
		return i;
	}
	for(int i=0;i<9;i++)
		if(CheckXO(&table->arr[i])==0)
					return 0;
	return DRAW;
}
void Set_XO_Table(XO_Table *table,float x,float y,float z)
{
	Set_Location(&table->location,x,y,z);
	Set_Sata(&table->sata,0,10,12);
	for(int i=0;i<9;i++){
		Set_Box_Color(&table->arr[i],0.9,1,0.9);
		Set_Box_Size(&table->arr[i],3.4,1,3.4);
	}
	Set_Box_Location(&table->arr[0],-4,0.5,-4);
	Set_Box_Location(&table->arr[1],0,0.5,-4);
	Set_Box_Location(&table->arr[2],4,0.5,-4);
	Set_Box_Location(&table->arr[3],-4,0.5,0);
	Set_Box_Location(&table->arr[4],0,0.5,0);
	Set_Box_Location(&table->arr[5],4,0.5,0);
	Set_Box_Location(&table->arr[6],-4,0.5,4);
	Set_Box_Location(&table->arr[7],0,0.5,4);
	Set_Box_Location(&table->arr[8],4,0.5,4);

	Set_Box_Color(&table->Body,0.5,0.5,0.5);
	Set_Box_Size(&table->Body,15,1,15);
	Set_Box_Location(&table->Body,0,0,0);
	Set_Box_Rotation(&table->Body,0,0,0);

	Set_Box_Color(&table->Stand[0],0.7,0.7,0.7);
	Set_Box_Size(&table->Stand[0],2,2,40);
	Set_Box_Location(&table->Stand[0],4,-1,15);
	Set_Box_Rotation(&table->Stand[0],0,0,0);

	Set_Box_Color(&table->Stand[1],0.7,0.7,0.7);
	Set_Box_Size(&table->Stand[1],2,2,40);
	Set_Box_Location(&table->Stand[1],-4,-1,15);
	Set_Box_Rotation(&table->Stand[1],0,0,0);

	Set_Box_Color(&table->Stand[2],0.7,0.7,0.7);
	Set_Box_Size(&table->Stand[2],6,6,20);
	Set_Box_Location(&table->Stand[2],0,2,24);
	Set_Box_Rotation(&table->Stand[2],0,0,0);

	Set_Box_Color(&table->Stand[3],0.8,0.8,0.8);
	Set_Box_Size(&table->Stand[3],6,20,4);
	Set_Box_Location(&table->Stand[3],0,0,12);
	Set_Box_Rotation(&table->Stand[3],0,0,0);

	Set_Box_Color(&table->Stand[4],0.8,0.8,0.8);
	Set_Box_Size(&table->Stand[4],20,1,5);
	Set_Box_Location(&table->Stand[4],0,3,14);
	Set_Box_Rotation(&table->Stand[4],0,0,0);

	Set_Box_Color(&table->Stand[5],0,0,1);
	Set_Box_Size(&table->Stand[5],1,8,1);
	Set_Box_Location(&table->Stand[5],0,6,10);
	Set_Box_Rotation(&table->Stand[5],0,0,0);

	Set_Box_Color(&table->Stand[6],0,0,1);
	Set_Box_Size(&table->Stand[6],1,8,1);
	Set_Box_Location(&table->Stand[6],2,5,10);
	Set_Box_Rotation(&table->Stand[6],0,0,0);

	Set_Box_Color(&table->Stand[7],0,0,1);
	Set_Box_Size(&table->Stand[7],1,8,1);
	Set_Box_Location(&table->Stand[7],-2,5,10);
	Set_Box_Rotation(&table->Stand[7],0,0,0);

	Set_Box_Color(&table->Stand[8],1,0,0);
	Set_Box_Size(&table->Stand[8],4,0.5,1);
	Set_Box_Location(&table->Stand[8],0,5,9.5);
	Set_Box_Rotation(&table->Stand[8],0,0,0);

	Set_Box_Color(&table->Stand[9],1,0,0);
	Set_Box_Size(&table->Stand[9],4,0.5,1);
	Set_Box_Location(&table->Stand[9],0,8,9.5);
	Set_Box_Rotation(&table->Stand[9],0,0,0);

}
void Draw_XO_Table(XO_Table *table)
{
	Go_Location(table->location);
	for(int i=0;i<9;i++)
		Draw_Box_T(table->arr[i]);
	for(int i=0;i<10;i++)
		Draw_Box_T(table->Stand[i]);
	Draw_Sata(&table->sata);
	Draw_Shapped_Box_Up(table->Body,-0.5,0,-0.5);
	Back_Location(table->location);

}
//User_Manegment_Functions
int User_Exists(char *Name)
{
	FILE *fp;
	char path[40]="Users/";
	strcat(path,Name);
	strcat(path,".txt");
	fp=fopen(path,"r");
	if(fp!=nullptr)
	{
		fclose(fp);
		return 1;
	}
	return 0;
}
User* Get_User(char *Name)
{
	char path[40]="Users/";
	User *user;
	FILE *fp;
	if(!User_Exists(Name))return nullptr;
	user = (User*)malloc(sizeof(User));
	strcat(path,Name);
	strcat(path,".txt");
	fp=fopen(path,"r");
	if(!fp)return nullptr;
	fseek(fp,7,SEEK_CUR);
	fscanf(fp,"%s",&user->User_Name);
	fseek(fp,12,SEEK_CUR);
	fscanf(fp,"%s",&user->Password);
	fseek(fp,9,SEEK_CUR);
	fscanf(fp,"%d",&user->Coins);
	fseek(fp,8,SEEK_CUR);
	fscanf(fp,"%d",&user->Wins);
	fseek(fp,9,SEEK_CUR);
	fscanf(fp,"%d",&user->Loses);
	fseek(fp,17,SEEK_CUR);
	fscanf(fp,"%f",&user->Bullet_Damage);
	fseek(fp,15,SEEK_CUR);
	fscanf(fp,"%f",&user->Bomb_Damage);
	fseek(fp,18,SEEK_CUR);
	fscanf(fp,"%f",&user->Missile_Damage);
	fseek(fp,8,SEEK_CUR);
	fscanf(fp,"%d",&user->Type);
	fclose(fp);
	return user;
}
void In_User(User *user)
{
	FILE *fp;
	char path[40]="Users/";
	strcat(path,user->User_Name);
	strcat(path,".txt");
	fp=fopen(path,"w");
	fprintf(fp,"User : %s\n",user->User_Name);
	fprintf(fp,"Password : %s\n",user->Password);
	fprintf(fp,"Coins : %d\n",user->Coins);
	fprintf(fp,"Wins : %d\n",user->Wins);
	fprintf(fp,"Loses : %d\n",user->Loses);
	fprintf(fp,"Bullet_Damage : %.1f\n",user->Bullet_Damage);
	fprintf(fp,"Bomb_Damage : %.1f\n",user->Bomb_Damage);
	fprintf(fp,"Missile_Damage : %.1f\n",user->Missile_Damage);
	fprintf(fp,"Type : %d\n",user->Type);
	fclose(fp);
}
void Print_User(char *Name)
{
	User *user;
	user = Get_User(Name);
	Draw_String(1,1,0,2+StoreX,1.3,-2.9,user->User_Name);
	Draw_String_int(1,1,1,2+StoreX,1.1,-2.9,"Coins: %d",user->Coins);
	Draw_String_float(1,1,1,2+StoreX,0.9,-2.9,"Bullet Damage: %.2f",user->Bullet_Damage);
	Draw_String_float(1,1,1,2+StoreX,0.7,-2.9,"Bomb Damage: %.2f",user->Bomb_Damage);
	Draw_String_float(1,1,1,2+StoreX,0.5,-2.9,"Missile Damage: %.2f",user->Missile_Damage);
	Draw_String_int(1,1,1,2+StoreX,0.3,-2.9,"Level : %d",(user->Type+1));

}
int New_User(char *User_Name,char *Password)
{
	if(User_Exists(User_Name))return 0;
	User user;
	user.Bomb_Damage = user.Bullet_Damage = user.Missile_Damage =1.0;
	user.Coins = user.Wins = user.Loses =user.Type=0;
	strcpy(user.User_Name,User_Name);
	strcpy(user.Password,Password);
	In_User(&user);
	return 1;
}
int Login(char *User_Name,char *Password)
{
	User *user;
	if(!User_Exists(User_Name)) return -1;
	user=Get_User(User_Name);
	if(strcmp(user->Password,Password)==0){
		free(user);
		return 1;
	}
	free(user);
	return 0;
}
//Stars
void Set_Stars(Star *s,float x,float y,float z)
{
	Set_Location(&s->location,x,y,z);
}
void Draw_Star(Star *s)
{
	s->location.x-=2;
	if(s->location.x<-210)s->location.x=210;
	Go_Location(s->location);
	glColor3f(10,10,10);
	glScalef(10,1,1);
	glutSolidSphere(0.5,5,5);
	glScalef(0.1,1,1);
	Back_Location(s->location);
}
//Bot
Box *Check_Row(Box *B1,Box *B2,Box *B3)
{
	if(CheckXO(B1)==RED_O && CheckXO(B2)==RED_O&& CheckXO(B3)==0)return B3;
	if(CheckXO(B1)==RED_O && CheckXO(B3)==RED_O&& CheckXO(B2)==0)return B2;
	if(CheckXO(B2)==RED_O && CheckXO(B3)==RED_O&& CheckXO(B1)==0)return B1;

	if(CheckXO(B1)==BLUE_X && CheckXO(B2)==BLUE_X&& CheckXO(B3)==0)return B3;
	if(CheckXO(B1)==BLUE_X && CheckXO(B3)==BLUE_X&& CheckXO(B2)==0)return B2;
	if(CheckXO(B2)==BLUE_X && CheckXO(B3)==BLUE_X&& CheckXO(B1)==0)return B1;

	return nullptr;
}
int Get_Move(Box *B1,Box *B2,Box *B3)
{
	Box *B;
	B=Check_Row(B1,B2,B3);
	if(B)
	{
		Set_Color(&B->color,1,0,0);
		B->location.y-=0.4;
		return 1;
	}
	return 0;
}
//Gun
void Blow_Gun(Gun *G)
{
	Copy_Location(&G->Blow.location,G->location);
	G->Blow.Radius=0.01;
}
void Set_Gun(Gun *G,int x,float y,float z,float Size)
{
	Set_Location(&G->location,x,y,z);
	Set_Rotation(&G->rotation,0,0,0);
	G->Health=150;
	G->Status=0;
	G->target=nullptr;
	
	Set_Smoke(&G->Shoot,0.2,0.05,0,0,0);
	Set_Smoke(&G->Blow,3,0.05,0,0,0);
	Set_Location(&G->Shoot.location,0,0,3);

	Set_Box_Color(&G->Bound_Area,0.2,0.4,0.1);
	Set_Box_Size(&G->Bound_Area,3,4,3);
	Set_Box_Location(&G->Bound_Area,0,2,0);
	Set_Box_Rotation(&G->Bound_Area,0,0,0);

	Set_Box_Color(&G->Gun_Area,0.2,0.4,0.1);
	Set_Box_Size(&G->Gun_Area,Size,20,Size);
	Set_Box_Location(&G->Gun_Area,0,10,0);
	Set_Box_Rotation(&G->Gun_Area,0,0,0);

	Set_Box_Color(&G->box[0],0.2,0.4,0.1);
	Set_Box_Size(&G->box[0],3,0.5,3);
	Set_Box_Location(&G->box[0],0,0.25,0);
	Set_Box_Rotation(&G->box[0],0,0,0);

	Set_Box_Color(&G->box[1],0.6,0.6,0.6);
	Set_Box_Size(&G->box[1],1,1,1);
	Set_Box_Location(&G->box[1],0,0.5,0);
	Set_Box_Rotation(&G->box[1],0,0,0);

	Set_Box_Color(&G->box[2],0.2,0.5,0.1);
	Set_Box_Size(&G->box[2],1.5,1,2);
	Set_Box_Location(&G->box[2],0,1,0);
	Set_Box_Rotation(&G->box[2],0,0,0);

	Set_Box_Color(&G->box[3],0.2,0.5,0.1);
	Set_Box_Size(&G->box[3],1,1,1);
	Set_Box_Location(&G->box[3],0,1.5,-1);
	Set_Box_Rotation(&G->box[3],0,0,0);

	Set_Box_Color(&G->box[4],0.3,0.5,0.2);
	Set_Box_Size(&G->box[4],3,0.5,0.5);
	Set_Box_Location(&G->box[4],0,1,0);
	Set_Box_Rotation(&G->box[4],0,0,0);

	Set_Box_Color(&G->box[5],0.2,0.2,0.2);
	Set_Box_Size(&G->box[5],0.6,0.6,1);
	Set_Box_Location(&G->box[5],1.21,1,0);
	Set_Box_Rotation(&G->box[5],-50,0,0);

	Set_Box_Color(&G->box[6],0.8,0.8,0.8);
	Set_Box_Size(&G->box[6],0.08,0.08,3);
	Set_Box_Location(&G->box[6],0,0.1,1.1);
	Set_Box_Rotation(&G->box[6],0,0,0);

	Set_Box_Color(&G->box[7],0.8,0.8,0.8);
	Set_Box_Size(&G->box[7],0.08,0.08,3);
	Set_Box_Location(&G->box[7],-0.1,-0.05,1.1);
	Set_Box_Rotation(&G->box[7],0,0,0);

	Set_Box_Color(&G->box[8],0.8,0.8,0.8);
	Set_Box_Size(&G->box[8],0.08,0.08,3);
	Set_Box_Location(&G->box[8],0.1,-0.05,1.1);
	Set_Box_Rotation(&G->box[8],0,0,0);

	Set_Box_Color(&G->box[9],0,0,0.8);
	Set_Box_Size(&G->box[9],0.3,0.3,0.1);
	Set_Box_Location(&G->box[9],0,0,1.2);
	Set_Box_Rotation(&G->box[9],0,0,0);

	Set_Box_Color(&G->box[10],0,0,0.8);
	Set_Box_Size(&G->box[10],0.3,0.3,0.1);
	Set_Box_Location(&G->box[10],0,0,2);
	Set_Box_Rotation(&G->box[10],0,0,0);

	Set_Box_Color(&G->box[11],0.2,0.2,0.2);
	Set_Box_Size(&G->box[11],0.6,0.6,1);
	Set_Box_Location(&G->box[11],-1.21,1,0);
	Set_Box_Rotation(&G->box[11],-50,0,0);

	Set_Box_Color(&G->box[12],0.8,0.8,0.8);
	Set_Box_Size(&G->box[12],0.08,0.08,3);
	Set_Box_Location(&G->box[12],0,0.1,1.1);
	Set_Box_Rotation(&G->box[12],0,0,0);

	Set_Box_Color(&G->box[13],0.8,0.8,0.8);
	Set_Box_Size(&G->box[13],0.08,0.08,3);
	Set_Box_Location(&G->box[13],0.1,-0.05,1.1);
	Set_Box_Rotation(&G->box[13],0,0,0);

	Set_Box_Color(&G->box[14],0.8,0.8,0.8);
	Set_Box_Size(&G->box[14],0.08,0.08,3);
	Set_Box_Location(&G->box[14],-0.1,-0.05,1.1);
	Set_Box_Rotation(&G->box[14],0,0,0);

	Set_Box_Color(&G->box[15],0,0,0.8);
	Set_Box_Size(&G->box[15],0.3,0.3,0.1);
	Set_Box_Location(&G->box[15],0,0,1.2);
	Set_Box_Rotation(&G->box[15],0,0,0);

	Set_Box_Color(&G->box[16],0,0,0.8);
	Set_Box_Size(&G->box[16],0.3,0.3,0.1);
	Set_Box_Location(&G->box[16],0,0,2);
	Set_Box_Rotation(&G->box[16],0,0,0);

}
void Draw_Gun(Gun *G)
{
	if(G->Blow.Radius!=0)
		Draw_Blow_Smoke(&G->Blow);

	if(G->Health<=0)
		return;
	Go_Location(G->location);
	Draw_Box_T(G->box[0]);

		Go_Location(G->box[1].location);
		Rotation_Open(G->box[1].rotation,0,1,0);
			Draw_Box(G->box[1]);
			Draw_Box_T(G->box[2]);
			Draw_Box_T(G->box[3]);
			Draw_Box_T(G->box[4]);

			Go_Location(G->box[5].location);
			Rotation_Open(G->box[5].rotation,1,0,0);
			Draw_Box(G->box[5]);
				Rotation_Open(G->box[10].rotation,0,0,1);
				if(G->Status!=0)
					Draw_Blow_Smoke(&G->Shoot);
					Draw_Box_T(G->box[6]);
					Draw_Box_T(G->box[7]);
					Draw_Box_T(G->box[8]);
					Draw_Box_T(G->box[9]);
					Draw_Box_T(G->box[10]);
				Rotation_Close(G->box[10].rotation,0,0,1);
			Rotation_Close(G->box[5].rotation,1,0,0);
			Back_Location(G->box[5].location);

		Go_Location(G->box[11].location);
		Rotation_Open(G->box[11].rotation,1,0,0);
		Draw_Box(G->box[11]);
			Rotation_Open(G->box[16].rotation,0,0,1);
			if(G->Status!=0)
			Draw_Blow_Smoke(&G->Shoot);
			Draw_Box_T(G->box[12]);
			Draw_Box_T(G->box[13]);
			Draw_Box_T(G->box[14]);
			Draw_Box_T(G->box[15]);
			Draw_Box_T(G->box[16]);
			Rotation_Close(G->box[16].rotation,0,0,1);
		Rotation_Close(G->box[11].rotation,1,0,0);
		Back_Location(G->box[11].location);

		Rotation_Close(G->box[1].rotation,0,1,0);
		Back_Location(G->box[1].location);
	Back_Location(G->location);
	
}
void Gun_Movement(Gun *G)
{
	if(G->Status==0 || G->Health<=0|| G->target==nullptr|| G->Heli==nullptr)
		return;

	RotateUntil_Y(&G->box[1].rotation,G->location,*G->target,0);
	RotateUntil_X_Half(&G->box[5].rotation,G->location,*G->target,0);
	RotateUntil_X_Half(&G->box[11].rotation,G->location,*G->target,0);

	G->box[16].rotation.z+=40;
	G->box[16].rotation.z%=360;
	G->box[10].rotation.z+=40;
	G->box[10].rotation.z%=360;

	if(G->Shoot.Radius==0)
		G->Shoot.Radius=0.01;
	if(G->box[16].rotation.z==0)
		G->Heli->Health--;
}