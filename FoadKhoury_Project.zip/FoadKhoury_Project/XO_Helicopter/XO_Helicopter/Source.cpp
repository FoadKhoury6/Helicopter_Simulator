#include "Functions.h"
#include <time.h>


int GameStatus=SCREEN_CHOOSE_PLAYERS; // Describes 
int MainPage=0; // Describes Witch Page To Show
int Typeing;    // Describes Typeing Into Somthing Or Not
int Roller=0;   // Describes Moveing From Page To Page

//Register Page
Button New_User_Name;        // Describes Button To Type New Name To Register
Button New_User_Password;    // Describes Button To Type New Password To Register
Button Register_Button;      // Describes Button To Register
char Register_Status[40]=""; // Describes Register Result Message 
Button BackMain2;			 // Describes Change Page Button
//
//Details Page
Bonus Shown_Bonus[5];	     // Describes Object Just For Show
float InfoX,InfoY;			 // Describes Location To Type On Screen
Button DrawBullet;			 // Describes Object Just For Show
Button DrawBomb;			 // Describes Object Just For Show
Button DrawMissile;			 // Describes Object Just For Show
Button DrawCoins;			 // Describes Object Just For Show
Button DrawFuel;			 // Describes Object Just For Show
Button BackMain1;	// Describes Change Page Button
//
//ChooseMap Page
Button Map1; 				 // Describes Choosen Map 1
Button Map2;  				 // Describes Choosen Map 2
Button Map3;  				 // Describes Choosen Map 3
Button Map4;  				 // Describes Choosen Map 4
Button Night_Day; 			 // Describes Choose Night Or Day
Button Store; 				 // Describes Change Page Button
Building Shown_Bulding[5];	 // Describes Object Just For Show
int Night_Day_Flag=0;		 // Describes Choose Night Or Day
Button Back;				 // Describes Change Page Button
//
//Store Page
Button Name1;				 // Describes Player 1 Is Upgrading
Button Name2;				 // Describes Player 2 Is Upgrading
Button Buy[4];				 // Describes Button To Upgrade Bullets,Bombs,Missiles And Level
Bonus Damage_Bonus[3];		 // Describes Object Just For Show
Button BackFromStore;		 // Describes Change Page Button
int clickName,money,MaxLevel;// Describes Status If Got Problem While Upgrading
//
//Manu Page
Button User_Name_1;			// Describes Button To Type Player 1 Name To Log In
Button User_Name_2;			// Describes Button To Type Player 2 Name To Log In	
Button User_Password_1;		// Describes Button To Type Player 1 Password To Log In
Button User_Password_2;		// Describes Button To Type Player 2 Password To Log In
Button ChooseMap;			// Describes Change Page Button
Button Details;				// Describes Change Page Button
Button Exit;				// Describes Button To Exit
Button ShowGames;			// Describes Change Page Button
char Login_Status[40]="";	// Describes Log In Result Message If Got A Problem
char *Hidden_Password;			// Describes Pointer The Points At String That We Are Typeing In
char Hidden_Password1[20]="";	// Describes The Password That Player 1 Entered
char Hidden_Password2[20]="";	// Describes The Password That Player 2 Entered
float MainX,MainY;			// Describes Location To Type On Screen
//
//Start Page
Button Register;			// Describes Change Page Button
Button Player1;				// Describes Change Page Button
Button Players2;			// Describes Change Page Button
int Players_flag;			// Describes How Many Player Are Playing 1 Or 2
//
//Show Games
Button Up;					// Describes Button To Scroll Up The Game List 
Button Down;				// Describes Button To Scroll Down The Game List 
Button Border;				// Describes Border Around GameList
FILE *fptr;					// Describes Pointer To Get Data From File's
GameList *Game_List=nullptr;// Describes A List Holds The Games Results
GameList *tmp;				// Describes Helpout Pointer To Move On The List
float List_y=2;				// Describes Position To Print List On The Screen
char str1[20]="",str2[20]="",str3[20]="",Winner_str[20]="";// Describes Helpout String To Get Data From File's
Button *Type_Into;			// Describes Pointer The Points At Button That We Are Typeing In
Button BackMain;	// Describes Change Page Button
//
//Objects 
Button Show_Opjects;		// Describes Change Page Button
Button Right_Opject;		// Describes Change Build Type To Show
Button Left_Opject;			// Describes Change Build Type To Show
Button Opject_Back;			// Describes Change Page Button
Building *Object_Build;		// Describes Object Just For Show
Tank Object_Tanks[4];		// Describes Object Just For Show
Trailer Object_Trailers[4];	// Describes Object Just For Show
Bullding_With_Tank Object_Building_With_Tank;// Describes Object Just For Show
int OBJECT_TANKS_TRAILER_SIZE=4;	// Describes Object Array Size
int Object_Build_Turn;		// Describes Which Type Of Build To Show
//
//Array Size's
int BUILDING_WITH_TANK_SIZE;
int GUN_SIZE;
int BUILDING_SIZE;
int BRIDGE_SIZE;
int CLOUD_SIZE;
int TREE_SIZE;
int STREET_SIZE;
int HELICOPTER_SIZE=2;
int XO_SIZE;
int TANKS_SIZE;
int BONUS_SIZE;
int TRAIN_SIZE;
int MOUNTEN_SIZE;
/////////////////////////////////
GLsizei WIDTH = 1300, HEIGHT = 1000; // Describes Screen Size
char Winner_Name[20];				 // Describes Winner Name
char Loser_Name[20];				 // Describes Loser Name

//GamePlay Objects
Helicopter Heli[2];
int INDEX=0; // Describes Which Player Is Playing
User *user;
XO *xo_x;
XO *xo_o;
Bullding_With_Tank building_Tank[7];
Building *building;
Bridge *bridge;
Cloud *cloud;
Tree *tree;
Street *street;
Box Land;
Tank tanks[15];
Bonus *bonus;
Gun gun[5];
Building Mounten[140];
Train train[5];
XO_Table table;
Star stars[50];
int MaxHigh;
int WinnerIs;
int Map;
int Price_Bomb,Price_Bullet,Price_Missile,Price_Upgrade;
//

int MouseX;
int MouseY;
float x,y,z,a,i;


GLfloat density = 0.00; //set the density to 0.3 which is
GLfloat fogColor[4] = {0, 0, 0, 1.0}; //set the for
void reshape (int w, int h);
void Set_Manu();
void Set_Buttons();
int Two_Players()
{
	if(Players_flag==TWO_PLAYERS)
		return 1;
	return 0;
}
void EndGame()
{
	if(Map!=MAP_4&&Map!=MAP_3)
		free(street);
	if(Map!=MAP_3)
		free(bridge);

	free(xo_x);
	free(xo_o);
	free(building);
	free(tree);
	free(bonus);
	free(cloud);

	Roller=0;
	MainPage=0;
	Map=0;
	TANKS_SIZE=0;
	BUILDING_WITH_TANK_SIZE=0;
	BUILDING_SIZE=0;
	BRIDGE_SIZE=0;
	XO_SIZE=0;
	CLOUD_SIZE=0;
	TREE_SIZE=0;
	STREET_SIZE=0;
	BONUS_SIZE=0;
	TRAIN_SIZE=0;
	MOUNTEN_SIZE=0;
	strcpy(Night_Day.str,"Day");
	Set_Color(&Night_Day.color,1,1,1);
	Night_Day_Flag=0;
	glutSetCursor( GLUT_CURSOR_RIGHT_ARROW );
	free(Heli[0].user);
	if(Two_Players())free(Heli[1].user);
	Set_Manu();
}
void Game_Draw()
{
	FILE *fp;
	fp=fopen("Score.txt","a");
	if(Two_Players())
	{
		fprintf(fp,"\n%s %s Draw",Heli[0].user->User_Name,Heli[1].user->User_Name);
		Game_List=Create_Game(0.5,-(8+List_y),Heli[0].user->User_Name,Heli[1].user->User_Name,"Draw");
		strcpy(Loser_Name,Heli[1].user->User_Name);
	}
	else
	{
		fprintf(fp,"\n%s BOT Draw",Heli[0].user->User_Name);
		Game_List=Create_Game(0.5,-(8+List_y),Heli[0].user->User_Name,"BOT","Draw");
	}
	strcpy(Winner_Name,Heli[0].user->User_Name);
	List_y+=3;
	fclose(fp);
	Heli[0].user->Coins+=Heli[0].Coins/2;
	if(Two_Players())
	{
		Heli[1].user->Coins+=Heli[1].Coins/2;
		In_User(Heli[1].user);
	}
	In_User(Heli[0].user);
	GameStatus=SCREEN_WINNER;
	EndGame();
	WinnerIs=DRAW;
}
void Game_Winner(int Winner,int Loser)
{
	FILE *fp;
	fp=fopen("Score.txt","a");
	fprintf(fp,"\n%s %s %s",Heli[Winner].user->User_Name,Heli[Loser].user->User_Name,Heli[Winner].user->User_Name);
	Game_List=Create_Game(0.5,-(8+List_y),Heli[Winner].user->User_Name,Heli[Loser].user->User_Name,Heli[Winner].user->User_Name);
	List_y+=3;
	fclose(fp);
	strcpy(Winner_Name,Heli[Winner].user->User_Name);
	strcpy(Loser_Name,Heli[Loser].user->User_Name);
	Heli[Winner].user->Wins++;
	Heli[Loser].user->Loses++;
	Heli[Winner].user->Coins+=Heli[Winner].Coins;
	Heli[Loser].user->Coins+=Heli[Loser].Coins/2;
	In_User(Heli[Winner].user);
	In_User(Heli[Loser].user);
	GameStatus=SCREEN_WINNER;
	EndGame();
	WinnerIs=Winner+1;
	return;
}
void Game_Winner_Bot(int Winner)
{
	FILE *fp;
	fp=fopen("Score.txt","a");
	if(Winner==0){
		fprintf(fp,"\n%s BOT %s",Heli[0].user->User_Name,Heli[0].user->User_Name);
		strcpy(Winner_Name,Heli[0].user->User_Name);
		Game_List=Create_Game(0.5,-(8+List_y),Heli[0].user->User_Name,"BOT",Heli[0].user->User_Name);
		Heli[0].user->Wins++;
		Heli[0].user->Coins+=Heli[0].Coins;
	}
	if(Winner==1){
		fprintf(fp,"\n%s BOT BOT",Heli[0].user->User_Name);
		strcpy(Winner_Name,"BOT");
		Game_List=Create_Game(0.5,-(8+List_y),Heli[0].user->User_Name,"BOT","BOT");
		Heli[0].user->Loses++;
		Heli[0].user->Coins+=Heli[0].Coins/2;
	}
	List_y+=3;
	fclose(fp);
	In_User(Heli[0].user);
	GameStatus=SCREEN_WINNER;
	EndGame();
	WinnerIs=Winner+1;
	return;
}
int Bot_Force_Turn()
{
	if(Get_Move(&table.arr[0],&table.arr[1],&table.arr[2]))return 1;
	if(Get_Move(&table.arr[3],&table.arr[4],&table.arr[5]))return 1;
	if(Get_Move(&table.arr[6],&table.arr[7],&table.arr[8]))return 1;
	if(Get_Move(&table.arr[0],&table.arr[3],&table.arr[6]))return 1;
	if(Get_Move(&table.arr[1],&table.arr[4],&table.arr[7]))return 1;
	if(Get_Move(&table.arr[2],&table.arr[5],&table.arr[8]))return 1;
	if(Get_Move(&table.arr[0],&table.arr[4],&table.arr[8]))return 1;
	if(Get_Move(&table.arr[2],&table.arr[4],&table.arr[6]))return 1;
	return 0;
}
void Bot_Turn()
{
	if(Bot_Force_Turn());
	else
	{
		if(CheckXO(&table.arr[4])!=0)
		{
			int In;
			In=rand()%9;
			while(CheckXO(&table.arr[In])!=0)In=rand()%9;
			Set_Color(&table.arr[In].color,1,0,0);
			table.arr[In].location.y-=0.4;
		}
		else
		{
			Set_Color(&table.arr[4].color,1,0,0);
			table.arr[4].location.y-=0.4;
		}
	}
	if(Check_Winner(&table)==DRAW)
		Game_Draw();
	if(Check_Winner(&table)==PLAYER_2_WINS)	
		Game_Winner_Bot(1);
}
void SwitchPlayer() 
{
	for(int i=0;i<BUILDING_WITH_TANK_SIZE;i++)
	{
		if(building_Tank[i].ML.missile.status!=NOT_ACTIVE)
			Reset_Missile(&building_Tank[i].ML.missile);
		if(building_Tank[i].tank.ML.missile.status!=NOT_ACTIVE)
			Reset_Missile(&building_Tank[i].tank.ML.missile);
		building_Tank[i].tank.target=nullptr;
	}
	for(int i=0;i<TANKS_SIZE;i++)
	{
		if(tanks[i].ML.missile.status!=NOT_ACTIVE)
			Reset_Missile(&tanks[i].ML.missile);
		if(tanks[i].Type!=2&&tanks[i].Type!=3)
		tanks[i].target=nullptr;
		tanks[i].ML.target=nullptr;
	}
	for(int i=0;i<TRAIN_SIZE;i++)
	{
		for(int j=0;j<10;j++)
			if(train[i].trailer[j].ML.missile.status!=NOT_ACTIVE)
				Reset_Missile(&train[i].trailer[j].ML.missile);
	}
	Throw_Xo(&Heli[INDEX]);
	Set_Helicopter(&Heli[0],table.location.x+5,table.location.y+5,table.location.z+13,0,Heli[0].user->User_Name);
	if(Two_Players())
		Set_Helicopter(&Heli[1],table.location.x-5,table.location.y+5,table.location.z+13,1,Heli[1].user->User_Name);
	else
	{
		Bot_Turn();
		INDEX=1;
	}
	
	INDEX=(!INDEX);
}

void reshape (int w, int h) {
    glViewport (0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode (GL_PROJECTION);
    glLoadIdentity ();
    gluPerspective (60, (GLfloat)w / (GLfloat)h, 1.0, 300);
    glMatrixMode (GL_MODELVIEW);
    WIDTH=w;
    HEIGHT=h;
}
void Set_Map_Objects(char *path) // Import Data From Files
{
	
	FILE *file_pointer;
	char Struct_Path[40];
	Set_Helicopter(&Heli[0],table.location.x+5,table.location.y+5,table.location.z+13,0,User_Name_1.str);
	if(Two_Players())
		Set_Helicopter(&Heli[1],table.location.x-5,table.location.y+5,table.location.z+13,1,User_Name_2.str);
	strcpy(Struct_Path,path);
	strcat(Struct_Path,"bridge.txt");
	file_pointer=fopen(Struct_Path,"r");
	for(int i=0;i<BRIDGE_SIZE;i++)
	{
			float x,y,z,height,each_Weigth;
			int horizon,count;
			fscanf(fptr,"%f %f %f %d %f %f %d",&x,&y,&z,&count,&each_Weigth,&height,&horizon);
			Set_Bridge(&bridge[i],x,y,z,count,each_Weigth,height,horizon);
	}
	fclose(file_pointer);
	strcpy(Struct_Path,path);
	strcat(Struct_Path,"building_with_tank.txt");
	file_pointer=fopen(Struct_Path,"r");
	for(int i=0;i<BUILDING_WITH_TANK_SIZE;i++)
	{
			float x,y,z;
			int Type;
			fscanf(fptr,"%f %f %f %d ",&x,&y,&z,&Type);
			Set_Bullding_With_Tank(&building_Tank[i],x,y,z,Type);
	}
	fclose(file_pointer);
	strcpy(Struct_Path,path);
	strcat(Struct_Path,"street.txt");
	file_pointer=fopen(Struct_Path,"r");
	for(int i=0;i<STREET_SIZE;i++)
	{
			float x,y,z,sx,sy;
			int horizon;
			fscanf(fptr,"%f %f %f %f %f %d ",&x,&y,&z,&sx,&sy,&horizon);
			Set_Street(&street[i],x,y,z,sx,sy,horizon);
	}
	fclose(file_pointer);
	strcpy(Struct_Path,path);
	strcat(Struct_Path,"tree.txt");
	file_pointer=fopen(Struct_Path,"r");
	for(int i=0;i<TREE_SIZE;i++)
	{
			float x,y,z;
			fscanf(fptr,"%f %f %f",&x,&y,&z);
			Set_Tree(&tree[i],x,y,z);
	}
	fclose(file_pointer);
	strcpy(Struct_Path,path);
	strcat(Struct_Path,"cloud.txt");
	file_pointer=fopen(Struct_Path,"r");
	for(int i=0;i<CLOUD_SIZE;i++)
	{
			float x,y,z;
			fscanf(fptr,"%f %f %f",&x,&y,&z);
			Set_Cloud(&cloud[i],x,y,z);
	}
	fclose(file_pointer);
	strcpy(Struct_Path,path);
	strcat(Struct_Path,"xo_x.txt");
	file_pointer=fopen(Struct_Path,"r");
	for(int i=0;i<XO_SIZE;i++)
	{
			float x,y,z;
			int Type;
			fscanf(fptr,"%f %f %f %d",&x,&y,&z,&Type);
			Set_XO_Box(&xo_x[i],x,y,z,Type);
	}
	fclose(file_pointer);
	strcpy(Struct_Path,path);
	strcat(Struct_Path,"xo_o.txt");
	file_pointer=fopen(Struct_Path,"r");
	for(int i=0;i<XO_SIZE;i++)
	{
			float x,y,z;
			int Type;
			fscanf(fptr,"%f %f %f %d",&x,&y,&z,&Type);
			Set_XO_Box(&xo_o[i],x,y,z,Type);
	}
	fclose(file_pointer);
	strcpy(Struct_Path,path);
	strcat(Struct_Path,"bonus.txt");
	file_pointer=fopen(Struct_Path,"r");
	for(int i=0;i<BONUS_SIZE;i++)
	{
			float x,y,z;
			int Type;
			fscanf(fptr,"%f %f %f %d",&x,&y,&z,&Type);
			Set_Bouns(&bonus[i],x,y,z,Type);
	}
	fclose(file_pointer);
	strcpy(Struct_Path,path);
	strcat(Struct_Path,"tank.txt");
	file_pointer=fopen(Struct_Path,"r");
	for(int i=0;i<TANKS_SIZE;i++)
	{
			float x,y,z;
			int Type;
			float x1,y1,z1;
			fscanf(fptr,"%f %f %f %f %f %f %d",&x,&y,&z,&x1,&y1,&z1,&Type);
			Set_Tank_1(&tanks[i],x,y,z,x1,y1,z1,Type);
	}
	fclose(file_pointer);
	for(int i=0;i<50;i++)
		Set_Stars(&stars[i],(rand()%400)-200,70+(rand()%20),(rand()%400)-200);
		glutSetCursor(GLUT_CURSOR_NONE);

}
void Set_Map1()	//Map 1 Initialization
{
	
	MaxHigh=25;
	Map=MAP_1;
	FILE *file_pointer;
	TANKS_SIZE=14;
	BUILDING_WITH_TANK_SIZE=7;
	BUILDING_SIZE=54;
	BRIDGE_SIZE=9;
	XO_SIZE=5;
	CLOUD_SIZE=20;
	TREE_SIZE=55;
	STREET_SIZE=17;	
	BONUS_SIZE=55;
	MOUNTEN_SIZE=140;
	GUN_SIZE=4;
	bonus=(Bonus*)malloc(sizeof(Bonus)*BONUS_SIZE);
	building=(Building*)malloc(sizeof(Building)*BUILDING_SIZE);
	xo_o=(XO*)malloc(sizeof(XO)*XO_SIZE);
	xo_x=(XO*)malloc(sizeof(XO)*XO_SIZE);
	bridge=(Bridge*)malloc(sizeof(Bridge)*BRIDGE_SIZE);
	street=(Street*)malloc(sizeof(Street)*STREET_SIZE);
	cloud=(Cloud*)malloc(sizeof(Cloud)*CLOUD_SIZE);
	tree=(Tree*)malloc(sizeof(Tree)*TREE_SIZE);
	if(!street||!tree||!cloud||!bridge||!building||!xo_o||!xo_x||!bonus)
	{
		GameStatus=0;
		return;
	}
	
	Set_Box(&Land,0,0,20,150,0.1,200,0,0,0,0.7,1,0.7);

	Set_XO_Table(&table,0,5,75);
	
	int Mounten_Cnt=0;
	for(int i=0;i<40;i++)
	{
		for(int j=0;j<30;j++)
		{
			if(i==0 || i== 39 || j==2 || j==28)
			{
				float sy;
				sy=25+(((float)rand()/(float)(RAND_MAX))*15);
				Set_Wall(&Mounten[Mounten_Cnt],(j-10)*5-25,0,(i-15)*5-5,5,sy,5);
				Set_Color(&Mounten[Mounten_Cnt++].arr[0].color,0.8,0.8+(((float)rand()/(float)(RAND_MAX))/3),0.8 );
			}
		}
	}
		
	file_pointer=fopen("Maps/Map_1/building.txt","r");
	for(int i=0;i<BUILDING_SIZE;i++)
	{
		if(i>=27 && i<=35)
		{
			float x,y,z,sx,sy,sz;
			fscanf(fptr,"%f %f %f %f %f %f",&x,&y,&z,&sx,&sy,&sz);
			Set_Wall(&building[i],x,y,z,sx,sy,sz);
		}
		else
		{
			float x,y,z;
			int Type;
			fscanf(fptr,"%f %f %f %d",&x,&y,&z,&Type);
			Set_Building(&building[i],x,y,z,Type);
		}
	}
	fclose(file_pointer);
	Set_Map_Objects("Maps/Map_1/");
	Set_Gun(&gun[0],30,0,50,6);
	Set_Gun(&gun[1],-30,0,50,6);
	Set_Gun(&gun[2],-20,0,50,6);
	Set_Gun(&gun[3],20,0,50,6);

}
void Set_Map2() //Map 2 Initialization
{	
	MaxHigh=25;
	Map=MAP_2;
	FILE *file_pointer;
	BUILDING_WITH_TANK_SIZE=5;
	BUILDING_SIZE=26;
	BRIDGE_SIZE=12;
	XO_SIZE=5;
	CLOUD_SIZE=16;
	TREE_SIZE=62;
	STREET_SIZE=18;	
	TANKS_SIZE=15;
	BONUS_SIZE=50;
	MOUNTEN_SIZE=140;
	GUN_SIZE=5;
	bonus=(Bonus*)malloc(sizeof(Bonus)*BONUS_SIZE);
	building=(Building*)malloc(sizeof(Building)*BUILDING_SIZE);
	xo_o=(XO*)malloc(sizeof(XO)*XO_SIZE);
	xo_x=(XO*)malloc(sizeof(XO)*XO_SIZE);
	bridge=(Bridge*)malloc(sizeof(Bridge)*BRIDGE_SIZE);
	street=(Street*)malloc(sizeof(Street)*STREET_SIZE);
	cloud=(Cloud*)malloc(sizeof(Cloud)*CLOUD_SIZE);
	tree=(Tree*)malloc(sizeof(Tree)*TREE_SIZE);
	if(!street||!tree||!cloud||!bridge||!building||!xo_o||!xo_x||!bonus)
	{
		GameStatus=0;
		return;
	}
	
	Set_Box(&Land,0,0,-30,150,0.1,200,0,0,0,0.3,1,0.4);
	Set_XO_Table(&table,0,10,25);
	int Mounten_Cnt=0;
	for(int i=0;i<40;i++)
	{
		for(int j=0;j<30;j++)
		{
			if(i==2 || i== 39 || j==4 || j==27)
			{
				float sy;
				sy=25+(((float)rand()/(float)(RAND_MAX))*15);
				Set_Wall(&Mounten[Mounten_Cnt],(j-10)*5-27,0,(i-15)*5-52,5,sy,5);
				Set_Color(&Mounten[Mounten_Cnt++].arr[0].color,0.3,0.8+(((float)rand()/(float)(RAND_MAX))/3),0.5 );
			}
		}
	}

	file_pointer=fopen("Maps/Map_2/building.txt","r");
	for(int i=0;i<BUILDING_SIZE;i++)
	{
		if(i>=0 && i<=3)
		{
			float x,y,z,sx,sy,sz;
			fscanf(fptr,"%f %f %f %f %f %f",&x,&y,&z,&sx,&sy,&sz);
			Set_Wall(&building[i],x,y,z,sx,sy,sz);
		}
		else
		{
			float x,y,z;
			int Type;
			fscanf(fptr,"%f %f %f %d",&x,&y,&z,&Type);
			Set_Building(&building[i],x,y,z,Type);
		}
	}
	fclose(file_pointer);
	Set_Map_Objects("Maps/Map_2/");
	Set_Gun(&gun[0],30,0,-45,6);
	Set_Gun(&gun[1],-30,0,-45,6);
	Set_Gun(&gun[2],30,0,-75,6);
	Set_Gun(&gun[3],-30,0,-75,6);
	Set_Gun(&gun[4],0,0,-80,6);

}
void Set_Map3() //Map 3 Initialization
{
	MaxHigh=25;
	Map=MAP_3;
	FILE *file_pointer;
	TANKS_SIZE=6;
	BUILDING_WITH_TANK_SIZE=5;
	BUILDING_SIZE=81;
	BRIDGE_SIZE=0;
	XO_SIZE=5;
	CLOUD_SIZE=20;
	TREE_SIZE=10;
	STREET_SIZE=0;
	BONUS_SIZE=50;
	TRAIN_SIZE=3;
	GUN_SIZE=4;
	MOUNTEN_SIZE=140;
	bonus=(Bonus*)malloc(sizeof(Bonus)*BONUS_SIZE);
	cloud=(Cloud*)malloc(sizeof(Cloud)*CLOUD_SIZE);
	building=(Building*)malloc(sizeof(Building)*BUILDING_SIZE);
	xo_o=(XO*)malloc(sizeof(XO)*XO_SIZE);
	xo_x=(XO*)malloc(sizeof(XO)*XO_SIZE);
	tree=(Tree*)malloc(sizeof(Tree)*TREE_SIZE);
	if(!building||!xo_o||!xo_x||!cloud||!tree||!bonus||!train)
	{
		GameStatus=0;
		return;
	}

	Set_Train(&train[0],-50,0,30,50,0,30);
	Set_Train(&train[1],-50,0,-10,50,0,-10);
	Set_Train(&train[2],-50,0,-50,50,0,-50);

	Set_Gun(&gun[0],15,0,45,6);
	Set_Gun(&gun[1],-15,0,45,6);
	Set_Gun(&gun[2],30,0,-42,6);
	Set_Gun(&gun[3],-30,0,-42,6);

	Set_XO_Table(&table,0,10,60);
	Set_Box(&Land,0,0,0,150,0.1,200,0,0,0,1,1,0.0);
	int Mounten_Cnt=0;
	for(int i=0;i<40;i++)
	{
		for(int j=0;j<30;j++)
		{
			if(i==3 || i== 39 || j==3 || j==27)
			{
				float sy;
				sy=25+(((float)rand()/(float)(RAND_MAX))*15);
				Set_Wall(&Mounten[Mounten_Cnt],(j-10)*5-25,0,(i-15)*5-25,5,sy,5);
				Set_Color(&Mounten[Mounten_Cnt++].arr[0].color,0.8,0.8+(((float)rand()/(float)(RAND_MAX))/3),0.3 );
			}
		}
	}


	file_pointer=fopen("Maps/Map_3/building.txt","r");
	for(int i=0;i<BUILDING_SIZE-3;i++)
	{
		if(i>=70)
		{
			float x,y,z,sx,sy,sz;
			fscanf(fptr,"%f %f %f %f %f %f",&x,&y,&z,&sx,&sy,&sz);
			Set_Wall(&building[i],x,y,z,sx,sy,sz);
		}
		else
		{
			float x,y,z;
			int Type;
			fscanf(fptr,"%f %f %f %d",&x,&y,&z,&Type);
			Set_Building(&building[i],x,y,z,Type);
		}
	}
	fclose(file_pointer);
	Set_Wall(&building[75],0,20,20,140,3,3);
	Set_Building(&building[76],-12,20,20,25);
	Set_Building(&building[77],12,20,20,25);

	Set_Wall(&building[78],0,20,-25,140,3,3);
	Set_Building(&building[79],-25,20,-25,25);
	Set_Building(&building[80],25,20,-25,25);
	building[80].MoveFlag=building[76].MoveFlag=0;
	Set_Map_Objects("Maps/Map_3/");
}
void Set_Map4() //Map 4 Initialization
{
	Map=MAP_4;
	MaxHigh=50;
	BUILDING_SIZE=817;
	TANKS_SIZE=15;
	BUILDING_WITH_TANK_SIZE=0;
	BRIDGE_SIZE=6;
	XO_SIZE=5;
	CLOUD_SIZE=20;
	TREE_SIZE=400;
	STREET_SIZE=0;
	BONUS_SIZE=50;
	TRAIN_SIZE=5;
	MOUNTEN_SIZE=0;
	GUN_SIZE=5;
	int cnt_tree=0,k=0,tank_k=0,gun_k=0;
	FILE *file_pointer;
	building=(Building*)malloc(sizeof(Building)*BUILDING_SIZE);
	tree=(Tree*)malloc(sizeof(Tree)*TREE_SIZE);
	cloud=(Cloud*)malloc(sizeof(Cloud)*CLOUD_SIZE);
	bonus=(Bonus*)malloc(sizeof(Bonus)*BONUS_SIZE);
	bridge=(Bridge*)malloc(sizeof(Bridge)*BRIDGE_SIZE);
	xo_o=(XO*)malloc(sizeof(XO)*XO_SIZE);
	xo_x=(XO*)malloc(sizeof(XO)*XO_SIZE);

	Set_XO_Table(&table,0,10,90);
	Set_Helicopter(&Heli[0],table.location.x+5,table.location.y+5,table.location.z+13,0,User_Name_1.str);
	if(Two_Players())
		Set_Helicopter(&Heli[1],table.location.x-5,table.location.y+5,table.location.z+13,1,User_Name_2.str);
	Set_Box(&Land,0,0,0,150,0.1,180,0,0,0,1,1,0.0);
	
	Set_XO_Box(&xo_x[0],-30,38,0,1);
	Set_XO_Box(&xo_x[1],15,27,25,1);
	Set_XO_Box(&xo_x[2],-30,25,-40,1);
	Set_XO_Box(&xo_x[3],20,21,50,1);
	Set_XO_Box(&xo_x[4],-35,41,-55,1);
	
	Set_XO_Box(&xo_o[0],30,38,0,0);
	Set_XO_Box(&xo_o[1],-15,27,25,0);
	Set_XO_Box(&xo_o[2],25,25,-40,0);
	Set_XO_Box(&xo_o[3],-30,21,50,0);
	Set_XO_Box(&xo_o[4],30,41,-55,0);

	Set_Bridge(&bridge[0],-40,0,0,4,25,18,0);
	Set_Bridge(&bridge[1],-40,0,25,8,10,13,0);
	Set_Bridge(&bridge[2],-45,0,-40,9,11,12,0);
	Set_Bridge(&bridge[3],-45,0,50,9,11,10,0);
	Set_Bridge(&bridge[4],-45,0,-55,9,11,20,0);
	Set_Bridge(&bridge[5],-35,0,70,2,70,20,0);

	Set_Train(&train[0],-40,26,25,50,26,25);
	Set_Train(&train[1],-50,36,0,80,36,0);
	Set_Train(&train[2],-45,24,-40,50,24,-40);
	Set_Train(&train[3],-50,20,50,80,20,50);
	Set_Train(&train[4],-50,40,-55,80,40,-55);

	Set_Building(&building[800],-32,26,25,20);
	Set_Building(&building[801],28,26,25,20);
	Set_Building(&building[802],-45,36,0,20);
	Set_Building(&building[803],-5,36,0,20);
	Set_Building(&building[804],5,36,0,20);
	Set_Building(&building[805],40,36,0,20);
	Set_Building(&building[806],-47,20,50,20);
	Set_Building(&building[807],45,20,50,20);
	Set_Building(&building[808],-47,24,-40,20);
	Set_Building(&building[809],45,24,-40,20);
	Set_Building(&building[810],39,40,-55,20);
	Set_Building(&building[811],-47,40,-55,20);
	Set_Building(&building[812],-25,35,0,25);
	Set_Building(&building[813],20,35,0,25);
	Set_Building(&building[814],-20,39,70,25);
	Set_Building(&building[815],0,39,70,25);
	Set_Building(&building[816],20,39,70,25);

	building[813].MoveFlag=0;
	building[815].MoveFlag=0;
	file_pointer=fopen("Maps/Map_4/cloud.txt","r");
	for(int i=0;i<CLOUD_SIZE;i++)
	{
		float x,y,z;
		fscanf(fptr,"%f %f %f",&x,&y,&z);
		Set_Cloud(&cloud[i],x,y,z);
	}
	fclose(file_pointer);
	for(int i=0;i<40;i++)
	{
		for(int j=0;j<20;j++)
		{
			float sy;

			if(i==0||i==39||j==0||j==19)
				sy=50+(((float)rand()/(float)(RAND_MAX))*15);
			else if(i==29&&j>6&&j<12)
				sy=10+(((float)rand()/(float)(RAND_MAX))*10);
			else if(i>0&&i<5&&(j<4|| j>15))
				sy=25+(((float)rand()/(float)(RAND_MAX))*15);
			else if(i>15&&i<23&&(j<4|| j>15))
				sy=25+(((float)rand()/(float)(RAND_MAX))*15);
			else if(i<4 || i> 26 || j<4 || j>16)
				sy=((float)rand()/(float)(RAND_MAX))*8;
			else if(i<18 && i> 12 && j>8 && j<12)
				sy=35+(((float)rand()/(float)(RAND_MAX))*18);
			else if(i<30 && i> 25 && j>12 && j<18)
				sy=20+(((float)rand()/(float)(RAND_MAX))*5);
			else
				sy=5+(((float)rand()/(float)(RAND_MAX))*13);
				
			if((i==26&&j==13)||(i==10&&j==7)||(i==17&&j==10)||(i==12&&j==15)|| (i==29&&j==9)||(i==34&&j==5)||(i==7&&j==15)||(i==17&&j==18))
				Set_Tank_2(&tanks[tank_k++],(j-10)*5,sy-0.5,(i-15)*5,tank_k%2);
			if((i==12&&j==6)||(i==8&&j==9)||(i==22&&j==12)||(i==9&&j==11)|| (i==22&&j==8))
				Set_Gun(&gun[gun_k++],(j-10)*5,sy,(i-15)*5,6);
			if(cnt_tree%2==0&&k<TREE_SIZE)
				Set_Tree(&tree[k++],(j-10)*5,sy,(i-15)*5);
			cnt_tree++;
			Set_Wall(&building[(i*20)+j],(j-10)*5,0,(i-15)*5,5,sy,5);
			Set_Color(&building[(i*20)+j].arr[0].color,0.6,0.8+(((float)rand()/(float)(RAND_MAX))/3),0.6 );
		}
	}
	for(int i=0;i<BONUS_SIZE;i++)
	{
		Set_Bouns(&bonus[i],(((float)rand()/(float)(RAND_MAX))*80)-40,60,(((float)rand()/(float)(RAND_MAX))*180)-90,i%5);
		bonus[i].Status=FALLEN;
	}
	for(int i=0;i<50;i++)
		Set_Stars(&stars[i],(rand()%400)-200,70+(rand()%20),(rand()%400)-200);
	Set_Tank_1(&tanks[8],-20,48,80,0,0,0,10);
	Set_Tank_1(&tanks[9],-30,45,60,0,0,0,10);
	Set_Tank_1(&tanks[10],-40,50,-55,0,0,0,10);
	Set_Tank_1(&tanks[11],-25,47,-20,0,0,0,10);
	Set_Tank_1(&tanks[12],20,50,65,0,0,0,10);
	Set_Tank_1(&tanks[13],25,45,20,0,0,0,10);
	Set_Tank_1(&tanks[14],15,46,-40,0,0,0,10);
	glutSetCursor(GLUT_CURSOR_NONE);

}

void Reset_Buttons()
{
		Set_Color(&User_Password_2.color,1,1,1);
		Set_Color(&User_Name_2.color,1,1,1);
		Set_Color(&User_Name_1.color,1,1,1);
		Set_Color(&User_Password_1.color,1,1,1);
		Set_Color(&New_User_Name.color,1,1,1);
		Set_Color(&New_User_Password.color,1,1,1);
		Set_Color(&Name1.color,1,1,1);
		Set_Color(&Name2.color,1,1,1);
		Set_Color(&Buy[0].color,1,1,1);
		Set_Color(&Buy[1].color,1,1,1);
		Set_Color(&Buy[2].color,1,1,1);
		Set_Color(&Buy[3].color,1,1,1);
		Set_Color(&New_User_Name.color,1,1,1);
		Set_Color(&New_User_Password.color,1,1,1);
		Type_Into=nullptr;
		Typeing=0;
		MaxLevel=0;
		money=0;
}
void passiveMotionFunc(int x, int y)
{
	if(GameStatus==SCREEN_MANU|| Heli[INDEX].Ready==NOT_READY)return;
	
	if(Heli[INDEX].rotation.y < 30 && Heli[INDEX].rotation.y > -30)
	{
		if(MouseX<x)
			MoveRight(&Heli[INDEX]);
		if(MouseX>x)
			MoveLeft(&Heli[INDEX]);
		if(MouseY<y)
			MoveBack(&Heli[INDEX]);
		if(MouseY>y)
			MoveForWord(&Heli[INDEX]);
	}
	if(Heli[INDEX].rotation.y >= 30 && Heli[INDEX].rotation.y < 70)
	{
		if(MouseX<x)
		{
			MoveForWord(&Heli[INDEX]);
			MoveRight(&Heli[INDEX]);
		}
		if(MouseX>x)
		{
			MoveBack(&Heli[INDEX]);
			MoveLeft(&Heli[INDEX]);
		}
		if(MouseY<y)
		{
			MoveRight(&Heli[INDEX]);
			MoveBack(&Heli[INDEX]);
		}
		if(MouseY>y)
		{
			MoveLeft(&Heli[INDEX]);
			MoveForWord(&Heli[INDEX]);
		}
	}
	if(Heli[INDEX].rotation.y >= 70 && Heli[INDEX].rotation.y < 120)
	{
		if(MouseX<x)
			MoveForWord(&Heli[INDEX]);
		if(MouseX>x)
			MoveBack(&Heli[INDEX]);
		if(MouseY<y)
			MoveRight(&Heli[INDEX]);
		if(MouseY>y)
			MoveLeft(&Heli[INDEX]);
	}
	if(Heli[INDEX].rotation.y >= 120 && Heli[INDEX].rotation.y < 150)
	{
		if(MouseX<x)
		{
			MoveLeft(&Heli[INDEX]);
			MoveForWord(&Heli[INDEX]);
		}
		if(MouseX>x)
		{
			MoveBack(&Heli[INDEX]);
			MoveRight(&Heli[INDEX]);
		}
		if(MouseY<y)
		{
			MoveRight(&Heli[INDEX]);
			MoveForWord(&Heli[INDEX]);
		}
		if(MouseY>y)
		{
			MoveLeft(&Heli[INDEX]);
			MoveBack(&Heli[INDEX]);
		}
	}
	if(Heli[INDEX].rotation.y > -150 && Heli[INDEX].rotation.y <= -120)
	{
		if(MouseX<x)
		{
			MoveLeft(&Heli[INDEX]);
			MoveBack(&Heli[INDEX]);
		}
		if(MouseX>x)
		{
			MoveForWord(&Heli[INDEX]);
			MoveRight(&Heli[INDEX]);
		}
		if(MouseY<y)
		{
			MoveLeft(&Heli[INDEX]);
			MoveForWord(&Heli[INDEX]);
		}
		if(MouseY>y)
		{
			MoveRight(&Heli[INDEX]);
			MoveBack(&Heli[INDEX]);
		}
	}

	if(Heli[INDEX].rotation.y > -120 && Heli[INDEX].rotation.y <= -70)
	{
		if(MouseX<x)
			MoveBack(&Heli[INDEX]);
		if(MouseX>x)
			MoveForWord(&Heli[INDEX]);
		if(MouseY<y)
			MoveLeft(&Heli[INDEX]);
		if(MouseY>y)
			MoveRight(&Heli[INDEX]);
	}

	if(Heli[INDEX].rotation.y > -70 && Heli[INDEX].rotation.y <= -30)
	{
		if(MouseX<x)
		{
			MoveRight(&Heli[INDEX]);
			MoveBack(&Heli[INDEX]);
		}
		if(MouseX>x)
		{
			MoveForWord(&Heli[INDEX]);
			MoveLeft(&Heli[INDEX]);
		}
		if(MouseY<y)
		{
			MoveLeft(&Heli[INDEX]);
			MoveBack(&Heli[INDEX]);
		}
		if(MouseY>y)
		{
			MoveRight(&Heli[INDEX]);
			MoveForWord(&Heli[INDEX]);
		}
	}
	if(Heli[INDEX].rotation.y >= 150 || Heli[INDEX].rotation.y <= -150)
	{
		if(MouseX<x)
			MoveLeft(&Heli[INDEX]);
		if(MouseX>x)
			MoveRight(&Heli[INDEX]);
		if(MouseY<y)
			MoveForWord(&Heli[INDEX]);
		if(MouseY>y)
			MoveBack(&Heli[INDEX]);
	}

	SetCursorPos(20,20);
	MouseX=20;
	MouseY=20;
}
void Next_Building() //Changing Build To Show In Game Objects Page
{
	if(Object_Build_Turn==-1)Object_Build_Turn=24;
	if(Object_Build_Turn==25)Object_Build_Turn=0;
	if(Object_Build!=nullptr) free(Object_Build);
	Object_Build=(Building*)malloc(sizeof(Building));
	Set_Building(Object_Build,25,-15,-50,Object_Build_Turn);
}
void glutMouseClick(int btn, int state, int x, int y)
{
	if(Roller!=0&&Roller!=100)return;
	if(GameStatus==SCREEN_CHOOSE_PLAYERS && btn==GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		if(ClickButton(Player1,x,y))
		{
			Players_flag=ONE_PLAYER;
			Set_Buttons();
			Roller=0;
			GameStatus=SCREEN_MANU;
			MainPage=MOVE_MAP_TO_MAIN;
			INDEX=0;
		}
		if(ClickButton(Players2,x,y))
		{
			Players_flag=TWO_PLAYERS;
			Set_Buttons();
			Roller=0;
			GameStatus=SCREEN_MANU;
			MainPage=MOVE_MAP_TO_MAIN;

		}
		if(ClickButton(Register,x,y))
		{
			Reset_Buttons();
			strcpy(Login_Status," ");
			GameStatus=SCREEN_NEWUSER;
		}
		return;
	}
	if(GameStatus==SCREEN_NEWUSER && btn==GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		if(ClickButton(Register_Button,x,y))
		{
			int status;
			if(strcmp(New_User_Name.str,"")==0 || strcmp(New_User_Password.str,"") ==0)
			{
				strcpy(Register_Status,"Fill User And Password");
				return;
			}
			status=New_User(New_User_Name.str,New_User_Password.str);
			if(status==0)
				strcpy(Register_Status,"User Already Registered");
			if(status==1)
				strcpy(Register_Status,"Successfuly Registered");
			Reset_Buttons();
			strcpy(New_User_Name.str," ");
			strcpy(New_User_Password.str," ");
			Remove_Char(New_User_Name.str);
			Remove_Char(New_User_Password.str);
			return;
		}
		if(ClickButton(BackMain2,x,y))
		{
			Reset_Buttons();
			GameStatus=SCREEN_CHOOSE_PLAYERS;
		}
		if(ClickButton(New_User_Name,x,y))
		{
			Reset_Buttons();
			strcpy(Register_Status," ");
			Type_Into=&New_User_Name;
			Typeing=1;
			Set_Color(&New_User_Name.color,1,0,0);
		}
		if(ClickButton(New_User_Password,x,y))
		{
			Reset_Buttons();
			strcpy(Register_Status," ");
			Type_Into=&New_User_Password;
			Typeing=1;
			Set_Color(&New_User_Password.color,1,0,0);
		}
		return;
	}
	if(GameStatus==SCREEN_OBJECTS && btn == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		if(ClickButton(Opject_Back,x,y))
			GameStatus=SCREEN_MANU;
		if(ClickButton(Left_Opject,x,y))
		{
			Object_Build_Turn--;
			Next_Building();
		}
		if(ClickButton(Right_Opject,x,y))
		{
			Object_Build_Turn++;
			Next_Building();
		}
		return;
	}
	if(GameStatus==SCREEN_MANU && btn == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		if(ClickButton(Back,x,y))
			MainPage=MOVE_MAP_TO_MAIN;
		else if(ClickButton(BackMain,x,y))
			MainPage=MOVE_GAMES_TO_MAIN;
		else if(ClickButton(BackMain1,x,y))
			MainPage=MOVE_DETAILS_TO_MAIN;			
		else if(ClickButton(Store,x,y)){
			MainPage=MOVE_MAP_TO_STORE;
			clickName=0;
		}
		else if(ClickButton(BackFromStore,x,y)){
			Reset_Buttons();
			MainPage=MOVE_STORE_TO_MAP;	
			Price_Bomb=Price_Bullet=Price_Missile=Price_Upgrade=0;
		}
		else if(ClickButton(Register,x,y))
		{
			strcpy(Login_Status," ");
			MainPage=MOVE_MAIN_TO_REGISTER;
		}
		else if(ClickButton(Exit,x,y))
			exit(1);	
		else if(ClickButton(Night_Day,x,y))
		{
			if(Night_Day_Flag==0)
			{
				strcpy(Night_Day.str,"Nigth");
				Set_Color(&Night_Day.color,0,0,0);
			}
			else
			{
				strcpy(Night_Day.str,"Day");
				Set_Color(&Night_Day.color,1,1,1);
				density=0;
				glFogf (GL_FOG_DENSITY, density);
			}
			Night_Day_Flag=!Night_Day_Flag;
		}
		else if(ClickButton(ChooseMap,x,y))
		{
			if(Players_flag==ONE_PLAYER)
			{
				if(strcmp(User_Name_1.str,"")==0 || strcmp(User_Password_1.str,"")==0)
					strcpy(Login_Status,"You should to fill Username and Password");
				else if(Login(User_Name_1.str,Hidden_Password1)!=1)
					strcpy(Login_Status,"Username OR Password for Player 1 incorrect");
				else
				{
					Reset_Buttons();
					strcpy(Login_Status," ");
					Set_Button(&Name1,17,2,1,1,1,1,User_Name_1.str);
					MainPage=MOVE_MAIN_TO_MAP;
					strcpy(Name1.str,User_Name_1.str);
				}
				return;
			}

			if(Two_Players())
			{
				if(strcmp(User_Name_1.str,"")==0 || strcmp(User_Name_2.str,"")==0 || strcmp(User_Password_1.str,"")==0 || strcmp(User_Password_2.str,"")==0)
					strcpy(Login_Status,"You should to fill Username and Password");
				else if(strcmp(User_Name_1.str,User_Name_2.str)==0)
					strcpy(Login_Status,"Users are the same");
				else if(Login(User_Name_1.str,Hidden_Password1)!=1)
					strcpy(Login_Status,"Username OR Password for Player 1 incorrect");
				else if (Login(User_Name_2.str,Hidden_Password2)!=1)
					strcpy(Login_Status,"Username OR Password for Player 2 incorrect");
				else
				{
					Reset_Buttons();
					strcpy(Login_Status," ");
					Set_Button(&Name1,17,2,1,1,1,1,User_Name_1.str);
					Set_Button(&Name2,17,1.3,1,1,1,1,User_Name_2.str);
					MainPage=MOVE_MAIN_TO_MAP;
					strcpy(Name1.str,User_Name_1.str);
					strcpy(Name2.str,User_Name_2.str);
				}
				return;
			}
		}
		else if(ClickButton(ShowGames,x,y))
		{
			strcpy(Login_Status," ");
			MainPage=MOVE_MAIN_TO_GAMES;
		}
		
		else if(ClickButton(Show_Opjects,x,y))
		{
			Next_Building();
			GameStatus=SCREEN_OBJECTS;
		}
		else if(ClickButton(Details,x,y))
		{
			MainPage=MOVE_MAIN_TO_DETAILS;
			strcpy(Login_Status," ");
		}
		else if(ClickButton(Map1,x,y))
		{
			Set_Map1();
			GameStatus=SCREEN_PLAYING;
		}
		else if(ClickButton(Map2,x,y))
		{
			Set_Map2();
			GameStatus=SCREEN_PLAYING;
		}
		else if(ClickButton(Map3,x,y))
		{
			Set_Map3();
			GameStatus=SCREEN_PLAYING;
		}
		else if(ClickButton(Map4,x,y))
		{
			Set_Map4();
			GameStatus=SCREEN_PLAYING;
		}
		else if(ClickButton(Up,x,y))
		{
			tmp=Game_List;
			if(tmp)
				tmp=tmp->next;
			while(tmp!=nullptr)
			{
				tmp->y+=0.1;
				tmp=tmp->next;
			}
		}
		else if(ClickButton(Down,x,y))
		{
			tmp=Game_List;
			if(tmp)
				tmp=tmp->next;
			while(tmp!=nullptr)
			{
				tmp->y-=0.1;
				tmp=tmp->next;
			}
		}
		else if(ClickButton(User_Name_1,x,y))
		{
			Reset_Buttons();
			Type_Into=&User_Name_1;
			Typeing=1;
			Set_Color(&User_Name_1.color,1,0,0);
			return;
		}
		else if(ClickButton(User_Password_1,x,y))
		{
			Reset_Buttons();
			Typeing=1;
			Type_Into=&User_Password_1;
			Hidden_Password=Hidden_Password1;
			Set_Color(&User_Password_1.color,1,0,0);
			return;
		}
		else if(ClickButton(User_Name_2,x,y))
		{
			Reset_Buttons();
			Typeing=1;
			Type_Into=&User_Name_2;
			Set_Color(&User_Name_2.color,1,0,0);
			return;
		}
		else if(ClickButton(User_Password_2,x,y))
		{
			Reset_Buttons();
			Typeing=1;
			Type_Into=&User_Password_2;
			Hidden_Password=Hidden_Password2;
			Set_Color(&User_Password_2.color,1,0,0);
			return;
		}
		else if(ClickButton(Name1,x,y))
		{
			Reset_Buttons();
			user=Get_User(Name1.str);
			clickName=1;
			Price_Bomb=50*user->Bomb_Damage;
			Price_Bullet=50*user->Bullet_Damage;
			Price_Missile=50*user->Missile_Damage;
			Price_Upgrade=200*(user->Type+1);
			Set_Color(&Name1.color,1,0,0);
			return;
		}
		else if(ClickButton(Name2,x,y) && Two_Players())
		{
			Reset_Buttons();
			user=Get_User(Name2.str);
			clickName=2;
			Price_Bomb=50*user->Bomb_Damage;
			Price_Bullet=50*user->Bullet_Damage;
			Price_Missile=50*user->Missile_Damage;
			Price_Upgrade=200*(user->Type+1);
			Set_Color(&Name2.color,1,0,0);
			return;
		}
		else if(ClickButton(Buy[0],x,y))
		{
			if(user==nullptr)return;
			Reset_Buttons();
			Set_Color(&Buy[0].color,1,0,0);
			if(user->Coins >=50*user->Bomb_Damage)
			{
				Price_Bomb=50*user->Bomb_Damage;
				user->Bomb_Damage+=1.0;
				user->Coins-=Price_Bomb;
				In_User(user);
			}
			else
				money=1;
		}
		else if(ClickButton(Buy[1],x,y))
		{
			if(user==nullptr)return;
			Reset_Buttons();
			Set_Color(&Buy[1].color,1,0,0);
			if(user->Coins >=50*user->Bullet_Damage)
			{
				Price_Bullet=50*user->Bullet_Damage;
				user->Bullet_Damage+=1.0;
				user->Coins-=Price_Bullet;
				In_User(user);
			}
			else
				money=1;
					
		}
		else if(ClickButton(Buy[2],x,y))
		{
			if(user==nullptr)return;
			Reset_Buttons();
			Set_Color(&Buy[2].color,1,0,0);
			if(user->Coins >=50*user->Missile_Damage)
			{
				Price_Missile=50*user->Missile_Damage;
				user->Missile_Damage+=1.0;
				user->Coins-=Price_Missile;
				In_User(user);
			}
			else
				money=1;
					
		}
		else if(ClickButton(Buy[3],x,y))
		{
			if(user==nullptr)return;
			Reset_Buttons();
			Set_Color(&Buy[3].color,1,0,0);
			if(user->Type==2)
				MaxLevel=1;
			else if(user->Coins >=200*(user->Type+1))
			{
				Price_Upgrade=200*(user->Type+1);
				user->Type+=1;
				user->Coins-=Price_Upgrade;
				In_User(user);
			}
			else
				money=1;
					
		}
		else
		{
			Reset_Buttons();
			if(!ClickButton(ChooseMap,x,y))
			{
				strcpy(Login_Status," ");
				strcpy(Register_Status," ");
			}
		}	
	}
}
void Set_Buttons()//Buttons Initialization
{
	MainX=0.0;
	MainY=0.0;
	InfoX=-12;
	InfoY=0;
	StoreX=19;

	Set_Building(&Shown_Bulding[0],175,-8,-100,4);
	Set_Building(&Shown_Bulding[1],175,15,-100,6);
	Set_Building(&Shown_Bulding[2],175,-25,-100,12);
	Set_Building(&Shown_Bulding[3],15,-15,-25,22);
	Set_Building(&Shown_Bulding[4],-15,-15,-25,24);

	Set_Button(&Store,13,-2,1,10,10,10,"Store");
	Set_Button(&Night_Day,10,-2,1,10,10,10,"Day");
	Set_Button(&BackFromStore,16,-2,1,10,10,10,"Back");
	Set_Button(&Buy[0],17,-0.5,1,10,10,10,"Buy Damage Bomb");
	Set_Button(&Buy[1],20,-0.5,1,10,10,10,"Buy Damage Bullet");
	Set_Button(&Buy[2],23,-0.5,1,10,10,10,"Buy Damage Missile");
	Set_Button(&Buy[3],23,-2,1,10,10,10,"Upgrade");

	Set_Button(&Map1,12,1,1,10,10,10,"Villa");
	Set_Button(&Map2,12,0,1,1,10,10,"City_2");
	Set_Button(&Map3,12,-1,1,10,10,1,"Eqypt HARD");
	Set_Button(&Map4,12,2,1,1,10,1,"Mountens HARD");
	Set_Button(&Back,8,-1,1,10,10,10,"Back");
	Set_Button(&Up,-3,-11,1,10,10,10,"UP");
	Set_Button(&Down,-3,-12,1,10,10,10,"Down");

	Set_Button(&Border,1,-11,2,10,10,10,"");
	Set_Button(&ShowGames,0,-2,1,10,10,10,"ShowGames");
	Set_Button(&BackMain,-3,-8,1,10,10,10,"Back");
	Set_Button(&ChooseMap,3,-1,1,2,5,2,"ChooseMap");
	Set_Button(&Exit,4,2.5,1,10,0,0,"Exit");

	Set_Bouns(&Shown_Bonus[0],-20,5,-14,0);
	Set_Button(&DrawBullet,-14,2,1,10,10,10,"Bullet");
	Set_Bouns(&Shown_Bonus[1],-20,2.5,-14,2);
	Set_Button(&DrawBomb,-14,1.2,1,10,10,10,"Bomb");
	Set_Bouns(&Shown_Bonus[2],-20,0.5,-14,1);
	Set_Button(&DrawMissile,-14,0.4,1,10,10,10,"Missile");
	Set_Bouns(&Shown_Bonus[3],-20,-2,-14,3);
	Set_Button(&DrawCoins,-14,-0.4,1,10,10,10,"Coin");
	Set_Bouns(&Shown_Bonus[4],-20,-4,-14,4);
	Set_Button(&DrawFuel,-14,-1.2,1,10,10,10,"Fuel");
	Set_Button(&Details,-4,-2,1,10,10,10,"Details");
	Set_Button(&BackMain1,-7,-2,1,10,10,10,"Back");
	Set_Button(&Show_Opjects,-10,-2,1,10,10,10,"Show_Opjects");
	Set_Button(&Name1,17,2,1,10,10,10,"");
	Set_Button(&Name2,17,1.3,1,10,10,10,"");

	Set_Bouns(&Damage_Bonus[0],200,0,-10,0);
	Set_Bouns(&Damage_Bonus[1],206,0,-10,1);
	Set_Bouns(&Damage_Bonus[2],194,0,-10,2);

	Set_Button(&Left_Opject,0.8,2,1,10,10,10,"Previus");
	Set_Button(&Right_Opject,3.2,2,1,10,10,10,"Next");
	Set_Button(&Opject_Back,-3,-2.5,1,10,10,10,"Back");

	Set_Button(&Player1,-1.5,-1,1,10,10,10,"1 Players");
	Set_Button(&Players2,1.5,-1,1,10,10,10,"2 Players");

	Set_Tank(&Object_Tanks[0],-20,8,-25,SMALL_MISSILE);
	Set_Tank(&Object_Tanks[1],-20,3,-25,BIG_MISSILE);
	Set_Tank_2(&Object_Tanks[2],-20,-3,-25,SMALL_MISSILE);
	Set_Tank_2(&Object_Tanks[3],-20,-8,-25,BIG_MISSILE);

	Set_Trailer(&Object_Trailers[0],-10,8,-25,TRILER_TYPE_0);
	Set_Trailer(&Object_Trailers[1],-10,3,-25,TRILER_TYPE_1);
	Set_Trailer(&Object_Trailers[2],-10,-3,-25,TRILER_TYPE_2);
	Set_Trailer(&Object_Trailers[3],-10,-8,-25,TRILER_TYPE_3);

	Set_Bullding_With_Tank(&Object_Building_With_Tank,0,-8,-30,BIG_MISSILE);
	if(Players_flag==ONE_PLAYER)
	{
		Set_Button(&User_Name_1,0,1,1,10,10,10,"");
		Set_Button(&User_Password_1,0,0,1,10,10,10,"");
	}
	if(Two_Players())
	{
		Set_Button(&User_Name_1,-2,1,1,10,10,10,"");
		Set_Button(&User_Name_2,2,1,1,10,10,10,"");
		Set_Button(&User_Password_1,-2,0,1,10,10,10,"");
		Set_Button(&User_Password_2,2,0,1,10,10,10,"");
	}
	Set_Button(&Register,-3.5,2,1,10,10,10,"New User");
	Set_Button(&BackMain2,-4,-2,1,10,10,10,"Back");
	Set_Button(&New_User_Name,-2,1,1,10,10,10,"");
	Set_Button(&New_User_Password,-2,0,1,10,10,10,"");
	Set_Button(&Register_Button,-0.5,-1,1,10,10,10,"Register");
}
void Set_Manu()//Games List Initialization
{
	for(GameList *tmp=Game_List;tmp!=nullptr;Game_List=Game_List->next,tmp=Game_List,free(tmp));
	float List_y=2;
	Game_List = Add_GameList (Game_List, Create_Game(0.5,-(8+List_y),"Player 1","Player 2","Winner_Is") );
	List_y+=0.7;
	fptr=fopen("Score.txt","r");
	while(!feof(fptr))
	{		
		if(EOF==fgetc(fptr))break;
		fseek(fptr,-1,SEEK_CUR);
		fscanf(fptr,"%s",str1);
		fscanf(fptr,"%s",str2);
		fscanf(fptr,"%s",Winner_str);
		Game_List = Add_GameList (Game_List, Create_Game(0.5,-(8+List_y),str1,str2,Winner_str) );
		List_y+=0.3;
	}
	fclose(fptr);
	Set_Buttons();
}
void keyboard(unsigned char key, int x, int y)
{
	if(GameStatus==SCREEN_PLAYING && Heli[INDEX].Health<=0 || Roller>0&&Roller<100)
		return;
	if(GameStatus==SCREEN_WINNER)
	{
		GameStatus=SCREEN_MANU;
		return;
	}
	if (key == 27)
	{
		if(GameStatus==SCREEN_PLAYING)
		{
			if(Heli[INDEX].Ready==1)
				Heli[INDEX].Ready=0;
			else{
				Typeing=0;
				Game_Draw();
			}
			return;
		}
		if(GameStatus==SCREEN_MANU)
		{
			GameStatus=SCREEN_CHOOSE_PLAYERS;
			return;
		}
		if(GameStatus==SCREEN_CHOOSE_PLAYERS)
			exit(1);
	}
	if(!Typeing)
	{
		if(key=='v')
		{
			Shoot_Bomb(&Heli[INDEX]);
		}
		if(key=='r')
		{
			Shoot_Bullet(&Heli[INDEX]);
		}
		if(key=='f')
		{
			Shoot_Missile(&Heli[INDEX]);
		}
		if(key=='p')
		{
			SwitchPlayer();
		}
		if (key == 'g') {
			Throw_Xo(&Heli[INDEX]);
		}
		if(key=='s')
		{
			Heli[INDEX].aim.UPDown-=0.4;
		}
		if (key == 'w') {
			Heli[INDEX].aim.UPDown+=0.4;
		}

		if(key=='a')
		{
			Heli[INDEX].rotation.y+=5;
			if(Heli[INDEX].rotation.y==185)Heli[INDEX].rotation.y=-175;
		}	
		if(key=='d')
		{
			Heli[INDEX].rotation.y-=5;
			if(Heli[INDEX].rotation.y==-185)Heli[INDEX].rotation.y=175;
		}
		if(key==' ' && Heli[INDEX].FanSpeed<35)Heli[INDEX].FanSpeed++;
		if(key=='c' && Heli[INDEX].FanSpeed>25)Heli[INDEX].FanSpeed--;
		
		if(key=='A')
		{
			Heli[INDEX].LookAround_Y-=5;
			Heli[INDEX].LookAround_Y%=360;
		}	
		if(key=='D')
		{
			Heli[INDEX].LookAround_Y+=5;
			Heli[INDEX].LookAround_Y%=360;
		}
		if(key=='S')
		{
			Heli[INDEX].LookAround_X-=5;
			Heli[INDEX].LookAround_X%=360;
		}
		if (key == 'W') {
			Heli[INDEX].LookAround_X+=5;
			Heli[INDEX].LookAround_X%=360;
		}
		if(key=='+')
			Heli[INDEX].CameraZ-=1;
		if (key == '-') 
			Heli[INDEX].CameraZ+=1;
		if(key==']')
			Heli[INDEX].CameraX-=1;
		if (key == '[') 
			Heli[INDEX].CameraX+=1;
		if(key=='E')
			Heli[INDEX].CameraY-=1;
		if (key == 'Q') 
			Heli[INDEX].CameraY+=1;
		if (key == 'X') 
			Heli[INDEX].Ready=READY;
		if(key=='1')
		{
			Heli[INDEX].CameraZ=15;
			Heli[INDEX].CameraY=2;
			Heli[INDEX].CameraX=2;
			Heli[INDEX].LookAround_X=0;
			Heli[INDEX].LookAround_Y=0;
		}
		if(key=='2')
		{
			Heli[INDEX].CameraZ=8;
			Heli[INDEX].CameraY=2;
			Heli[INDEX].CameraX=2;
			Heli[INDEX].LookAround_X=0;
			Heli[INDEX].LookAround_Y=0;
		}
		if(key=='3')
		{
			Heli[INDEX].CameraZ=15;
			Heli[INDEX].CameraY=2;
			Heli[INDEX].CameraX=-2;
			Heli[INDEX].LookAround_X=0;
			Heli[INDEX].LookAround_Y=0;
		}
		if(key=='4')
		{
			Heli[INDEX].CameraZ=8;
			Heli[INDEX].CameraY=2;
			Heli[INDEX].CameraX=-2;
			Heli[INDEX].LookAround_X=0;
			Heli[INDEX].LookAround_Y=0;
		}
		if(key=='5')
		{
			Heli[INDEX].CameraZ=0;
			Heli[INDEX].CameraY=1;
			Heli[INDEX].CameraX=0;
			Heli[INDEX].LookAround_X=0;
			Heli[INDEX].LookAround_Y=0;
		}
	}
	if(Typeing)
	{
		if(Type_Into != &User_Password_1 && Type_Into != &User_Password_2)
		{
			if(key==8)
				Remove_Char(Type_Into->str);
			else
				Type_Name(Type_Into->str,key);
		}
		else
		{
			if(key==8)
			{
				Remove_Char(Type_Into->str);
				Remove_Char(Hidden_Password);
			}
			else
			{
				Type_Name(Hidden_Password,key);
				Type_Name(Type_Into->str,'*');
			}
		}
		
	}
	glutPostRedisplay();
}
void Sun_Light() // Control The Space
{
	/************************************************************/
	/************************************************************/
	if(Night_Day_Flag==1)
	{
		if(sin(y)>0&&density>0)
			density-=0.00004;
		if(sin(y)<0&&density<0.02)
			density+=0.00004;		
		glFogf (GL_FOG_DENSITY, density);
	}
	 
	glDisable(GL_LIGHT0);
	glDisable(GL_FOG);
	GLfloat light_position[4]={x*150,y*150,z*150,0};
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);

	if(Night_Day_Flag==1)
	{
		if(sin(y)<0.0)
			glClearColor(0, 0, 0, 0.0);
		else
			glClearColor(sin(y)*0.3, sin(y)*0.3, sin(y)*1, 0.0);
	}
	else
		glClearColor(0.3, 0.5, 1, 0.0);
	
	glTranslatef(x*150,(y*150),z*150);
	glColor3f(10,10,1);
	glutSolidSphere(10,32,32);
	glTranslatef(-x*150,-(y*150),-z*150);

	glTranslatef((x*100),-(y*100),-(z*100));
	glColor3f(10,10,10);
	glutSolidSphere(4,32,32);
	glTranslatef(-x*100,(y*100),z*100);

	for(int i=0;i<50;i++)
		Draw_Star(&stars[i]);

	glTranslatef(x*120,70,y*120);
		glColor3f(13,1,10);
		glutSolidSphere(10,32,32);
			glRotatef(30,1,0,1);
				glScalef(20,1,20);
					glColor3f(0.4,1,0.3);
					glutSolidSphere(1,32,32);
				glScalef(0.05,1,0.05);
			glRotatef(-30,1,0,1);
	glTranslatef(-x*120,-70,-y*120);

	glTranslatef(-x*120,80,-y*120);
	glColor3f(1,13,10);
	glutSolidSphere(9,32,32);
	glTranslatef(x*120,-80,y*120);

	glTranslatef(0,80,-200);
		glColor3f(0.4,10,0.3);
		glutSolidSphere(24,32,32);
		glColor3f(10,0.4,0.3);
			glTranslatef(-x*30,15,-y*30);
			glutSolidSphere(7,32,32);
			glTranslatef(x*30,-15,y*30);
	glTranslatef(0,-80,200);

	glEnable(GL_FOG);
	glEnable(GL_LIGHT0);

		a = PI * i;
		x = sin(a/180);
		y = cos(a/180);
		z = sin(a/180);
		i+=0.2;
		if(i>360)i=0;
}
void Light_1() 
{
	GLfloat mat_ambdif[] = { 1, 1, 1, 1 };
	GLfloat mat_specular[] = { 1, 1, 1, 1 };
	GLfloat mat_diffuseLight[] = {1,1,1,1};
	GLfloat mat_shininess[] = { 80.0 };
	GLfloat light_position[] = { 5, 5, 5, 0.0 };
	glClearColor(0.3, 0.3, 1.0, 0.0);

	glMaterialfv(GL_LIGHT0, GL_AMBIENT_AND_DIFFUSE, mat_ambdif);	// set both amb and diff components
	glMaterialfv(GL_LIGHT0, GL_SPECULAR, mat_specular);		// set specular
	glMaterialfv(GL_LIGHT0, GL_SHININESS, mat_shininess);		// set shininess
	glMaterialfv(GL_LIGHT0, GL_DIFFUSE, mat_diffuseLight);		// set shininess
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);		// set light "position", in this case direction
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);		// active material changes by glColor3f(..)
	glEnable(GL_COLOR_MATERIAL);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
}
void GamePlay_Page() 
{
	/************************************************************/

    Light_1();
	Draw_Player(&Heli[INDEX]);
	Sun_Light();
	if(Two_Players())
		Draw_Wainting_Player(&Heli[!INDEX]);	
	Draw_XO_Table(&table);
	for(int i=0;i<GUN_SIZE;i++)
		Draw_Gun(&gun[i]);
	for(int i=0;i<TRAIN_SIZE;i++)
		Draw_Train(&train[i]);
	for(int i=0;i<BONUS_SIZE;i++)
		Draw_Bonus(&bonus[i]);
	for(int i=0;i<TANKS_SIZE;i++)
		Draw_Tank(&tanks[i]);
	for(int i=0;i<BUILDING_WITH_TANK_SIZE;i++)
		Draw_Bullding_With_Tank(&building_Tank[i]);
	for(int i=0;i<BUILDING_SIZE;i++)
		Draw_Building(&building[i]);
	for(int i=0;i<MOUNTEN_SIZE;i++)
		Draw_Building(&Mounten[i]);
	for(int i=0;i<BRIDGE_SIZE;i++)
		Draw_Bridge(&bridge[i]);
	for(int i=0;i<CLOUD_SIZE;i++)
		Draw_Cloud(&cloud[i]);
	for(int i=0;i<TREE_SIZE;i++)
		Draw_Tree(&tree[i]);
	for(int i=0;i<STREET_SIZE;i++)
		Draw_Street(&street[i]);
	if(Two_Players())
		for(int i=0;i<XO_SIZE;i++)
			if(xo_o[i].Status!=CATCHED)	Draw_XO_Box(&xo_o[i]);
	for(int i=0;i<XO_SIZE;i++)
		if(xo_x[i].Status!=CATCHED)	Draw_XO_Box(&xo_x[i]);
	Draw_Box_TR(Land);
}
void Manu_Page()
{	
	Sun_Light();
	Light_1();
	glClearColor(0.3,0.3,1,1);

	tmp=Game_List;
	glColor3f(0,0,0);
	Draw_Gamelist(Game_List);
	while(tmp!=nullptr)
	{
		if(tmp->y<-0.5 && tmp->y>-1.5)
		Draw_Gamelist(tmp);
		tmp=tmp->next;
	}
	if(clickName==1)
		Print_User(Name1.str);
	if(clickName==2)
		Print_User(Name2.str);
	if(money==1)
		Draw_String(10,0,0,0+StoreX,-1.5,-5,"You didnt have enough money");
	if(MaxLevel==1)
		Draw_String(10,0,0,0+StoreX,-1.5,-5,"You Have Got To Max Level");

	Draw_Button(&BackMain);
	Draw_Button(&ShowGames);
	Draw_Button(&Up);
	Draw_Button(&Down);
	Draw_Button(&Border);
	
	Draw_Button(&ChooseMap);
	Draw_Button(&Exit);
	Draw_Button(&Map1);
	Draw_Button(&Map2);
	Draw_Button(&Map3);
	Draw_Button(&Map4);
	Draw_Button(&Back);
	Draw_Button(&Details);
	Draw_Button(&BackMain1);
	Draw_Button(&DrawBullet);
	Draw_Button(&DrawBomb);
	Draw_Button(&DrawMissile);
	Draw_Button(&DrawCoins);
	Draw_Button(&DrawFuel);
	Draw_Button(&Show_Opjects);

	for(int i=0;i<5;i++)
		Draw_Bonus(&Shown_Bonus[i]);
	for(int i=0;i<3;i++)
		Draw_Building(&Shown_Bulding[i]);
		for(int i=0;i<3;i++)
	Draw_Bonus(&Damage_Bonus[i]);
	for(int i=0;i<4;i++)
		Draw_Button(&Buy[i]);
	
	Draw_String_int(1,1,1,-3+StoreX,-1,-5,"%d",Price_Bomb);
	Draw_String_int(1,1,1,0+StoreX,-1,-5,"%d",Price_Bullet);
	Draw_String_int(1,1,1,3+StoreX,-1,-5,"%d",Price_Missile);
	if(Price_Upgrade!=600)
		Draw_String_int(1,1,1,3+StoreX,-2.5,-5,"%d",Price_Upgrade);
	else
		Draw_String(1,1,1,3+StoreX,-2.5,-5,"MAX_LEVEL");

	Draw_String(1,1,1,0+StoreX,2,-5,"XO-Helicopter STORE");
	Draw_Button(&Store);
	Draw_Button(&BackFromStore);
	Draw_Button(&Night_Day);

	Draw_String(0,1,0,InfoX,InfoY+2.2,-5,"Game Controls : ");
	Draw_String(0,0,0,InfoX,InfoY+1.8,-5,"W : Aim T0 Up");
	Draw_String(0,0,0,InfoX,InfoY+1.6,-5,"S : Aim To Down");
	Draw_String(0,0,0,InfoX,InfoY+1.4,-5,"D : Rotate Right      ");
	Draw_String(0,0,0,InfoX,InfoY+1.2,-5,"A : Rotate Left");
	Draw_String(0,0,0,InfoX,InfoY+1.0,-5,"E : Look Right");
	Draw_String(0,0,0,InfoX,InfoY+0.8,-5,"Q : Look Left");
	Draw_String(0,0,0,InfoX,InfoY+0.6,-5,"R : Shoot Bullets");
	Draw_String(0,0,0,InfoX,InfoY+0.4,-5,"F : Shoot Missles");
	Draw_String(0,0,0,InfoX,InfoY+0.2,-5,"V : Shoot Bombs");

	Draw_String(0,0,0,InfoX+2.1,InfoY+1.8,-5,"Space : Go Up");
	Draw_String(0,0,0,InfoX+2.1,InfoY+1.6,-5,"C    : Go Down");
	Draw_String(0,0,0,InfoX+2.1,InfoY+1.4,-5,"G : Throw XO ");
	Draw_String(0,0,0,InfoX+2.1,InfoY+1.2,-5,"Shift + W : Look Up");
	Draw_String(0,0,0,InfoX+2.1,InfoY+1.0,-5,"Shift + S : Look Down");
	Draw_String(0,0,0,InfoX+2.1,InfoY+0.8,-5,"Shift + D : Look Right");
	Draw_String(0,0,0,InfoX+2.1,InfoY+0.6,-5,"Shift + A : Look Left");
	
	Draw_String(0,0,0,InfoX+4.2,InfoY+1.8,-5,"Shift + Q : Camera Up");
	Draw_String(0,0,0,InfoX+4.2,InfoY+1.6,-5,"Shift + E : Camera Down");
	Draw_String(0,0,0,InfoX+4.2,InfoY+1.4,-5,"']' : Camera Left");
	Draw_String(0,0,0,InfoX+4.2,InfoY+1.2,-5,"'[' : Camera Right");
	Draw_String(0,0,0,InfoX+4.2,InfoY+1.0,-5,"'+' : Camera In");
	Draw_String(0,0,0,InfoX+4.2,InfoY+0.8,-5,"'-' : Camera Out");
	
	Draw_String(0,0,0,InfoX+17.5,InfoY+2.5,-5,"Game Rules : ");
	Draw_String(0,0,0,InfoX+17.5,InfoY+2.3,-5,"You Have To Take The X Or O And To Throw It At The XO_Table");
	Draw_String(0,0,0,InfoX+17.5,InfoY+2.1,-5,"Before The Fuel Ends");
	Draw_String(0,0,0,InfoX+17.5,InfoY+1.9,-5,"Important , If Some Missile Hit You, The X Or O Will Fall ");
	Draw_String(0,0,0,InfoX+17.5,InfoY+1.7,-5,"And You Will Have To Get It Again");
	Draw_String(0,0,0,InfoX+17.5,InfoY+1.5,-5,"And Maybe It Can Destroy Your");
	Draw_String(0,0,0,InfoX+17.5,InfoY+1.3,-5,"Helicopter And You Lose Your Turn");
	Draw_String(0,0,0,InfoX+17.5,InfoY+1.1,-5,"You Can't Destroy : Bridge's , Pyramid , Train");
	Draw_String(0,0,0,InfoX+17.5,InfoY+0.9,-5,"You Can Destroy : Tanks , Building");
	Draw_String(0,0,0,InfoX+17.5,InfoY+0.7,-5,"While Playing You Can Collect Coins");
	Draw_String(0,0,0,InfoX+17.5,InfoY+0.5,-5,"Winner Takes 100% Of The Coins He Collected");
	Draw_String(0,0,0,InfoX+17.5,InfoY+0.3,-5,"Loser Takes 50% Of The Coins He Collected");

	Draw_String(1,1,0,InfoX,InfoY-0.4,-5,"Level 1 : Mini Helicopter");
	Draw_String(0,0,0,InfoX,InfoY-0.6,-5,"Health : 100");
	Draw_String(0,0,0,InfoX,InfoY-0.8,-5,"Shooting Bullets");

	Draw_String(1,1,0,InfoX+2.1,InfoY-0.4,-5,"Level 2 : Air Ship");
	Draw_String(0,0,0,InfoX+2.1,InfoY-0.6,-5,"Health : 150");
	Draw_String(0,0,0,InfoX+2.1,InfoY-0.8,-5,"Shooting Bullets");
	Draw_String(0,0,0,InfoX+2.1,InfoY-1.0,-5,"Shooting Missile");

	Draw_String(1,1,0,InfoX+4,InfoY-0.4,-5,"Level 3 : Air Monster");
	Draw_String(0,0,0,InfoX+4,InfoY-0.6,-5,"Health : 200");
	Draw_String(0,0,0,InfoX+4,InfoY-0.8,-5,"Shooting Bullets");
	Draw_String(0,0,0,InfoX+4,InfoY-1.0,-5,"Shooting Missile");
	Draw_String(0,0,0,InfoX+4,InfoY-1.2,-5,"Shooting Bombs");


	Draw_String(10,0,0,-1.5,-1,-5,Login_Status);
	Draw_Button(&Name1);
	Draw_Button(&User_Name_1);
	Draw_Button(&User_Password_1);	

	if(Two_Players())
	{
		Draw_String(1,1,1,MainX-3,MainY+1.5,-5,"Player 1 :");
		Draw_String(1,1,1,MainX+1,MainY+1.5,-5,"Player 2:");
		Draw_String(1,1,1,MainX-3,MainY+0.4,-5,"Password :");
		Draw_String(1,1,1,MainX+1,MainY+0.4,-5,"Password :");
		Draw_Button(&User_Name_2);
		Draw_Button(&User_Password_2);
		Draw_Button(&Name2);
	}
	else
	{
		Draw_String(1,1,1,MainX-1,MainY+1.5,-5,"Player 1 :");
		Draw_String(1,1,1,MainX-1,MainY+0.4,-5,"Password :");
	}
}
void Winner_Page()
{
	Sun_Light();
	Light_1();
	glClearColor(0.2,0.4,1,1);
	Draw_Building(&Shown_Bulding[3]);
	Draw_Building(&Shown_Bulding[4]);
	if(Two_Players())
	{
		if(WinnerIs==PLAYER_1_WINS)
		{	
			Draw_String(0,0,0,-1,0,-5,"The Winner Is : ");
			Draw_String(1,1,0,0.5,0,-5,Winner_Name);
			Draw_String(0,0,0,-1,-0.2,-5,"Coins Collected :");
			Draw_String_int(1,1,0,0.5,-0.2,-5,"%d",Heli[0].Coins);
		}
		else if(WinnerIs==PLAYER_2_WINS)
		{	
			Draw_String(0,0,0,-1,0,-5,"The Winner Is : ");
			Draw_String(1,1,0,1,0,-5,Winner_Name);
			Draw_String(0,0,0,-1,-0.2,-5,"Coins Collected :");
			Draw_String_int(1,1,0,0.5,-0.2,-5,"%d",Heli[1].Coins);
		}
		else if(WinnerIs==DRAW)
		{	
			Draw_String(0,0,0,-0.2,0,-5,"DRAW");
			Draw_String(1,1,0,-1.5,-0.2,-5,Winner_Name);
			Draw_String(0,0,0,-0.5,-0.2,-5,"Coins Collected :");
			Draw_String_int(1,1,0,1,-0.2,-5,"%d",Heli[0].Coins/2);
			Draw_String(1,1,0,-1.5,-0.4,-5,Loser_Name);
			Draw_String(0,0,0,-0.5,-0.4,-5,"Coins Collected :");
			Draw_String_int(1,1,0,1,-0.4,-5,"%d",Heli[1].Coins/2);
		}
	}
	else
	{
		if(WinnerIs==PLAYER_1_WINS)
		{	
			Draw_String(0,0,0,-1,0,-5,"The Winner Is : ");
			Draw_String(1,1,0,0.5,0,-5,Winner_Name);
			Draw_String(0,0,0,-1,-0.2,-5,"Coins Collected :");
			Draw_String_int(1,1,0,0.5,-0.2,-5,"%d",Heli[0].Coins);
		}
		else if(WinnerIs==PLAYER_2_WINS)
		{	
			Draw_String(0,0,0,-1,0,-5,"The Winner Is : ");
			Draw_String(1,1,0,1,0,-5,"Bot");
		}
		else if(WinnerIs==DRAW)
		{	
			Draw_String(0,0,0,-0.2,0,-5,"DRAW");
			Draw_String(1,1,0,-1.5,-0.2,-5,Winner_Name);
			Draw_String(0,0,0,-0.5,-0.2,-5,"Coins Collected :");
			Draw_String_int(1,1,0,1,-0.2,-5,"%d",Heli[0].Coins/2);
		}
	}
	Draw_String(0,0,0,-0.5,-2,-5,"Press Any Key");
}
void Objects_Page()
{
	Draw_String(0,0,0,-3.5,2.5,-5,"Tanks - Train - Object");
	Draw_String(0,0,0,2,-2,-5,"Buildings - Object");
	Draw_String(0,0,0,-0.9,-2,-5,"Buildings With Missile - Object");
	Draw_Button(&Left_Opject);
	Draw_Button(&Right_Opject);
	Draw_Button(&Opject_Back);
	Draw_Bullding_With_Tank(&Object_Building_With_Tank);
	Draw_Building(Object_Build);
	for(int i=0;i<OBJECT_TANKS_TRAILER_SIZE;i++){
		Draw_Tank(&Object_Tanks[i]);
		Draw_Trailer(&Object_Trailers[i]);
		Object_Tanks[i].rotation.y++;
		Object_Tanks[i].rotation.y%=360;
		Object_Trailers[i].rotation.y++;
		Object_Trailers[i].rotation.y%=360;
	}
	Object_Build->rotation.y++;
	Object_Build->rotation.y%=360;
}
void ChoosePlayes_Page()
{
	Sun_Light();
	Light_1();
	Draw_String(0,0,10,-0.5,2,-5,"X-O Helicopter");
	Draw_Button(&Player1);
	Draw_Button(&Players2);
	Draw_Button(&Register);
	Draw_String(0,1,0,-2.2,-1.25,-5,"--VS Computer--");
	Draw_String(1,0,0,1,-1.25,-5,"--VS Player--");
}
void NewUser_page()
{
	Draw_String(0,0,0,-2.8,1.5,-5,"User name :");
	Draw_String(0,0,0,-2.8,0.5,-5,"Password :");
	Draw_String(0,0,0,-2,-1.5,-5,Register_Status);
	Draw_Button(&Register_Button);
	Draw_Button(&New_User_Name);
	Draw_Button(&New_User_Password);
	Draw_Button(&BackMain2);
}

void draw()
{
	glClear(GL_COLOR_BUFFER_BIT |
		GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	if(GameStatus==SCREEN_CHOOSE_PLAYERS)	 //Start Page 
		ChoosePlayes_Page();
	if(GameStatus==SCREEN_MANU)				 //Login Page 
		Manu_Page();
	if(GameStatus==SCREEN_PLAYING)			 //While Playing
		GamePlay_Page();
	if(GameStatus==SCREEN_WINNER)			 //Game Result Page
		Winner_Page();
	if(GameStatus==SCREEN_OBJECTS)			 //Show Up Objects Page
		Objects_Page();
	if(GameStatus==SCREEN_NEWUSER)			 //Register Page
		NewUser_page();

	glutSwapBuffers();			// display the output
}
int Missile_Controller(Missile *missile)//Controls Missile And Checks Bound With All Objects
{
	Bound_Missile_Bridge(missile,bridge,BRIDGE_SIZE);
	return 
	Bound_Missile_Bullding_With_Tank(missile,building_Tank,BUILDING_WITH_TANK_SIZE)
	+Bound_Missile_Building(missile,building,BUILDING_SIZE)
	+Bound_Missile_Tank(missile,tanks,TANKS_SIZE)
	+Bound_Missile_Train(missile,train,TRAIN_SIZE)
	+Bound_Missile_Gun(missile,gun,GUN_SIZE);
}
void Helicopter_Controller(Helicopter *Heli)//Controls Helicopter And Checks Bound With All Objects
{
	if(Heli->Health<=0 || Heli->fuel<0)
	{
		if(Heli->Blow.Radius==0)
		{
			Copy_Location(&Heli->Blow.location,Heli->location);
			Heli->Blow.Radius=0.001;
		}
		if(Heli->Blow.Radius>Heli->Blow.Max_Radius-0.1)
			SwitchPlayer();
	}

	if(Heli->location.y>MaxHigh)
		Heli->location.y=MaxHigh;
	for(int i=0;i<GUN_SIZE;i++)
		Bound_Helicopter_Gun(Heli,&gun[i]);
	for(int i=0;i<BONUS_SIZE;i++)
		Bound_Helicopter_Bonus(Heli,&bonus[i]);
	
	for(int i=0;i<4;i++)
		Heli->Coins+=Missile_Controller(&Heli->missile[i]);

	for(int i=0;i<TANKS_SIZE;i++)

		Bound_Helicopter_Tank(Heli,&tanks[i]);		
	for(int i=0;i<TRAIN_SIZE;i++)
		for(int j=0;j<10;j++)
			Bound_Helicopter_Trailer(Heli,&train[i].trailer[j]);

	Bound_Helicopter_XO_Table(Heli,&table);
	if(Heli->Status)return;

	for(int i=0;i<BUILDING_WITH_TANK_SIZE;i++)
	{
		Bound_Helicopter_Build(Heli,&building_Tank[i]);
		if(Heli->Status)return;
	}
	Heli->Status=Bound_Status_Box(Heli->BoundArea,Heli->location,Land);
	if(Heli->Status)return;
	for(int i=0;i<BRIDGE_SIZE;i++)
	{
		Bound_Helicopter_Bridge(Heli,&bridge[i]);
		if(Heli->Status)return;
	}
	for(int i=0;i<BUILDING_SIZE;i++)
	{
		Bound_Helicopter_Building(Heli,&building[i]);
		if(Heli->Status)return;
	}
	for(int i=0;i<MOUNTEN_SIZE;i++)
	{
		Bound_Helicopter_Building(Heli,&Mounten[i]);
		if(Heli->Status)return;
	}
}
void Tank_Controller(Tank *tank)//Controls Tank And Checks Bound With All Objects
{

	for(int i=0;i<BUILDING_WITH_TANK_SIZE;i++)
	{
		for(int j=0;j<TRAIN_SIZE;j++)
			Bound_Tank_Train(&building_Tank[i].tank,&train[j]);
		if(tank->Status)return;
			Bound_Tank_Build_With_Tank(tank,&building_Tank[i]);
		if(tank->Status)return;
	}
	for(int i=0;i<TANKS_SIZE;i++)
	{
		if(tank!=&tanks[i])
		Bound_Tank_Tank(tank,&tanks[i]);
		if(tank->Status)return;
	}
	for(int i=0;i<BRIDGE_SIZE;i++)
	{
		Bound_Tank_Bridge(tank,&bridge[i]);
		if(tank->Status)return;
	}
	for(int i=0;i<BUILDING_SIZE;i++)
	{			
		Bound_Tank_Building(tank,&building[i]);
		if(tank->Status)return;	
	}
	for(int i=0;i<GUN_SIZE;i++)
	{
		Bound_Tank_Gun(tank,&gun[i]);
		if(tank->Status)return;
	}
}
void XO_Conrtoller(XO *xo)//Controls XO And Checks Bound With All Objects
{
	if(Bound_XOBox_Table(xo,&table)==HIT_XO)
	{
		if(Check_Winner(&table)==DRAW)
		{
			Game_Draw();
			return;
		}
		if(Check_Winner(&table)==PLAYER_1_WINS)
		{
			if(Two_Players())
				Game_Winner(0,1);
			else
				Game_Winner_Bot(0);

			return;
		}
		if(Check_Winner(&table)==PLAYER_2_WINS)
		{
			Game_Winner(1,0);
			return;
		}
		SwitchPlayer();
	}
	for(int i=0;i<BRIDGE_SIZE;i++)
	{
		Bound_XOBox_Bridge(xo,&bridge[i]);
		if(!xo->Status)return;
	}
	for(int i=0;i<BUILDING_WITH_TANK_SIZE;i++)
	{
		Bound_XOBox_Build_With_Tank(xo,&building_Tank[i]);
		if(!xo->Status)return;
	}
	for(int i=0;i<BUILDING_SIZE;i++)
	{
		Bound_XOBox_Building(xo,&building[i]);
		if(!xo->Status)return;
	}
}
void Bonus_Controller(Bonus *B)//Controls Bonus And Checks Bound With All Objects
{
	for(int i=0;i<BRIDGE_SIZE;i++)
	{
		Bound_Bonus_Bridge(B,&bridge[i]);
		if(!B->Status)return;
	}
	for(int i=0;i<BUILDING_WITH_TANK_SIZE;i++)
	{
		Bound_Bonus_Build_With_Tank(B,&building_Tank[i]);
		if(!B->Status)return;
	}
	for(int i=0;i<BUILDING_SIZE;i++)
	{
		Bound_Bonus_Building(B,&building[i]);
		if(!B->Status)return;
	}
	Bonus_Movement(B);
}
void GamePlayIdle()
{
	if(Heli[INDEX].Ready==0)
		return;
	for(int i=0;i<GUN_SIZE;i++)			
		Gun_Movement(&gun[i]);
	if(Two_Players())
	{
		Helicopter_Controller(&Heli[INDEX]);
		Helicopter_Movement(&Heli[INDEX]);
	}
	else
	{
		Helicopter_Controller(&Heli[0]);
		Helicopter_Movement(&Heli[0]);
	}
		for(int i=0;i<TANKS_SIZE;i++)
		{
			Tank_Controller(&tanks[i]);
			Tank_Movement(&tanks[i]);
		}
	

	for(int i=0;i<TANKS_SIZE;i++)
		Missile_Controller(&tanks[i].ML.missile);

	for(int i=0;i<BUILDING_SIZE;i++)
		Build_Movement(&building[i]);
	for(int i=0;i<BONUS_SIZE;i++)
		Bonus_Controller(&bonus[i]);

	
	for(int i=0;i<XO_SIZE;i++)
	{
		XO_Conrtoller(&xo_o[i]);
		if(GameStatus!=SCREEN_PLAYING)return;
		Bound_Helicopter_XOBox(&Heli[1],&xo_o[i]);
		XO_Box_Movement(&xo_o[i]);
	}
	
	for(int i=0;i<XO_SIZE;i++)
	{
		XO_Conrtoller(&xo_x[i]);
		if(GameStatus!=SCREEN_PLAYING)return;
		Bound_Helicopter_XOBox(&Heli[0],&xo_x[i]);
		XO_Box_Movement(&xo_x[i]);
	}

	for(int i=0;i<TRAIN_SIZE;i++)
		Train_Movement(&train[i]);
	for(int i=0;i<TRAIN_SIZE;i++)
	{
		for(int j=0;j<10;j++)
			if(train[i].trailer[j].Type==1 ||train[i].trailer[j].Type==2)			
				Missile_Controller(&train[i].trailer[j].ML.missile);		
	}

	for(int i=0;i<5;i++)
	{
		Heli[INDEX].Coins+=Bound_Bomb_Bullding_With_Tank(&Heli[INDEX].Bombs[i],building_Tank,BUILDING_WITH_TANK_SIZE);
		Bound_Bomb_Bridge(&Heli[INDEX].Bombs[i],bridge,BRIDGE_SIZE);
		Heli[INDEX].Coins+=Bound_Bomb_Building(&Heli[INDEX].Bombs[i],building,BUILDING_SIZE);
		Heli[INDEX].Coins+=Bound_Bomb_Tank(&Heli[INDEX].Bombs[i],tanks,TANKS_SIZE);
		Heli[INDEX].Coins+=Bound_Bomb_Train(&Heli[INDEX].Bombs[i],train,TRAIN_SIZE);
		Heli[INDEX].Coins+=Bound_Bomb_Gun(&Heli[INDEX].Bombs[i],gun,GUN_SIZE);

		Heli[INDEX].Coins+=Bound_Bomb_Bullding_With_Tank(&Heli[INDEX].bullet[i],building_Tank,BUILDING_WITH_TANK_SIZE);
		Bound_Bomb_Bridge(&Heli[INDEX].bullet[i],bridge,BRIDGE_SIZE);
		Heli[INDEX].Coins+=Bound_Bomb_Building(&Heli[INDEX].bullet[i],building,BUILDING_SIZE);
		Heli[INDEX].Coins+=Bound_Bomb_Tank(&Heli[INDEX].bullet[i],tanks,TANKS_SIZE);
		Heli[INDEX].Coins+=Bound_Bomb_Train(&Heli[INDEX].bullet[i],train,TRAIN_SIZE);
		Heli[INDEX].Coins+=Bound_Bomb_Gun(&Heli[INDEX].bullet[i],gun,GUN_SIZE);
	}
	for(int i=0;i<BUILDING_WITH_TANK_SIZE;i++)
	{
		Tank_Controller(&building_Tank[i].tank);
		Bullding_With_Tank_Movement(&building_Tank[i]);
		Missile_Controller(&building_Tank[i].ML.missile);
		Missile_Controller(&building_Tank[i].tank.ML.missile);
	}
}
void Main_To_Register()//Moving Page
{
		New_User_Name.y-=0.1;
		New_User_Password.y-=0.1;
		Register_Button.y-=0.1;
		ShowGames.y-=0.1;
		BackMain2.y-=0.1;
		Register.y-=0.1;
		Details.y-=0.1;
		User_Name_1.y-=0.1;
		User_Name_2.y-=0.1;
		User_Password_1.y-=0.1;
		User_Password_2.y-=0.1;
		ChooseMap.y-=0.1;
		Exit.y-=0.1;
		Register.y-=0.1;
		MainY-=0.1;
}
void Register_To_Map()//Moving Page
{
		New_User_Name.y+=0.1;
		New_User_Password.y+=0.1;
		Register_Button.y+=0.1;
		ShowGames.y+=0.1;
		BackMain2.y+=0.1;
		Register.y+=0.1;
		Details.y+=0.1;
		Register.y+=0.1;
		User_Name_1.y+=0.1;
		User_Name_2.y+=0.1;
		User_Password_1.y+=0.1;
		User_Password_2.y+=0.1;
		ChooseMap.y+=0.1;
		MainY+=0.1;
		Exit.y+=0.1;
}
void Main_To_Map()//Moving Page
{
	for(int i=0;i<3;i++)
			Shown_Bulding[i].location.x-=1;

		Up.x-=0.1;
		Border.x-=0.1;
		Down.x-=0.1;
		BackMain.x-=0.1;
		ShowGames.x-=0.1;
		User_Name_1.x-=0.1;
		User_Name_2.x-=0.1;
		User_Password_1.x-=0.1;
		User_Password_2.x-=0.1;
		ChooseMap.x-=0.1;
		Exit.x-=0.1;
		Back.x-=0.1;
		Map1.x-=0.1;
		Map2.x-=0.1;
		Map3.x-=0.1;
		Map4.x-=0.1;
		Details.x-=0.1;
		Register.x-=0.1;
		MainX-=0.1;
		Store.x-=0.1;
		InfoX-=0.1;
		Name1.x-=0.1;
		Name2.x-=0.1;
		BackFromStore.x-=0.1;
		for(int i=0;i<3;i++)
			Damage_Bonus[i].location.x-=1;
		for(int i=0;i<4;i++)
			Buy[i].x-=0.1;
		StoreX-=0.1;
		Night_Day.x-=0.1;
	
}
void Map_To_Main()//Moving Page//Moving Page
{
		for(int i=0;i<3;i++)
			Shown_Bulding[i].location.x+=1;

		Up.x+=0.1;
		Border.x+=0.1;
		Down.x+=0.1;
		Game_List->x+=0.1;
		BackMain.x+=0.1;
		ShowGames.x+=0.1;
		User_Name_1.x+=0.1;
		User_Name_2.x+=0.1;
		User_Password_1.x+=0.1;
		User_Password_2.x+=0.1;
		ChooseMap.x+=0.1;
		Exit.x+=0.1;
		Back.x+=0.1;
		Map1.x+=0.1;
		Map2.x+=0.1;
		Map3.x+=0.1;
		Map4.x+=0.1;
		Details.x+=0.1;
		Register.x+=0.1;
		MainX+=0.1;
		InfoX+=0.1;
		Store.x+=0.1;
		Name1.x+=0.1;
		Name2.x+=0.1;
		BackFromStore.x+=0.1;
		for(int i=0;i<3;i++)
			Damage_Bonus[i].location.x+=1;
		for(int i=0;i<4;i++)
			Buy[i].x+=0.1;
		StoreX+=0.1;
		Night_Day.x+=0.1;
}
void Map_To_Store()//Moving Page
{
	for(int i=0;i<3;i++)
			Shown_Bulding[i].location.x-=2;

		Up.x-=0.1;
		Border.x-=0.1;
		Down.x-=0.1;
		BackMain.x-=0.1;
		ShowGames.x-=0.1;
		User_Name_1.x-=0.1;
		User_Name_2.x-=0.1;
		User_Password_1.x-=0.1;
		User_Password_2.x-=0.1;
		ChooseMap.x-=0.1;
		Exit.x-=0.1;
		Back.x-=0.1;
		Map1.x-=0.1;
		Map2.x-=0.1;
		Map3.x-=0.1;
		Map4.x-=0.1;
		Details.x-=0.1;
		Register.x-=0.1;
		MainX-=0.1;
		Store.x-=0.1;
		Name1.x-=0.1;
		Name2.x-=0.1;
		BackFromStore.x-=0.1;
		for(int i=0;i<3;i++)
			Damage_Bonus[i].location.x-=1;
		for(int i=0;i<4;i++)
			Buy[i].x-=0.1;
		StoreX-=0.1;
		Night_Day.x-=0.1;
		InfoX-=0.1;

}
void Store_To_Map()//Moving Page
{
		for(int i=0;i<3;i++)
			Shown_Bulding[i].location.x+=2;

		Up.x+=0.1;
		Border.x+=0.1;
		Down.x+=0.1;
		Game_List->x+=0.1;
		BackMain.x+=0.1;
		ShowGames.x+=0.1;
		User_Name_1.x+=0.1;
		User_Name_2.x+=0.1;
		User_Password_1.x+=0.1;
		User_Password_2.x+=0.1;
		ChooseMap.x+=0.1;
		Exit.x+=0.1;
		Back.x+=0.1;
		Map1.x+=0.1;
		Map2.x+=0.1;
		Map3.x+=0.1;
		Map4.x+=0.1;
		Details.x+=0.1;
		Register.x+=0.1;
		MainX+=0.1;
		Store.x+=0.1;
		Name1.x+=0.1;
		Name2.x+=0.1;
		BackFromStore.x+=0.1;
		InfoX+=0.1;
		for(int i=0;i<3;i++)
			Damage_Bonus[i].location.x+=1;
		for(int i=0;i<4;i++)
			Buy[i].x+=0.1;
		StoreX+=0.1;
		Night_Day.x+=0.1;
}
void Main_To_Games()//Moving Page
{
	tmp=Game_List;
		while(tmp!=nullptr)
		{
			tmp->y+=0.1;
			tmp=tmp->next;
		}

		Up.y+=0.1;
		Border.y+=0.1;
		Down.y+=0.1;
		BackMain.y+=0.1;
		ShowGames.y+=0.1;
		User_Name_1.y+=0.1;
		User_Name_2.y+=0.1;
		User_Password_1.y+=0.1;
		User_Password_2.y+=0.1;
		ChooseMap.y+=0.1;
		Exit.y+=0.1;
		Back.y+=0.1;
		Map1.y+=0.1;
		Map2.y+=0.1;
		Map3.y+=0.1;
		Details.y+=0.1;
		Register.y+=0.1;
		MainY+=0.1;
}
void Games_To_Main()//Moving Page
{
	tmp=Game_List;
		while(tmp!=nullptr)
		{
			tmp->y-=0.1;
			tmp=tmp->next;
		}

		Up.y-=0.1;
		Border.y-=0.1;
		Down.y-=0.1;
		BackMain.y-=0.1;
		ShowGames.y-=0.1;
		User_Name_1.y-=0.1;
		User_Name_2.y-=0.1;
		User_Password_1.y-=0.1;
		User_Password_2.y-=0.1;
		ChooseMap.y-=0.1;
		Exit.y-=0.1;
		Back.y-=0.1;
		Map1.y-=0.1;
		Map2.y-=0.1;
		Map3.y-=0.1;
		Details.y-=0.1;
		Register.y-=0.1;
		MainY-=0.1;
}
void Main_To_Details()//Moving Page
{

		Up.x+=0.1;
		Border.x+=0.1;
		Down.x+=0.1;
		Game_List->x+=0.1;
		BackMain.x+=0.1;
		ShowGames.x+=0.1;
		User_Name_1.x+=0.1;
		User_Name_2.x+=0.1;
		User_Password_1.x+=0.1;
		User_Password_2.x+=0.1;
		ChooseMap.x+=0.1;
		Exit.x+=0.1;
		Back.x+=0.1;
		Map1.x+=0.1;
		Map2.x+=0.1;
		Map3.x+=0.1;
		Details.x+=0.1;
		BackMain1.x+=0.1;
		DrawBullet.x+=0.1;
		DrawBomb.x+=0.1;
		DrawMissile.x+=0.1;
		DrawCoins.x+=0.1;
		DrawFuel.x+=0.1;
		Register.x+=0.1;
		Show_Opjects.x+=0.1;
		for(int i=0;i<5;i++)
			Shown_Bonus[i].location.x+=0.1;
		InfoX+=0.1;
		MainX+=0.1;
}
void Details_To_Main()//Moving Page
{

		Up.x-=0.1;
		Border.x-=0.1;
		Down.x-=0.1;
		Game_List->x-=0.1;
		BackMain.x-=0.1;
		ShowGames.x-=0.1;
		User_Name_1.x-=0.1;
		User_Name_2.x-=0.1;
		User_Password_1.x-=0.1;
		User_Password_2.x-=0.1;
		ChooseMap.x-=0.1;
		Exit.x-=0.1;
		Back.x-=0.1;
		Map1.x-=0.1;
		Map2.x-=0.1;
		Map3.x-=0.1;
		Details.x-=0.1;
		BackMain1.x-=0.1;
		DrawBullet.x-=0.1;
		DrawBomb.x-=0.1;
		DrawMissile.x-=0.1;
		DrawCoins.x-=0.1;
		DrawFuel.x-=0.1;
		Register.x-=0.1;
		Show_Opjects.x-=0.1;

		for(int i=0;i<5;i++)
			Shown_Bonus[i].location.x-=0.1;
		MainX-=0.1;
		InfoX-=0.1;
}
void MainIdle()
{
	if(MainPage==MOVE_MAP_TO_MAIN && Roller>0)
	{
		Map_To_Main();
		Roller--;
	}
	if(MainPage==MOVE_MAIN_TO_MAP && Roller<100)
	{
		Main_To_Map();
		Roller++;
	}
	if(MainPage==MOVE_MAIN_TO_GAMES && Roller<100)
	{
		Main_To_Games();
		Roller++;
	}
	if(MainPage==MOVE_GAMES_TO_MAIN && Roller>0)
	{
		Games_To_Main();
		Roller--;
	}
	if(MainPage==MOVE_MAIN_TO_DETAILS && Roller<100)
	{
		Main_To_Details();
		Roller++;
	}
	if(MainPage==MOVE_DETAILS_TO_MAIN && Roller>0)
	{
		Details_To_Main();
		Roller--;
	}
	if(MainPage==MOVE_MAIN_TO_REGISTER && Roller <100)
	{
		Main_To_Register();
		Roller++;
	}
	if(MainPage==MOVE_REGISTER_TO_MAP && Roller >0)
	{
		Register_To_Map();
		Roller--;
	}
	if(MainPage==MOVE_MAP_TO_STORE && Roller>0)
	{
		Map_To_Store();
		Roller--;
	}
	if(MainPage==MOVE_STORE_TO_MAP && Roller<100)
	{
		Store_To_Map();
		Roller++;
	}
}
void idle()
{

	if(GameStatus==SCREEN_MANU)	  //While Not Playing
		 MainIdle();
	if(GameStatus==SCREEN_PLAYING)//While Playing
		GamePlayIdle();

		draw();
}
// Set OpenGL parameters
void init()

{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, 1.0, 0.1, 300);
	glMatrixMode(GL_MODELVIEW);

	// Lighting parameters
	GLfloat mat_ambdif[] = { 1, 1, 1, 0 };
	GLfloat mat_specular[] = { 1, 1, 1, 0.0 };
	GLfloat mat_diffuseLight[] = {1,1,1,0};
	GLfloat mat_shininess[] = { 80.0 };
	GLfloat light_position[] = { 1, 1, 1, 0.0 };
	glClearColor(0.3, 0.3, 1.0, 0.0);

	glMaterialfv(GL_LIGHT0, GL_AMBIENT, mat_ambdif);	
	glMaterialfv(GL_LIGHT0, GL_SPECULAR, mat_specular);		
	glMaterialfv(GL_LIGHT0, GL_SHININESS, mat_shininess);		
	glMaterialfv(GL_LIGHT0, GL_DIFFUSE, mat_diffuseLight);		
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);		
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);		
	glEnable(GL_COLOR_MATERIAL);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);

	glEnable (GL_FOG); //enable the fog
	glFogi (GL_FOG_MODE, GL_EXP2); //set the fog mode to GL_EXP2
	glFogfv (GL_FOG_COLOR, fogColor); //set the fog color to
	glFogf (GL_FOG_DENSITY, density); //set the density to the
	glHint (GL_FOG_HINT, GL_DONT_CARE); // set the fog to look the
	glEnable(GL_DEPTH_TEST);
}

int main(int argc, char *argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);	// RGB display, double-buffered, with Z-Buffer
	glutInitWindowSize(WIDTH, HEIGHT);					
	glutInitWindowPosition (10, 10);
	glutCreateWindow("3D");
	glutReshapeFunc(reshape);
	glutDisplayFunc(draw);						// Set the display function
	glutKeyboardFunc(keyboard);					// Set the keyboard function
	glutIdleFunc(idle);
	glutMouseFunc(glutMouseClick);
	glutFullScreen();
	glutPassiveMotionFunc(passiveMotionFunc);
	Set_Manu();
	init();
	glutMainLoop();							// Start the main event loop
}