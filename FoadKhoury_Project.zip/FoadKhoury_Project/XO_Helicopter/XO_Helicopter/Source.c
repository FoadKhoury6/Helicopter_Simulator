#include "Functions.h"

int rot = 0;
int ind = 0;
struct elem
{
	float x, y, z;
	float r, g, b;
};
struct elem arr[8];
void init_elem()
{
	int i;
	for(i=0;i<8;i++)
	{
		arr[i].x = -4 + i;
		arr[i].y = 0.0;
		arr[i].z = -4 + i;
		arr[i].r = 1.0;
		arr[i].g = 0.0;
		arr[i].b = 0.0;
	}
}
void keyboard(unsigned char key, int x, int y)
{
	if (key == 27) exit(1);
	if (key == 'r') {
		rot += 5;
		rot %= 360;
	}
	if(key>='1'&&key<='8')
	{
		arr[ind].r = 1.0;
		arr[ind].g = 0.0;
		arr[ind].b = 0.0;
		ind = key - '0' - 1;
		arr[ind].r = 0.0;
		arr[ind].g = 0.0;
		arr[ind].b = 1.0;
	}
	if (key == 'w')
		arr[ind].z -= 0.5;
	if (key == 's')
		arr[ind].z += 0.5;
	if (key == 'a')
		arr[ind].x -= 0.5;
	if (key == 'd')
		arr[ind].x += 0.5;
	glutPostRedisplay();
}

void cub()
{
	glBegin(GL_QUADS);
	// Front

	glNormal3f(0, 0, 1);
	glVertex3f(-1, 0, 1);
	glVertex3f(-1, 2, 1);
	glVertex3f(1, 2, 1);
	glVertex3f(1, 0, 1);

	// Back
	glNormal3f(0, 0, -1);
	glVertex3f(-1, 0, -1);
	glVertex3f(1, 0, -1);
	glVertex3f(1, 2, -1);
	glVertex3f(-1, 2, -1);

	// Left side
	glNormal3f(-1, 0, 0);
	glVertex3f(-1, 0, 1);
	glVertex3f(-1, 2, 1);
	glVertex3f(-1, 2, -1);
	glVertex3f(-1, 0, -1);

	// Right side
	glNormal3f(1, 0, 0);
	glVertex3f(1, 0, 1);
	glVertex3f(1, 0, -1);
	glVertex3f(1, 2, -1);
	glVertex3f(1, 2, 1);
	glEnd();
}

void regel()
{
	glBegin(GL_QUADS);
	// Front
	glNormal3f(0, 0, 0.5);
	glVertex3f(-0.5, 0, 0.5);
	glVertex3f(-0.5, -2, 0.5);
	glVertex3f(0.5, -2, 0.5);
	glVertex3f(0.5, 0, 0.5);

	// Back
	glNormal3f(0, 0, -0.5);
	glVertex3f(-0.5, 0, -0.5);
	glVertex3f(0.5, 0, -0.5);
	glVertex3f(0.5, -2, -0.5);
	glVertex3f(-0.5, -2, -0.5);

	// Left side
	glNormal3f(-0.5, 0, 0);
	glVertex3f(-0.5, 0, 0.5);
	glVertex3f(-0.5, -2, 0.5);
	glVertex3f(-0.5, -2, -0.5);
	glVertex3f(-0.5, 0, -0.5);

	// Right side
	glNormal3f(0.5, 0, 0);
	glVertex3f(0.5, 0, 0.5);
	glVertex3f(0.5, 0, -0.5);
	glVertex3f(0.5, -2, -0.5);
	glVertex3f(0.5, -2, 0.5);
	glEnd();
}
void draw()
{
	glClear(GL_COLOR_BUFFER_BIT |
		GL_DEPTH_BUFFER_BIT);

	glLoadIdentity();
	glTranslatef(0, -3, -12);
	glRotatef(rot, 1, 0, 0);
	/************************************************************/
	// Floor
	glBegin(GL_QUADS);
	glColor3f(0.2, 0.7, 0.3);
	glNormal3f(0, 1, 0);	// normal straight up
	glVertex3f(-5, 0, -5);
	glVertex3f(5, 0, -5);
	glVertex3f(5, 0, 5);
	glVertex3f(-5, 0, 5);
	glEnd();
	glColor3f(1.0, 0.0, 0.0);
	glTranslatef(-4.5, 0, -4.5);
	regel();
	glTranslatef(9, 0, 0);
	regel();
	glTranslatef(0, 0, 9);
	regel();
	glTranslatef(-9, 0, 0);
	regel();
	glTranslatef(4.5, 0, -4.5);
	glTranslatef(0, 0.5, 0);

	for(int i=0;i<4;i++)
	{
		glTranslatef(arr[i].x, arr[i].y, arr[i].z);
		glColor3f(arr[i].r, arr[i].g, arr[i].b);
		glutSolidCube(1);
		glTranslatef(-arr[i].x, -arr[i].y, -arr[i].z);
	}
	for (int i = 4; i<8; i++)
	{
		glTranslatef(arr[i].x, arr[i].y, arr[i].z);
		glColor3f(arr[i].r, arr[i].g, arr[i].b);
		glutSolidSphere(0.5,32,32);
		glTranslatef(-arr[i].x, -arr[i].y, -arr[i].z);
	}
	/*
	glutSolidSphere(0.5,32,32);

	glTranslatef(2, 0, 0);
	glutSolidCube(1);*/

	//cub();
	//glTranslatef(2.5, 0, 0);
	//cub();
	glutSwapBuffers();			// display the output
}

// Set OpenGL parameters
void init()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60, 1.0, 0.1, 100);
	glMatrixMode(GL_MODELVIEW);

	// Lighting parameters

	GLfloat mat_ambdif[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat mat_specular[] = { 0.0, 1.0, 0.0, 0.0 };
	GLfloat mat_shininess[] = { 80.0 };
	GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 };
	glClearColor(0.0, 0.0, 0.0, 0.0);


	glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, mat_ambdif);	// set both amb and diff components
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);		// set specular
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);		// set shininess
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);		// set light "position", in this case direction
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);		// active material changes by glColor3f(..)

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_COLOR_MATERIAL);

	glEnable(GL_DEPTH_TEST);
}

int main(int argc, char *argv[])

{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);	// RGB display, double-buffered, with Z-Buffer
	glutInitWindowSize(500, 500);					// 500 x 500 pixels
	glutCreateWindow("3D");
	glutDisplayFunc(draw);						// Set the display function
	glutKeyboardFunc(keyboard);					// Set the keyboard function
	init_elem();
	init();
	glutMainLoop();							// Start the main event loop
}

