#include "_Define.h"
typedef struct User
{
	char User_Name[20];
	char Password[20];
	int Type;
	int Coins;
	int Wins;
	int Loses;
	float Bullet_Damage;
	float Bomb_Damage;
	float Missile_Damage;
}User;
typedef struct Speed
{
	float x,y,z;
}Speed;
typedef struct Color{
	float r,g,b;
}Color;
typedef struct Location
{
	float x,y,z;
}Location;
typedef struct Rotation
{
	int x,y,z;
}Rotation;
typedef struct Size
{
	float x,y,z;
}Size;
typedef struct Smoke
{
	Location location;
	Color color;
	float Radius,Max_Radius,Speed;
}Smoke;
typedef struct Box
{
	Color color;
	Location location;
	Rotation rotation;
	Size size;
}Box;
typedef struct Wheel
{
	Location location;
	Rotation rotation;
	Box B1,B2;
	float Radius;
}Wheel;
typedef struct Sata{
	Location location;
	Rotation rotation;
	Box arr[5];
}Sata;
typedef struct Missile
{
	int Type;
	int status;
	int fuel;
	float Damage;
	Location location;
	Location *Launch_Location;
	Location *target;
	Helicopter *Helicopter_target;
	Rotation rotation;
	Speed speed;
	Speed Maxspeed;
	Box Body;
	Box Top;
	Box Wing1,Wing2;
	Smoke smoke[4];
	Smoke Blow;
}Missile;
typedef struct Missile_Launcher
{
	int Type;
	int *TankRotation;
	Location location;
	Location *target;
	Location *Launch_Location;
	Trailer *trailer;
	Rotation rotation;
	Missile missile;
	Box Base;
	Box Hold;
	Box Stick;
	Box Under_base;
}Missile_Launcher;
typedef struct Tank
{
	int Health;
	int Type;
	int Status;
	int Maxspeed;
	int Start_Tank;
	Smoke Blow;
	Location location_1,location_2;
	Location location;
	Location *target;
	Rotation rotation;
	Speed speed;
	Wheel wheel[6];
	Box Body;
	Box Room;
	Missile_Launcher ML;
	Box Missile_Area;
	Box Tank_Bound_Area;
	Box Heli[4];
}Tank;
typedef struct Bullding_With_Tank
{
	Tank tank;
	Sata sata;
	Location location;
	Missile_Launcher ML;
	Box box[7];
	Box Virtual_Boxes;
	Box Missile_Area;
}Bullding_With_Tank;
typedef struct Tree
{
	Location location;
}Tree;
typedef struct Cloud
{
	Location location;
}Cloud;
typedef struct Street{
	Location location;
	Rotation rotation;
	Box body;
	Box line;
}Street;
typedef struct XO
{
	float MoveFlag;
	int Status;
	int X_Or_O;
	Location location;
	Box Body;
	Box Body1;
}XO;
typedef struct Aim
{
	Location location;
	Rotation rotation;
	Box B1,B2,B3,B4;
	float UPDown;
}Aim;
typedef struct Bullet
{
	float Damage;
	int Status;
	Location location;
	Speed speed;
	float Radius;
	Smoke Blow;
	Box Bound;
}Bullet;
typedef struct Helicopter
{
	int Health,Reload,Ready,Status,FanSpeed,X_Or_O;
	float fuel;
	int Missile_Cnt,Bullet_Cnt,Bomb_Cnt,Shake,Coins;
	int CameraX,CameraY,CameraZ,LookAround_X,LookAround_Y;
	Smoke Shoot;
	Speed speed;
	Smoke Blow;
	User *user;
	XO *MyXo;
	Location location;
	Rotation rotation;
	Box Engine;
	Box Fan,BackFan,Roof;
	Box FanStick,BackFanStick,BackWing;
	Box Body,UpBody,Wing,BoundArea;
	int bomb_index;
	Bullet Bombs[4];
	Missile missile[4];
	int missile_index;
	Aim aim;
	int bullet_index;
	Bullet bullet[5];
	Box Robot[20];
	Smoke RobotSmoke[5];
}Helicopter;
typedef struct Bridge
{
	Location location;
	int Size;
	Street street;
	Box *Roof;
	Box *Base;
}Bridge;
typedef struct Building
{
	Location location;
	Rotation rotation;
	int Health;
	int Type,Size,Shake;
	Box *arr;
	Box Tank_Bound;
	int MoveFlag;
}Building;
typedef struct Button
{
	float x,y;
	char *strPointer;
	char str[80];
	float Side;
	Color color;
}Button;
typedef struct GameList
{
	float x,y;
	char Player1[20];
	char Player2[20];
	char Winner[20];
	char *str;
	struct GameList *next;
}GameList;
typedef struct Bonus{
	Location location;
	Rotation rotation;
	int Type;
	int Status;
	Box arr[3];
	Box Bound;
}Bonus;
typedef struct Trailer
{
	int Type;
	Location location;
	Rotation rotation;
	Box B1,B2,B3;
	Box Missile_Area;
	Wheel wheel[4];
	Missile_Launcher ML;
}Trailer;
typedef struct Train
{
	Location location_1,location_2;
	Trailer trailer[10];
	Speed speed;
	Box B1,B2;
}Train;
typedef struct XO_Table{
	Location location;
	Box arr[9];
	Box Body;
	Box Stand[10];
	Sata sata;
}XO_Table;
typedef struct Star
{
	Location location;
}Star;
typedef struct Gun{
	Location location;
	Rotation rotation;
	int Status;
	int Health;
	Location *target;
	Helicopter *Heli;
	Box Gun_Area;
	Box Bound_Area;
	Box box[17];
	Smoke Blow;
	Smoke Shoot;
}Gun;